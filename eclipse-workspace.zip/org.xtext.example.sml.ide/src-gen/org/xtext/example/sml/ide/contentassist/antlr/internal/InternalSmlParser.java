package org.xtext.example.sml.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.example.sml.services.SmlGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSmlParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_ID", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'e-puck'", "'footboot'", "'uniform'", "'gaussian'", "'constant'", "'objects'", "'obstacles'", "'Circle'", "'Polygon'", "'Triangle'", "'Rectangle'", "'red'", "'yellow'", "'green'", "'The'", "'arena'", "'contains'", "'the'", "'following'", "'elements'", "':'", "'distributed'", "'with'", "'a'", "'distribution'", "'in'", "'robot'", "'swarm'", "'consists'", "'of'", "'are'", "'light'", "'sources'", "'object'", "'as'", "'obstacle'", "'source'", "'emitting'", "'is'", "'placed'", "'center'", "'reference point'", "'point'", "'and'", "'radius'", "'length'", "',width'", "'height'", "'.'", "'less'", "'than'", "'or'", "'equal'", "'more'", "'between'", "'There'", "'An'", "'A'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=4;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__68=68;
    public static final int T__25=25;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalSmlParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSmlParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSmlParser.tokenNames; }
    public String getGrammarFileName() { return "InternalSml.g"; }


    	private SmlGrammarAccess grammarAccess;

    	public void setGrammarAccess(SmlGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleModel"
    // InternalSml.g:53:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // InternalSml.g:54:1: ( ruleModel EOF )
            // InternalSml.g:55:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalSml.g:62:1: ruleModel : ( ( rule__Model__Group__0 ) ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:66:2: ( ( ( rule__Model__Group__0 ) ) )
            // InternalSml.g:67:2: ( ( rule__Model__Group__0 ) )
            {
            // InternalSml.g:67:2: ( ( rule__Model__Group__0 ) )
            // InternalSml.g:68:3: ( rule__Model__Group__0 )
            {
             before(grammarAccess.getModelAccess().getGroup()); 
            // InternalSml.g:69:3: ( rule__Model__Group__0 )
            // InternalSml.g:69:4: rule__Model__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Model__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleEnvironment"
    // InternalSml.g:78:1: entryRuleEnvironment : ruleEnvironment EOF ;
    public final void entryRuleEnvironment() throws RecognitionException {
        try {
            // InternalSml.g:79:1: ( ruleEnvironment EOF )
            // InternalSml.g:80:1: ruleEnvironment EOF
            {
             before(grammarAccess.getEnvironmentRule()); 
            pushFollow(FOLLOW_1);
            ruleEnvironment();

            state._fsp--;

             after(grammarAccess.getEnvironmentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEnvironment"


    // $ANTLR start "ruleEnvironment"
    // InternalSml.g:87:1: ruleEnvironment : ( ( rule__Environment__Group__0 ) ) ;
    public final void ruleEnvironment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:91:2: ( ( ( rule__Environment__Group__0 ) ) )
            // InternalSml.g:92:2: ( ( rule__Environment__Group__0 ) )
            {
            // InternalSml.g:92:2: ( ( rule__Environment__Group__0 ) )
            // InternalSml.g:93:3: ( rule__Environment__Group__0 )
            {
             before(grammarAccess.getEnvironmentAccess().getGroup()); 
            // InternalSml.g:94:3: ( rule__Environment__Group__0 )
            // InternalSml.g:94:4: rule__Environment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Environment__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEnvironmentAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEnvironment"


    // $ANTLR start "entryRuleProbabilisticDecription"
    // InternalSml.g:103:1: entryRuleProbabilisticDecription : ruleProbabilisticDecription EOF ;
    public final void entryRuleProbabilisticDecription() throws RecognitionException {
        try {
            // InternalSml.g:104:1: ( ruleProbabilisticDecription EOF )
            // InternalSml.g:105:1: ruleProbabilisticDecription EOF
            {
             before(grammarAccess.getProbabilisticDecriptionRule()); 
            pushFollow(FOLLOW_1);
            ruleProbabilisticDecription();

            state._fsp--;

             after(grammarAccess.getProbabilisticDecriptionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleProbabilisticDecription"


    // $ANTLR start "ruleProbabilisticDecription"
    // InternalSml.g:112:1: ruleProbabilisticDecription : ( ( rule__ProbabilisticDecription__Group__0 ) ) ;
    public final void ruleProbabilisticDecription() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:116:2: ( ( ( rule__ProbabilisticDecription__Group__0 ) ) )
            // InternalSml.g:117:2: ( ( rule__ProbabilisticDecription__Group__0 ) )
            {
            // InternalSml.g:117:2: ( ( rule__ProbabilisticDecription__Group__0 ) )
            // InternalSml.g:118:3: ( rule__ProbabilisticDecription__Group__0 )
            {
             before(grammarAccess.getProbabilisticDecriptionAccess().getGroup()); 
            // InternalSml.g:119:3: ( rule__ProbabilisticDecription__Group__0 )
            // InternalSml.g:119:4: rule__ProbabilisticDecription__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ProbabilisticDecription__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getProbabilisticDecriptionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleProbabilisticDecription"


    // $ANTLR start "entryRuleSwarmconf"
    // InternalSml.g:128:1: entryRuleSwarmconf : ruleSwarmconf EOF ;
    public final void entryRuleSwarmconf() throws RecognitionException {
        try {
            // InternalSml.g:129:1: ( ruleSwarmconf EOF )
            // InternalSml.g:130:1: ruleSwarmconf EOF
            {
             before(grammarAccess.getSwarmconfRule()); 
            pushFollow(FOLLOW_1);
            ruleSwarmconf();

            state._fsp--;

             after(grammarAccess.getSwarmconfRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSwarmconf"


    // $ANTLR start "ruleSwarmconf"
    // InternalSml.g:137:1: ruleSwarmconf : ( ( rule__Swarmconf__Group__0 ) ) ;
    public final void ruleSwarmconf() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:141:2: ( ( ( rule__Swarmconf__Group__0 ) ) )
            // InternalSml.g:142:2: ( ( rule__Swarmconf__Group__0 ) )
            {
            // InternalSml.g:142:2: ( ( rule__Swarmconf__Group__0 ) )
            // InternalSml.g:143:3: ( rule__Swarmconf__Group__0 )
            {
             before(grammarAccess.getSwarmconfAccess().getGroup()); 
            // InternalSml.g:144:3: ( rule__Swarmconf__Group__0 )
            // InternalSml.g:144:4: rule__Swarmconf__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Swarmconf__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSwarmconfAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSwarmconf"


    // $ANTLR start "entryRuleRobot"
    // InternalSml.g:153:1: entryRuleRobot : ruleRobot EOF ;
    public final void entryRuleRobot() throws RecognitionException {
        try {
            // InternalSml.g:154:1: ( ruleRobot EOF )
            // InternalSml.g:155:1: ruleRobot EOF
            {
             before(grammarAccess.getRobotRule()); 
            pushFollow(FOLLOW_1);
            ruleRobot();

            state._fsp--;

             after(grammarAccess.getRobotRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRobot"


    // $ANTLR start "ruleRobot"
    // InternalSml.g:162:1: ruleRobot : ( ( rule__Robot__Alternatives ) ) ;
    public final void ruleRobot() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:166:2: ( ( ( rule__Robot__Alternatives ) ) )
            // InternalSml.g:167:2: ( ( rule__Robot__Alternatives ) )
            {
            // InternalSml.g:167:2: ( ( rule__Robot__Alternatives ) )
            // InternalSml.g:168:3: ( rule__Robot__Alternatives )
            {
             before(grammarAccess.getRobotAccess().getAlternatives()); 
            // InternalSml.g:169:3: ( rule__Robot__Alternatives )
            // InternalSml.g:169:4: rule__Robot__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Robot__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getRobotAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRobot"


    // $ANTLR start "entryRuleDistribution"
    // InternalSml.g:178:1: entryRuleDistribution : ruleDistribution EOF ;
    public final void entryRuleDistribution() throws RecognitionException {
        try {
            // InternalSml.g:179:1: ( ruleDistribution EOF )
            // InternalSml.g:180:1: ruleDistribution EOF
            {
             before(grammarAccess.getDistributionRule()); 
            pushFollow(FOLLOW_1);
            ruleDistribution();

            state._fsp--;

             after(grammarAccess.getDistributionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDistribution"


    // $ANTLR start "ruleDistribution"
    // InternalSml.g:187:1: ruleDistribution : ( ( rule__Distribution__Alternatives ) ) ;
    public final void ruleDistribution() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:191:2: ( ( ( rule__Distribution__Alternatives ) ) )
            // InternalSml.g:192:2: ( ( rule__Distribution__Alternatives ) )
            {
            // InternalSml.g:192:2: ( ( rule__Distribution__Alternatives ) )
            // InternalSml.g:193:3: ( rule__Distribution__Alternatives )
            {
             before(grammarAccess.getDistributionAccess().getAlternatives()); 
            // InternalSml.g:194:3: ( rule__Distribution__Alternatives )
            // InternalSml.g:194:4: rule__Distribution__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Distribution__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getDistributionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDistribution"


    // $ANTLR start "entryRuleEnvironmentElements"
    // InternalSml.g:203:1: entryRuleEnvironmentElements : ruleEnvironmentElements EOF ;
    public final void entryRuleEnvironmentElements() throws RecognitionException {
        try {
            // InternalSml.g:204:1: ( ruleEnvironmentElements EOF )
            // InternalSml.g:205:1: ruleEnvironmentElements EOF
            {
             before(grammarAccess.getEnvironmentElementsRule()); 
            pushFollow(FOLLOW_1);
            ruleEnvironmentElements();

            state._fsp--;

             after(grammarAccess.getEnvironmentElementsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEnvironmentElements"


    // $ANTLR start "ruleEnvironmentElements"
    // InternalSml.g:212:1: ruleEnvironmentElements : ( ( rule__EnvironmentElements__Group__0 ) ) ;
    public final void ruleEnvironmentElements() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:216:2: ( ( ( rule__EnvironmentElements__Group__0 ) ) )
            // InternalSml.g:217:2: ( ( rule__EnvironmentElements__Group__0 ) )
            {
            // InternalSml.g:217:2: ( ( rule__EnvironmentElements__Group__0 ) )
            // InternalSml.g:218:3: ( rule__EnvironmentElements__Group__0 )
            {
             before(grammarAccess.getEnvironmentElementsAccess().getGroup()); 
            // InternalSml.g:219:3: ( rule__EnvironmentElements__Group__0 )
            // InternalSml.g:219:4: rule__EnvironmentElements__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EnvironmentElements__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEnvironmentElementsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEnvironmentElements"


    // $ANTLR start "entryRuleEnvironmentElement"
    // InternalSml.g:228:1: entryRuleEnvironmentElement : ruleEnvironmentElement EOF ;
    public final void entryRuleEnvironmentElement() throws RecognitionException {
        try {
            // InternalSml.g:229:1: ( ruleEnvironmentElement EOF )
            // InternalSml.g:230:1: ruleEnvironmentElement EOF
            {
             before(grammarAccess.getEnvironmentElementRule()); 
            pushFollow(FOLLOW_1);
            ruleEnvironmentElement();

            state._fsp--;

             after(grammarAccess.getEnvironmentElementRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEnvironmentElement"


    // $ANTLR start "ruleEnvironmentElement"
    // InternalSml.g:237:1: ruleEnvironmentElement : ( ( rule__EnvironmentElement__Alternatives ) ) ;
    public final void ruleEnvironmentElement() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:241:2: ( ( ( rule__EnvironmentElement__Alternatives ) ) )
            // InternalSml.g:242:2: ( ( rule__EnvironmentElement__Alternatives ) )
            {
            // InternalSml.g:242:2: ( ( rule__EnvironmentElement__Alternatives ) )
            // InternalSml.g:243:3: ( rule__EnvironmentElement__Alternatives )
            {
             before(grammarAccess.getEnvironmentElementAccess().getAlternatives()); 
            // InternalSml.g:244:3: ( rule__EnvironmentElement__Alternatives )
            // InternalSml.g:244:4: rule__EnvironmentElement__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EnvironmentElement__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEnvironmentElementAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEnvironmentElement"


    // $ANTLR start "entryRuleElementDescription"
    // InternalSml.g:253:1: entryRuleElementDescription : ruleElementDescription EOF ;
    public final void entryRuleElementDescription() throws RecognitionException {
        try {
            // InternalSml.g:254:1: ( ruleElementDescription EOF )
            // InternalSml.g:255:1: ruleElementDescription EOF
            {
             before(grammarAccess.getElementDescriptionRule()); 
            pushFollow(FOLLOW_1);
            ruleElementDescription();

            state._fsp--;

             after(grammarAccess.getElementDescriptionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleElementDescription"


    // $ANTLR start "ruleElementDescription"
    // InternalSml.g:262:1: ruleElementDescription : ( ( rule__ElementDescription__Group__0 ) ) ;
    public final void ruleElementDescription() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:266:2: ( ( ( rule__ElementDescription__Group__0 ) ) )
            // InternalSml.g:267:2: ( ( rule__ElementDescription__Group__0 ) )
            {
            // InternalSml.g:267:2: ( ( rule__ElementDescription__Group__0 ) )
            // InternalSml.g:268:3: ( rule__ElementDescription__Group__0 )
            {
             before(grammarAccess.getElementDescriptionAccess().getGroup()); 
            // InternalSml.g:269:3: ( rule__ElementDescription__Group__0 )
            // InternalSml.g:269:4: rule__ElementDescription__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ElementDescription__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getElementDescriptionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleElementDescription"


    // $ANTLR start "entryRuleElement"
    // InternalSml.g:278:1: entryRuleElement : ruleElement EOF ;
    public final void entryRuleElement() throws RecognitionException {
        try {
            // InternalSml.g:279:1: ( ruleElement EOF )
            // InternalSml.g:280:1: ruleElement EOF
            {
             before(grammarAccess.getElementRule()); 
            pushFollow(FOLLOW_1);
            ruleElement();

            state._fsp--;

             after(grammarAccess.getElementRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleElement"


    // $ANTLR start "ruleElement"
    // InternalSml.g:287:1: ruleElement : ( ( rule__Element__Alternatives ) ) ;
    public final void ruleElement() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:291:2: ( ( ( rule__Element__Alternatives ) ) )
            // InternalSml.g:292:2: ( ( rule__Element__Alternatives ) )
            {
            // InternalSml.g:292:2: ( ( rule__Element__Alternatives ) )
            // InternalSml.g:293:3: ( rule__Element__Alternatives )
            {
             before(grammarAccess.getElementAccess().getAlternatives()); 
            // InternalSml.g:294:3: ( rule__Element__Alternatives )
            // InternalSml.g:294:4: rule__Element__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Element__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getElementAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleElement"


    // $ANTLR start "entryRuleObject"
    // InternalSml.g:303:1: entryRuleObject : ruleObject EOF ;
    public final void entryRuleObject() throws RecognitionException {
        try {
            // InternalSml.g:304:1: ( ruleObject EOF )
            // InternalSml.g:305:1: ruleObject EOF
            {
             before(grammarAccess.getObjectRule()); 
            pushFollow(FOLLOW_1);
            ruleObject();

            state._fsp--;

             after(grammarAccess.getObjectRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleObject"


    // $ANTLR start "ruleObject"
    // InternalSml.g:312:1: ruleObject : ( ( rule__Object__Group__0 ) ) ;
    public final void ruleObject() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:316:2: ( ( ( rule__Object__Group__0 ) ) )
            // InternalSml.g:317:2: ( ( rule__Object__Group__0 ) )
            {
            // InternalSml.g:317:2: ( ( rule__Object__Group__0 ) )
            // InternalSml.g:318:3: ( rule__Object__Group__0 )
            {
             before(grammarAccess.getObjectAccess().getGroup()); 
            // InternalSml.g:319:3: ( rule__Object__Group__0 )
            // InternalSml.g:319:4: rule__Object__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Object__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getObjectAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleObject"


    // $ANTLR start "entryRuleObstacle"
    // InternalSml.g:328:1: entryRuleObstacle : ruleObstacle EOF ;
    public final void entryRuleObstacle() throws RecognitionException {
        try {
            // InternalSml.g:329:1: ( ruleObstacle EOF )
            // InternalSml.g:330:1: ruleObstacle EOF
            {
             before(grammarAccess.getObstacleRule()); 
            pushFollow(FOLLOW_1);
            ruleObstacle();

            state._fsp--;

             after(grammarAccess.getObstacleRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleObstacle"


    // $ANTLR start "ruleObstacle"
    // InternalSml.g:337:1: ruleObstacle : ( ( rule__Obstacle__Group__0 ) ) ;
    public final void ruleObstacle() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:341:2: ( ( ( rule__Obstacle__Group__0 ) ) )
            // InternalSml.g:342:2: ( ( rule__Obstacle__Group__0 ) )
            {
            // InternalSml.g:342:2: ( ( rule__Obstacle__Group__0 ) )
            // InternalSml.g:343:3: ( rule__Obstacle__Group__0 )
            {
             before(grammarAccess.getObstacleAccess().getGroup()); 
            // InternalSml.g:344:3: ( rule__Obstacle__Group__0 )
            // InternalSml.g:344:4: rule__Obstacle__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Obstacle__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getObstacleAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleObstacle"


    // $ANTLR start "entryRuleLight"
    // InternalSml.g:353:1: entryRuleLight : ruleLight EOF ;
    public final void entryRuleLight() throws RecognitionException {
        try {
            // InternalSml.g:354:1: ( ruleLight EOF )
            // InternalSml.g:355:1: ruleLight EOF
            {
             before(grammarAccess.getLightRule()); 
            pushFollow(FOLLOW_1);
            ruleLight();

            state._fsp--;

             after(grammarAccess.getLightRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLight"


    // $ANTLR start "ruleLight"
    // InternalSml.g:362:1: ruleLight : ( ( rule__Light__Group__0 ) ) ;
    public final void ruleLight() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:366:2: ( ( ( rule__Light__Group__0 ) ) )
            // InternalSml.g:367:2: ( ( rule__Light__Group__0 ) )
            {
            // InternalSml.g:367:2: ( ( rule__Light__Group__0 ) )
            // InternalSml.g:368:3: ( rule__Light__Group__0 )
            {
             before(grammarAccess.getLightAccess().getGroup()); 
            // InternalSml.g:369:3: ( rule__Light__Group__0 )
            // InternalSml.g:369:4: rule__Light__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Light__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLightAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLight"


    // $ANTLR start "entryRulePosition"
    // InternalSml.g:378:1: entryRulePosition : rulePosition EOF ;
    public final void entryRulePosition() throws RecognitionException {
        try {
            // InternalSml.g:379:1: ( rulePosition EOF )
            // InternalSml.g:380:1: rulePosition EOF
            {
             before(grammarAccess.getPositionRule()); 
            pushFollow(FOLLOW_1);
            rulePosition();

            state._fsp--;

             after(grammarAccess.getPositionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePosition"


    // $ANTLR start "rulePosition"
    // InternalSml.g:387:1: rulePosition : ( ( rule__Position__Alternatives ) ) ;
    public final void rulePosition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:391:2: ( ( ( rule__Position__Alternatives ) ) )
            // InternalSml.g:392:2: ( ( rule__Position__Alternatives ) )
            {
            // InternalSml.g:392:2: ( ( rule__Position__Alternatives ) )
            // InternalSml.g:393:3: ( rule__Position__Alternatives )
            {
             before(grammarAccess.getPositionAccess().getAlternatives()); 
            // InternalSml.g:394:3: ( rule__Position__Alternatives )
            // InternalSml.g:394:4: rule__Position__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Position__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getPositionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePosition"


    // $ANTLR start "entryRuleShape"
    // InternalSml.g:403:1: entryRuleShape : ruleShape EOF ;
    public final void entryRuleShape() throws RecognitionException {
        try {
            // InternalSml.g:404:1: ( ruleShape EOF )
            // InternalSml.g:405:1: ruleShape EOF
            {
             before(grammarAccess.getShapeRule()); 
            pushFollow(FOLLOW_1);
            ruleShape();

            state._fsp--;

             after(grammarAccess.getShapeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleShape"


    // $ANTLR start "ruleShape"
    // InternalSml.g:412:1: ruleShape : ( ( rule__Shape__Alternatives ) ) ;
    public final void ruleShape() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:416:2: ( ( ( rule__Shape__Alternatives ) ) )
            // InternalSml.g:417:2: ( ( rule__Shape__Alternatives ) )
            {
            // InternalSml.g:417:2: ( ( rule__Shape__Alternatives ) )
            // InternalSml.g:418:3: ( rule__Shape__Alternatives )
            {
             before(grammarAccess.getShapeAccess().getAlternatives()); 
            // InternalSml.g:419:3: ( rule__Shape__Alternatives )
            // InternalSml.g:419:4: rule__Shape__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Shape__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getShapeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleShape"


    // $ANTLR start "entryRuleArena"
    // InternalSml.g:428:1: entryRuleArena : ruleArena EOF ;
    public final void entryRuleArena() throws RecognitionException {
        try {
            // InternalSml.g:429:1: ( ruleArena EOF )
            // InternalSml.g:430:1: ruleArena EOF
            {
             before(grammarAccess.getArenaRule()); 
            pushFollow(FOLLOW_1);
            ruleArena();

            state._fsp--;

             after(grammarAccess.getArenaRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleArena"


    // $ANTLR start "ruleArena"
    // InternalSml.g:437:1: ruleArena : ( ( rule__Arena__Group__0 ) ) ;
    public final void ruleArena() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:441:2: ( ( ( rule__Arena__Group__0 ) ) )
            // InternalSml.g:442:2: ( ( rule__Arena__Group__0 ) )
            {
            // InternalSml.g:442:2: ( ( rule__Arena__Group__0 ) )
            // InternalSml.g:443:3: ( rule__Arena__Group__0 )
            {
             before(grammarAccess.getArenaAccess().getGroup()); 
            // InternalSml.g:444:3: ( rule__Arena__Group__0 )
            // InternalSml.g:444:4: rule__Arena__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Arena__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getArenaAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArena"


    // $ANTLR start "entryRuleColor"
    // InternalSml.g:453:1: entryRuleColor : ruleColor EOF ;
    public final void entryRuleColor() throws RecognitionException {
        try {
            // InternalSml.g:454:1: ( ruleColor EOF )
            // InternalSml.g:455:1: ruleColor EOF
            {
             before(grammarAccess.getColorRule()); 
            pushFollow(FOLLOW_1);
            ruleColor();

            state._fsp--;

             after(grammarAccess.getColorRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleColor"


    // $ANTLR start "ruleColor"
    // InternalSml.g:462:1: ruleColor : ( ( rule__Color__Alternatives ) ) ;
    public final void ruleColor() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:466:2: ( ( ( rule__Color__Alternatives ) ) )
            // InternalSml.g:467:2: ( ( rule__Color__Alternatives ) )
            {
            // InternalSml.g:467:2: ( ( rule__Color__Alternatives ) )
            // InternalSml.g:468:3: ( rule__Color__Alternatives )
            {
             before(grammarAccess.getColorAccess().getAlternatives()); 
            // InternalSml.g:469:3: ( rule__Color__Alternatives )
            // InternalSml.g:469:4: rule__Color__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Color__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getColorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleColor"


    // $ANTLR start "entryRuleRegion"
    // InternalSml.g:478:1: entryRuleRegion : ruleRegion EOF ;
    public final void entryRuleRegion() throws RecognitionException {
        try {
            // InternalSml.g:479:1: ( ruleRegion EOF )
            // InternalSml.g:480:1: ruleRegion EOF
            {
             before(grammarAccess.getRegionRule()); 
            pushFollow(FOLLOW_1);
            ruleRegion();

            state._fsp--;

             after(grammarAccess.getRegionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRegion"


    // $ANTLR start "ruleRegion"
    // InternalSml.g:487:1: ruleRegion : ( ( rule__Region__Group__0 ) ) ;
    public final void ruleRegion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:491:2: ( ( ( rule__Region__Group__0 ) ) )
            // InternalSml.g:492:2: ( ( rule__Region__Group__0 ) )
            {
            // InternalSml.g:492:2: ( ( rule__Region__Group__0 ) )
            // InternalSml.g:493:3: ( rule__Region__Group__0 )
            {
             before(grammarAccess.getRegionAccess().getGroup()); 
            // InternalSml.g:494:3: ( rule__Region__Group__0 )
            // InternalSml.g:494:4: rule__Region__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Region__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRegionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRegion"


    // $ANTLR start "entryRuleDimension"
    // InternalSml.g:503:1: entryRuleDimension : ruleDimension EOF ;
    public final void entryRuleDimension() throws RecognitionException {
        try {
            // InternalSml.g:504:1: ( ruleDimension EOF )
            // InternalSml.g:505:1: ruleDimension EOF
            {
             before(grammarAccess.getDimensionRule()); 
            pushFollow(FOLLOW_1);
            ruleDimension();

            state._fsp--;

             after(grammarAccess.getDimensionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDimension"


    // $ANTLR start "ruleDimension"
    // InternalSml.g:512:1: ruleDimension : ( ( rule__Dimension__Alternatives ) ) ;
    public final void ruleDimension() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:516:2: ( ( ( rule__Dimension__Alternatives ) ) )
            // InternalSml.g:517:2: ( ( rule__Dimension__Alternatives ) )
            {
            // InternalSml.g:517:2: ( ( rule__Dimension__Alternatives ) )
            // InternalSml.g:518:3: ( rule__Dimension__Alternatives )
            {
             before(grammarAccess.getDimensionAccess().getAlternatives()); 
            // InternalSml.g:519:3: ( rule__Dimension__Alternatives )
            // InternalSml.g:519:4: rule__Dimension__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Dimension__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getDimensionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDimension"


    // $ANTLR start "entryRuleCircleD"
    // InternalSml.g:528:1: entryRuleCircleD : ruleCircleD EOF ;
    public final void entryRuleCircleD() throws RecognitionException {
        try {
            // InternalSml.g:529:1: ( ruleCircleD EOF )
            // InternalSml.g:530:1: ruleCircleD EOF
            {
             before(grammarAccess.getCircleDRule()); 
            pushFollow(FOLLOW_1);
            ruleCircleD();

            state._fsp--;

             after(grammarAccess.getCircleDRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCircleD"


    // $ANTLR start "ruleCircleD"
    // InternalSml.g:537:1: ruleCircleD : ( ( rule__CircleD__Group__0 ) ) ;
    public final void ruleCircleD() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:541:2: ( ( ( rule__CircleD__Group__0 ) ) )
            // InternalSml.g:542:2: ( ( rule__CircleD__Group__0 ) )
            {
            // InternalSml.g:542:2: ( ( rule__CircleD__Group__0 ) )
            // InternalSml.g:543:3: ( rule__CircleD__Group__0 )
            {
             before(grammarAccess.getCircleDAccess().getGroup()); 
            // InternalSml.g:544:3: ( rule__CircleD__Group__0 )
            // InternalSml.g:544:4: rule__CircleD__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__CircleD__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCircleDAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCircleD"


    // $ANTLR start "entryRuleRectangleD"
    // InternalSml.g:553:1: entryRuleRectangleD : ruleRectangleD EOF ;
    public final void entryRuleRectangleD() throws RecognitionException {
        try {
            // InternalSml.g:554:1: ( ruleRectangleD EOF )
            // InternalSml.g:555:1: ruleRectangleD EOF
            {
             before(grammarAccess.getRectangleDRule()); 
            pushFollow(FOLLOW_1);
            ruleRectangleD();

            state._fsp--;

             after(grammarAccess.getRectangleDRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRectangleD"


    // $ANTLR start "ruleRectangleD"
    // InternalSml.g:562:1: ruleRectangleD : ( ( rule__RectangleD__Group__0 ) ) ;
    public final void ruleRectangleD() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:566:2: ( ( ( rule__RectangleD__Group__0 ) ) )
            // InternalSml.g:567:2: ( ( rule__RectangleD__Group__0 ) )
            {
            // InternalSml.g:567:2: ( ( rule__RectangleD__Group__0 ) )
            // InternalSml.g:568:3: ( rule__RectangleD__Group__0 )
            {
             before(grammarAccess.getRectangleDAccess().getGroup()); 
            // InternalSml.g:569:3: ( rule__RectangleD__Group__0 )
            // InternalSml.g:569:4: rule__RectangleD__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__RectangleD__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRectangleDAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRectangleD"


    // $ANTLR start "entryRuleCoordinate"
    // InternalSml.g:578:1: entryRuleCoordinate : ruleCoordinate EOF ;
    public final void entryRuleCoordinate() throws RecognitionException {
        try {
            // InternalSml.g:579:1: ( ruleCoordinate EOF )
            // InternalSml.g:580:1: ruleCoordinate EOF
            {
             before(grammarAccess.getCoordinateRule()); 
            pushFollow(FOLLOW_1);
            ruleCoordinate();

            state._fsp--;

             after(grammarAccess.getCoordinateRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCoordinate"


    // $ANTLR start "ruleCoordinate"
    // InternalSml.g:587:1: ruleCoordinate : ( ( rule__Coordinate__Group__0 ) ) ;
    public final void ruleCoordinate() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:591:2: ( ( ( rule__Coordinate__Group__0 ) ) )
            // InternalSml.g:592:2: ( ( rule__Coordinate__Group__0 ) )
            {
            // InternalSml.g:592:2: ( ( rule__Coordinate__Group__0 ) )
            // InternalSml.g:593:3: ( rule__Coordinate__Group__0 )
            {
             before(grammarAccess.getCoordinateAccess().getGroup()); 
            // InternalSml.g:594:3: ( rule__Coordinate__Group__0 )
            // InternalSml.g:594:4: rule__Coordinate__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Coordinate__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCoordinateAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCoordinate"


    // $ANTLR start "entryRuleDouble"
    // InternalSml.g:603:1: entryRuleDouble : ruleDouble EOF ;
    public final void entryRuleDouble() throws RecognitionException {
        try {
            // InternalSml.g:604:1: ( ruleDouble EOF )
            // InternalSml.g:605:1: ruleDouble EOF
            {
             before(grammarAccess.getDoubleRule()); 
            pushFollow(FOLLOW_1);
            ruleDouble();

            state._fsp--;

             after(grammarAccess.getDoubleRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDouble"


    // $ANTLR start "ruleDouble"
    // InternalSml.g:612:1: ruleDouble : ( ( rule__Double__Group__0 ) ) ;
    public final void ruleDouble() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:616:2: ( ( ( rule__Double__Group__0 ) ) )
            // InternalSml.g:617:2: ( ( rule__Double__Group__0 ) )
            {
            // InternalSml.g:617:2: ( ( rule__Double__Group__0 ) )
            // InternalSml.g:618:3: ( rule__Double__Group__0 )
            {
             before(grammarAccess.getDoubleAccess().getGroup()); 
            // InternalSml.g:619:3: ( rule__Double__Group__0 )
            // InternalSml.g:619:4: rule__Double__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Double__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDoubleAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDouble"


    // $ANTLR start "entryRuleRange"
    // InternalSml.g:628:1: entryRuleRange : ruleRange EOF ;
    public final void entryRuleRange() throws RecognitionException {
        try {
            // InternalSml.g:629:1: ( ruleRange EOF )
            // InternalSml.g:630:1: ruleRange EOF
            {
             before(grammarAccess.getRangeRule()); 
            pushFollow(FOLLOW_1);
            ruleRange();

            state._fsp--;

             after(grammarAccess.getRangeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRange"


    // $ANTLR start "ruleRange"
    // InternalSml.g:637:1: ruleRange : ( ( rule__Range__Alternatives ) ) ;
    public final void ruleRange() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:641:2: ( ( ( rule__Range__Alternatives ) ) )
            // InternalSml.g:642:2: ( ( rule__Range__Alternatives ) )
            {
            // InternalSml.g:642:2: ( ( rule__Range__Alternatives ) )
            // InternalSml.g:643:3: ( rule__Range__Alternatives )
            {
             before(grammarAccess.getRangeAccess().getAlternatives()); 
            // InternalSml.g:644:3: ( rule__Range__Alternatives )
            // InternalSml.g:644:4: rule__Range__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Range__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getRangeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRange"


    // $ANTLR start "entryRuleConstantSize"
    // InternalSml.g:653:1: entryRuleConstantSize : ruleConstantSize EOF ;
    public final void entryRuleConstantSize() throws RecognitionException {
        try {
            // InternalSml.g:654:1: ( ruleConstantSize EOF )
            // InternalSml.g:655:1: ruleConstantSize EOF
            {
             before(grammarAccess.getConstantSizeRule()); 
            pushFollow(FOLLOW_1);
            ruleConstantSize();

            state._fsp--;

             after(grammarAccess.getConstantSizeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleConstantSize"


    // $ANTLR start "ruleConstantSize"
    // InternalSml.g:662:1: ruleConstantSize : ( ( rule__ConstantSize__NAssignment ) ) ;
    public final void ruleConstantSize() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:666:2: ( ( ( rule__ConstantSize__NAssignment ) ) )
            // InternalSml.g:667:2: ( ( rule__ConstantSize__NAssignment ) )
            {
            // InternalSml.g:667:2: ( ( rule__ConstantSize__NAssignment ) )
            // InternalSml.g:668:3: ( rule__ConstantSize__NAssignment )
            {
             before(grammarAccess.getConstantSizeAccess().getNAssignment()); 
            // InternalSml.g:669:3: ( rule__ConstantSize__NAssignment )
            // InternalSml.g:669:4: rule__ConstantSize__NAssignment
            {
            pushFollow(FOLLOW_2);
            rule__ConstantSize__NAssignment();

            state._fsp--;


            }

             after(grammarAccess.getConstantSizeAccess().getNAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleConstantSize"


    // $ANTLR start "entryRuleLowerbound"
    // InternalSml.g:678:1: entryRuleLowerbound : ruleLowerbound EOF ;
    public final void entryRuleLowerbound() throws RecognitionException {
        try {
            // InternalSml.g:679:1: ( ruleLowerbound EOF )
            // InternalSml.g:680:1: ruleLowerbound EOF
            {
             before(grammarAccess.getLowerboundRule()); 
            pushFollow(FOLLOW_1);
            ruleLowerbound();

            state._fsp--;

             after(grammarAccess.getLowerboundRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLowerbound"


    // $ANTLR start "ruleLowerbound"
    // InternalSml.g:687:1: ruleLowerbound : ( ( rule__Lowerbound__Group__0 ) ) ;
    public final void ruleLowerbound() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:691:2: ( ( ( rule__Lowerbound__Group__0 ) ) )
            // InternalSml.g:692:2: ( ( rule__Lowerbound__Group__0 ) )
            {
            // InternalSml.g:692:2: ( ( rule__Lowerbound__Group__0 ) )
            // InternalSml.g:693:3: ( rule__Lowerbound__Group__0 )
            {
             before(grammarAccess.getLowerboundAccess().getGroup()); 
            // InternalSml.g:694:3: ( rule__Lowerbound__Group__0 )
            // InternalSml.g:694:4: rule__Lowerbound__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Lowerbound__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLowerboundAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLowerbound"


    // $ANTLR start "entryRuleLowerorEqualbound"
    // InternalSml.g:703:1: entryRuleLowerorEqualbound : ruleLowerorEqualbound EOF ;
    public final void entryRuleLowerorEqualbound() throws RecognitionException {
        try {
            // InternalSml.g:704:1: ( ruleLowerorEqualbound EOF )
            // InternalSml.g:705:1: ruleLowerorEqualbound EOF
            {
             before(grammarAccess.getLowerorEqualboundRule()); 
            pushFollow(FOLLOW_1);
            ruleLowerorEqualbound();

            state._fsp--;

             after(grammarAccess.getLowerorEqualboundRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLowerorEqualbound"


    // $ANTLR start "ruleLowerorEqualbound"
    // InternalSml.g:712:1: ruleLowerorEqualbound : ( ( rule__LowerorEqualbound__Group__0 ) ) ;
    public final void ruleLowerorEqualbound() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:716:2: ( ( ( rule__LowerorEqualbound__Group__0 ) ) )
            // InternalSml.g:717:2: ( ( rule__LowerorEqualbound__Group__0 ) )
            {
            // InternalSml.g:717:2: ( ( rule__LowerorEqualbound__Group__0 ) )
            // InternalSml.g:718:3: ( rule__LowerorEqualbound__Group__0 )
            {
             before(grammarAccess.getLowerorEqualboundAccess().getGroup()); 
            // InternalSml.g:719:3: ( rule__LowerorEqualbound__Group__0 )
            // InternalSml.g:719:4: rule__LowerorEqualbound__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__LowerorEqualbound__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLowerorEqualboundAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLowerorEqualbound"


    // $ANTLR start "entryRuleUpperbound"
    // InternalSml.g:728:1: entryRuleUpperbound : ruleUpperbound EOF ;
    public final void entryRuleUpperbound() throws RecognitionException {
        try {
            // InternalSml.g:729:1: ( ruleUpperbound EOF )
            // InternalSml.g:730:1: ruleUpperbound EOF
            {
             before(grammarAccess.getUpperboundRule()); 
            pushFollow(FOLLOW_1);
            ruleUpperbound();

            state._fsp--;

             after(grammarAccess.getUpperboundRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUpperbound"


    // $ANTLR start "ruleUpperbound"
    // InternalSml.g:737:1: ruleUpperbound : ( ( rule__Upperbound__Group__0 ) ) ;
    public final void ruleUpperbound() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:741:2: ( ( ( rule__Upperbound__Group__0 ) ) )
            // InternalSml.g:742:2: ( ( rule__Upperbound__Group__0 ) )
            {
            // InternalSml.g:742:2: ( ( rule__Upperbound__Group__0 ) )
            // InternalSml.g:743:3: ( rule__Upperbound__Group__0 )
            {
             before(grammarAccess.getUpperboundAccess().getGroup()); 
            // InternalSml.g:744:3: ( rule__Upperbound__Group__0 )
            // InternalSml.g:744:4: rule__Upperbound__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Upperbound__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getUpperboundAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUpperbound"


    // $ANTLR start "entryRuleUpperorEqualbound"
    // InternalSml.g:753:1: entryRuleUpperorEqualbound : ruleUpperorEqualbound EOF ;
    public final void entryRuleUpperorEqualbound() throws RecognitionException {
        try {
            // InternalSml.g:754:1: ( ruleUpperorEqualbound EOF )
            // InternalSml.g:755:1: ruleUpperorEqualbound EOF
            {
             before(grammarAccess.getUpperorEqualboundRule()); 
            pushFollow(FOLLOW_1);
            ruleUpperorEqualbound();

            state._fsp--;

             after(grammarAccess.getUpperorEqualboundRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUpperorEqualbound"


    // $ANTLR start "ruleUpperorEqualbound"
    // InternalSml.g:762:1: ruleUpperorEqualbound : ( ( rule__UpperorEqualbound__Group__0 ) ) ;
    public final void ruleUpperorEqualbound() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:766:2: ( ( ( rule__UpperorEqualbound__Group__0 ) ) )
            // InternalSml.g:767:2: ( ( rule__UpperorEqualbound__Group__0 ) )
            {
            // InternalSml.g:767:2: ( ( rule__UpperorEqualbound__Group__0 ) )
            // InternalSml.g:768:3: ( rule__UpperorEqualbound__Group__0 )
            {
             before(grammarAccess.getUpperorEqualboundAccess().getGroup()); 
            // InternalSml.g:769:3: ( rule__UpperorEqualbound__Group__0 )
            // InternalSml.g:769:4: rule__UpperorEqualbound__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__UpperorEqualbound__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getUpperorEqualboundAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUpperorEqualbound"


    // $ANTLR start "entryRuleInterval"
    // InternalSml.g:778:1: entryRuleInterval : ruleInterval EOF ;
    public final void entryRuleInterval() throws RecognitionException {
        try {
            // InternalSml.g:779:1: ( ruleInterval EOF )
            // InternalSml.g:780:1: ruleInterval EOF
            {
             before(grammarAccess.getIntervalRule()); 
            pushFollow(FOLLOW_1);
            ruleInterval();

            state._fsp--;

             after(grammarAccess.getIntervalRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInterval"


    // $ANTLR start "ruleInterval"
    // InternalSml.g:787:1: ruleInterval : ( ( rule__Interval__Group__0 ) ) ;
    public final void ruleInterval() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:791:2: ( ( ( rule__Interval__Group__0 ) ) )
            // InternalSml.g:792:2: ( ( rule__Interval__Group__0 ) )
            {
            // InternalSml.g:792:2: ( ( rule__Interval__Group__0 ) )
            // InternalSml.g:793:3: ( rule__Interval__Group__0 )
            {
             before(grammarAccess.getIntervalAccess().getGroup()); 
            // InternalSml.g:794:3: ( rule__Interval__Group__0 )
            // InternalSml.g:794:4: rule__Interval__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Interval__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getIntervalAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInterval"


    // $ANTLR start "rule__Robot__Alternatives"
    // InternalSml.g:802:1: rule__Robot__Alternatives : ( ( 'e-puck' ) | ( 'footboot' ) );
    public final void rule__Robot__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:806:1: ( ( 'e-puck' ) | ( 'footboot' ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==11) ) {
                alt1=1;
            }
            else if ( (LA1_0==12) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalSml.g:807:2: ( 'e-puck' )
                    {
                    // InternalSml.g:807:2: ( 'e-puck' )
                    // InternalSml.g:808:3: 'e-puck'
                    {
                     before(grammarAccess.getRobotAccess().getEPuckKeyword_0()); 
                    match(input,11,FOLLOW_2); 
                     after(grammarAccess.getRobotAccess().getEPuckKeyword_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSml.g:813:2: ( 'footboot' )
                    {
                    // InternalSml.g:813:2: ( 'footboot' )
                    // InternalSml.g:814:3: 'footboot'
                    {
                     before(grammarAccess.getRobotAccess().getFootbootKeyword_1()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getRobotAccess().getFootbootKeyword_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Robot__Alternatives"


    // $ANTLR start "rule__Distribution__Alternatives"
    // InternalSml.g:823:1: rule__Distribution__Alternatives : ( ( 'uniform' ) | ( 'gaussian' ) | ( 'constant' ) );
    public final void rule__Distribution__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:827:1: ( ( 'uniform' ) | ( 'gaussian' ) | ( 'constant' ) )
            int alt2=3;
            switch ( input.LA(1) ) {
            case 13:
                {
                alt2=1;
                }
                break;
            case 14:
                {
                alt2=2;
                }
                break;
            case 15:
                {
                alt2=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalSml.g:828:2: ( 'uniform' )
                    {
                    // InternalSml.g:828:2: ( 'uniform' )
                    // InternalSml.g:829:3: 'uniform'
                    {
                     before(grammarAccess.getDistributionAccess().getUniformKeyword_0()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getDistributionAccess().getUniformKeyword_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSml.g:834:2: ( 'gaussian' )
                    {
                    // InternalSml.g:834:2: ( 'gaussian' )
                    // InternalSml.g:835:3: 'gaussian'
                    {
                     before(grammarAccess.getDistributionAccess().getGaussianKeyword_1()); 
                    match(input,14,FOLLOW_2); 
                     after(grammarAccess.getDistributionAccess().getGaussianKeyword_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSml.g:840:2: ( 'constant' )
                    {
                    // InternalSml.g:840:2: ( 'constant' )
                    // InternalSml.g:841:3: 'constant'
                    {
                     before(grammarAccess.getDistributionAccess().getConstantKeyword_2()); 
                    match(input,15,FOLLOW_2); 
                     after(grammarAccess.getDistributionAccess().getConstantKeyword_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distribution__Alternatives"


    // $ANTLR start "rule__EnvironmentElement__Alternatives"
    // InternalSml.g:850:1: rule__EnvironmentElement__Alternatives : ( ( ruleObstacle ) | ( ruleLight ) | ( ruleObject ) );
    public final void rule__EnvironmentElement__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:854:1: ( ( ruleObstacle ) | ( ruleLight ) | ( ruleObject ) )
            int alt3=3;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==67) ) {
                int LA3_1 = input.LA(2);

                if ( (LA3_1==46) ) {
                    alt3=1;
                }
                else if ( (LA3_1==44) ) {
                    alt3=3;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA3_0==68) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalSml.g:855:2: ( ruleObstacle )
                    {
                    // InternalSml.g:855:2: ( ruleObstacle )
                    // InternalSml.g:856:3: ruleObstacle
                    {
                     before(grammarAccess.getEnvironmentElementAccess().getObstacleParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleObstacle();

                    state._fsp--;

                     after(grammarAccess.getEnvironmentElementAccess().getObstacleParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSml.g:861:2: ( ruleLight )
                    {
                    // InternalSml.g:861:2: ( ruleLight )
                    // InternalSml.g:862:3: ruleLight
                    {
                     before(grammarAccess.getEnvironmentElementAccess().getLightParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleLight();

                    state._fsp--;

                     after(grammarAccess.getEnvironmentElementAccess().getLightParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSml.g:867:2: ( ruleObject )
                    {
                    // InternalSml.g:867:2: ( ruleObject )
                    // InternalSml.g:868:3: ruleObject
                    {
                     before(grammarAccess.getEnvironmentElementAccess().getObjectParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleObject();

                    state._fsp--;

                     after(grammarAccess.getEnvironmentElementAccess().getObjectParserRuleCall_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnvironmentElement__Alternatives"


    // $ANTLR start "rule__Element__Alternatives"
    // InternalSml.g:877:1: rule__Element__Alternatives : ( ( 'objects' ) | ( 'obstacles' ) | ( ( rule__Element__Group_2__0 ) ) );
    public final void rule__Element__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:881:1: ( ( 'objects' ) | ( 'obstacles' ) | ( ( rule__Element__Group_2__0 ) ) )
            int alt4=3;
            switch ( input.LA(1) ) {
            case 16:
                {
                alt4=1;
                }
                break;
            case 17:
                {
                alt4=2;
                }
                break;
            case 42:
                {
                alt4=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // InternalSml.g:882:2: ( 'objects' )
                    {
                    // InternalSml.g:882:2: ( 'objects' )
                    // InternalSml.g:883:3: 'objects'
                    {
                     before(grammarAccess.getElementAccess().getObjectsKeyword_0()); 
                    match(input,16,FOLLOW_2); 
                     after(grammarAccess.getElementAccess().getObjectsKeyword_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSml.g:888:2: ( 'obstacles' )
                    {
                    // InternalSml.g:888:2: ( 'obstacles' )
                    // InternalSml.g:889:3: 'obstacles'
                    {
                     before(grammarAccess.getElementAccess().getObstaclesKeyword_1()); 
                    match(input,17,FOLLOW_2); 
                     after(grammarAccess.getElementAccess().getObstaclesKeyword_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSml.g:894:2: ( ( rule__Element__Group_2__0 ) )
                    {
                    // InternalSml.g:894:2: ( ( rule__Element__Group_2__0 ) )
                    // InternalSml.g:895:3: ( rule__Element__Group_2__0 )
                    {
                     before(grammarAccess.getElementAccess().getGroup_2()); 
                    // InternalSml.g:896:3: ( rule__Element__Group_2__0 )
                    // InternalSml.g:896:4: rule__Element__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Element__Group_2__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getElementAccess().getGroup_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Alternatives"


    // $ANTLR start "rule__Position__Alternatives"
    // InternalSml.g:904:1: rule__Position__Alternatives : ( ( ( rule__Position__Group_0__0 ) ) | ( ( rule__Position__Group_1__0 ) ) | ( ( rule__Position__Group_2__0 ) ) );
    public final void rule__Position__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:908:1: ( ( ( rule__Position__Group_0__0 ) ) | ( ( rule__Position__Group_1__0 ) ) | ( ( rule__Position__Group_2__0 ) ) )
            int alt5=3;
            switch ( input.LA(1) ) {
            case 51:
                {
                alt5=1;
                }
                break;
            case 52:
                {
                alt5=2;
                }
                break;
            case 53:
                {
                alt5=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalSml.g:909:2: ( ( rule__Position__Group_0__0 ) )
                    {
                    // InternalSml.g:909:2: ( ( rule__Position__Group_0__0 ) )
                    // InternalSml.g:910:3: ( rule__Position__Group_0__0 )
                    {
                     before(grammarAccess.getPositionAccess().getGroup_0()); 
                    // InternalSml.g:911:3: ( rule__Position__Group_0__0 )
                    // InternalSml.g:911:4: rule__Position__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Position__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPositionAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSml.g:915:2: ( ( rule__Position__Group_1__0 ) )
                    {
                    // InternalSml.g:915:2: ( ( rule__Position__Group_1__0 ) )
                    // InternalSml.g:916:3: ( rule__Position__Group_1__0 )
                    {
                     before(grammarAccess.getPositionAccess().getGroup_1()); 
                    // InternalSml.g:917:3: ( rule__Position__Group_1__0 )
                    // InternalSml.g:917:4: rule__Position__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Position__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPositionAccess().getGroup_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSml.g:921:2: ( ( rule__Position__Group_2__0 ) )
                    {
                    // InternalSml.g:921:2: ( ( rule__Position__Group_2__0 ) )
                    // InternalSml.g:922:3: ( rule__Position__Group_2__0 )
                    {
                     before(grammarAccess.getPositionAccess().getGroup_2()); 
                    // InternalSml.g:923:3: ( rule__Position__Group_2__0 )
                    // InternalSml.g:923:4: rule__Position__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Position__Group_2__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPositionAccess().getGroup_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Alternatives"


    // $ANTLR start "rule__Shape__Alternatives"
    // InternalSml.g:931:1: rule__Shape__Alternatives : ( ( 'Circle' ) | ( 'Polygon' ) | ( 'Triangle' ) | ( 'Rectangle' ) );
    public final void rule__Shape__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:935:1: ( ( 'Circle' ) | ( 'Polygon' ) | ( 'Triangle' ) | ( 'Rectangle' ) )
            int alt6=4;
            switch ( input.LA(1) ) {
            case 18:
                {
                alt6=1;
                }
                break;
            case 19:
                {
                alt6=2;
                }
                break;
            case 20:
                {
                alt6=3;
                }
                break;
            case 21:
                {
                alt6=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // InternalSml.g:936:2: ( 'Circle' )
                    {
                    // InternalSml.g:936:2: ( 'Circle' )
                    // InternalSml.g:937:3: 'Circle'
                    {
                     before(grammarAccess.getShapeAccess().getCircleKeyword_0()); 
                    match(input,18,FOLLOW_2); 
                     after(grammarAccess.getShapeAccess().getCircleKeyword_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSml.g:942:2: ( 'Polygon' )
                    {
                    // InternalSml.g:942:2: ( 'Polygon' )
                    // InternalSml.g:943:3: 'Polygon'
                    {
                     before(grammarAccess.getShapeAccess().getPolygonKeyword_1()); 
                    match(input,19,FOLLOW_2); 
                     after(grammarAccess.getShapeAccess().getPolygonKeyword_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSml.g:948:2: ( 'Triangle' )
                    {
                    // InternalSml.g:948:2: ( 'Triangle' )
                    // InternalSml.g:949:3: 'Triangle'
                    {
                     before(grammarAccess.getShapeAccess().getTriangleKeyword_2()); 
                    match(input,20,FOLLOW_2); 
                     after(grammarAccess.getShapeAccess().getTriangleKeyword_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSml.g:954:2: ( 'Rectangle' )
                    {
                    // InternalSml.g:954:2: ( 'Rectangle' )
                    // InternalSml.g:955:3: 'Rectangle'
                    {
                     before(grammarAccess.getShapeAccess().getRectangleKeyword_3()); 
                    match(input,21,FOLLOW_2); 
                     after(grammarAccess.getShapeAccess().getRectangleKeyword_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shape__Alternatives"


    // $ANTLR start "rule__Color__Alternatives"
    // InternalSml.g:964:1: rule__Color__Alternatives : ( ( 'red' ) | ( 'yellow' ) | ( 'green' ) );
    public final void rule__Color__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:968:1: ( ( 'red' ) | ( 'yellow' ) | ( 'green' ) )
            int alt7=3;
            switch ( input.LA(1) ) {
            case 22:
                {
                alt7=1;
                }
                break;
            case 23:
                {
                alt7=2;
                }
                break;
            case 24:
                {
                alt7=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // InternalSml.g:969:2: ( 'red' )
                    {
                    // InternalSml.g:969:2: ( 'red' )
                    // InternalSml.g:970:3: 'red'
                    {
                     before(grammarAccess.getColorAccess().getRedKeyword_0()); 
                    match(input,22,FOLLOW_2); 
                     after(grammarAccess.getColorAccess().getRedKeyword_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSml.g:975:2: ( 'yellow' )
                    {
                    // InternalSml.g:975:2: ( 'yellow' )
                    // InternalSml.g:976:3: 'yellow'
                    {
                     before(grammarAccess.getColorAccess().getYellowKeyword_1()); 
                    match(input,23,FOLLOW_2); 
                     after(grammarAccess.getColorAccess().getYellowKeyword_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSml.g:981:2: ( 'green' )
                    {
                    // InternalSml.g:981:2: ( 'green' )
                    // InternalSml.g:982:3: 'green'
                    {
                     before(grammarAccess.getColorAccess().getGreenKeyword_2()); 
                    match(input,24,FOLLOW_2); 
                     after(grammarAccess.getColorAccess().getGreenKeyword_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Color__Alternatives"


    // $ANTLR start "rule__Dimension__Alternatives"
    // InternalSml.g:991:1: rule__Dimension__Alternatives : ( ( ruleCircleD ) | ( ruleRectangleD ) );
    public final void rule__Dimension__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:995:1: ( ( ruleCircleD ) | ( ruleRectangleD ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==55) ) {
                alt8=1;
            }
            else if ( (LA8_0==56) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalSml.g:996:2: ( ruleCircleD )
                    {
                    // InternalSml.g:996:2: ( ruleCircleD )
                    // InternalSml.g:997:3: ruleCircleD
                    {
                     before(grammarAccess.getDimensionAccess().getCircleDParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleCircleD();

                    state._fsp--;

                     after(grammarAccess.getDimensionAccess().getCircleDParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSml.g:1002:2: ( ruleRectangleD )
                    {
                    // InternalSml.g:1002:2: ( ruleRectangleD )
                    // InternalSml.g:1003:3: ruleRectangleD
                    {
                     before(grammarAccess.getDimensionAccess().getRectangleDParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleRectangleD();

                    state._fsp--;

                     after(grammarAccess.getDimensionAccess().getRectangleDParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Dimension__Alternatives"


    // $ANTLR start "rule__Range__Alternatives"
    // InternalSml.g:1012:1: rule__Range__Alternatives : ( ( ruleUpperbound ) | ( ruleLowerbound ) | ( ruleInterval ) | ( ruleLowerorEqualbound ) | ( ruleUpperorEqualbound ) | ( ruleConstantSize ) );
    public final void rule__Range__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1016:1: ( ( ruleUpperbound ) | ( ruleLowerbound ) | ( ruleInterval ) | ( ruleLowerorEqualbound ) | ( ruleUpperorEqualbound ) | ( ruleConstantSize ) )
            int alt9=6;
            switch ( input.LA(1) ) {
            case 64:
                {
                int LA9_1 = input.LA(2);

                if ( (LA9_1==61) ) {
                    alt9=1;
                }
                else if ( (LA9_1==62) ) {
                    alt9=5;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 9, 1, input);

                    throw nvae;
                }
                }
                break;
            case 60:
                {
                int LA9_2 = input.LA(2);

                if ( (LA9_2==61) ) {
                    alt9=2;
                }
                else if ( (LA9_2==62) ) {
                    alt9=4;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 9, 2, input);

                    throw nvae;
                }
                }
                break;
            case 65:
                {
                alt9=3;
                }
                break;
            case RULE_INT:
                {
                alt9=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalSml.g:1017:2: ( ruleUpperbound )
                    {
                    // InternalSml.g:1017:2: ( ruleUpperbound )
                    // InternalSml.g:1018:3: ruleUpperbound
                    {
                     before(grammarAccess.getRangeAccess().getUpperboundParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleUpperbound();

                    state._fsp--;

                     after(grammarAccess.getRangeAccess().getUpperboundParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSml.g:1023:2: ( ruleLowerbound )
                    {
                    // InternalSml.g:1023:2: ( ruleLowerbound )
                    // InternalSml.g:1024:3: ruleLowerbound
                    {
                     before(grammarAccess.getRangeAccess().getLowerboundParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleLowerbound();

                    state._fsp--;

                     after(grammarAccess.getRangeAccess().getLowerboundParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSml.g:1029:2: ( ruleInterval )
                    {
                    // InternalSml.g:1029:2: ( ruleInterval )
                    // InternalSml.g:1030:3: ruleInterval
                    {
                     before(grammarAccess.getRangeAccess().getIntervalParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleInterval();

                    state._fsp--;

                     after(grammarAccess.getRangeAccess().getIntervalParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSml.g:1035:2: ( ruleLowerorEqualbound )
                    {
                    // InternalSml.g:1035:2: ( ruleLowerorEqualbound )
                    // InternalSml.g:1036:3: ruleLowerorEqualbound
                    {
                     before(grammarAccess.getRangeAccess().getLowerorEqualboundParserRuleCall_3()); 
                    pushFollow(FOLLOW_2);
                    ruleLowerorEqualbound();

                    state._fsp--;

                     after(grammarAccess.getRangeAccess().getLowerorEqualboundParserRuleCall_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSml.g:1041:2: ( ruleUpperorEqualbound )
                    {
                    // InternalSml.g:1041:2: ( ruleUpperorEqualbound )
                    // InternalSml.g:1042:3: ruleUpperorEqualbound
                    {
                     before(grammarAccess.getRangeAccess().getUpperorEqualboundParserRuleCall_4()); 
                    pushFollow(FOLLOW_2);
                    ruleUpperorEqualbound();

                    state._fsp--;

                     after(grammarAccess.getRangeAccess().getUpperorEqualboundParserRuleCall_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSml.g:1047:2: ( ruleConstantSize )
                    {
                    // InternalSml.g:1047:2: ( ruleConstantSize )
                    // InternalSml.g:1048:3: ruleConstantSize
                    {
                     before(grammarAccess.getRangeAccess().getConstantSizeParserRuleCall_5()); 
                    pushFollow(FOLLOW_2);
                    ruleConstantSize();

                    state._fsp--;

                     after(grammarAccess.getRangeAccess().getConstantSizeParserRuleCall_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Range__Alternatives"


    // $ANTLR start "rule__Model__Group__0"
    // InternalSml.g:1057:1: rule__Model__Group__0 : rule__Model__Group__0__Impl rule__Model__Group__1 ;
    public final void rule__Model__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1061:1: ( rule__Model__Group__0__Impl rule__Model__Group__1 )
            // InternalSml.g:1062:2: rule__Model__Group__0__Impl rule__Model__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Model__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0"


    // $ANTLR start "rule__Model__Group__0__Impl"
    // InternalSml.g:1069:1: rule__Model__Group__0__Impl : ( ( rule__Model__ArenasAssignment_0 ) ) ;
    public final void rule__Model__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1073:1: ( ( ( rule__Model__ArenasAssignment_0 ) ) )
            // InternalSml.g:1074:1: ( ( rule__Model__ArenasAssignment_0 ) )
            {
            // InternalSml.g:1074:1: ( ( rule__Model__ArenasAssignment_0 ) )
            // InternalSml.g:1075:2: ( rule__Model__ArenasAssignment_0 )
            {
             before(grammarAccess.getModelAccess().getArenasAssignment_0()); 
            // InternalSml.g:1076:2: ( rule__Model__ArenasAssignment_0 )
            // InternalSml.g:1076:3: rule__Model__ArenasAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Model__ArenasAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getArenasAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0__Impl"


    // $ANTLR start "rule__Model__Group__1"
    // InternalSml.g:1084:1: rule__Model__Group__1 : rule__Model__Group__1__Impl rule__Model__Group__2 ;
    public final void rule__Model__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1088:1: ( rule__Model__Group__1__Impl rule__Model__Group__2 )
            // InternalSml.g:1089:2: rule__Model__Group__1__Impl rule__Model__Group__2
            {
            pushFollow(FOLLOW_3);
            rule__Model__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1"


    // $ANTLR start "rule__Model__Group__1__Impl"
    // InternalSml.g:1096:1: rule__Model__Group__1__Impl : ( ( rule__Model__EnvAssignment_1 ) ) ;
    public final void rule__Model__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1100:1: ( ( ( rule__Model__EnvAssignment_1 ) ) )
            // InternalSml.g:1101:1: ( ( rule__Model__EnvAssignment_1 ) )
            {
            // InternalSml.g:1101:1: ( ( rule__Model__EnvAssignment_1 ) )
            // InternalSml.g:1102:2: ( rule__Model__EnvAssignment_1 )
            {
             before(grammarAccess.getModelAccess().getEnvAssignment_1()); 
            // InternalSml.g:1103:2: ( rule__Model__EnvAssignment_1 )
            // InternalSml.g:1103:3: rule__Model__EnvAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Model__EnvAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getEnvAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1__Impl"


    // $ANTLR start "rule__Model__Group__2"
    // InternalSml.g:1111:1: rule__Model__Group__2 : rule__Model__Group__2__Impl ;
    public final void rule__Model__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1115:1: ( rule__Model__Group__2__Impl )
            // InternalSml.g:1116:2: rule__Model__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Model__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2"


    // $ANTLR start "rule__Model__Group__2__Impl"
    // InternalSml.g:1122:1: rule__Model__Group__2__Impl : ( ( rule__Model__SwAssignment_2 ) ) ;
    public final void rule__Model__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1126:1: ( ( ( rule__Model__SwAssignment_2 ) ) )
            // InternalSml.g:1127:1: ( ( rule__Model__SwAssignment_2 ) )
            {
            // InternalSml.g:1127:1: ( ( rule__Model__SwAssignment_2 ) )
            // InternalSml.g:1128:2: ( rule__Model__SwAssignment_2 )
            {
             before(grammarAccess.getModelAccess().getSwAssignment_2()); 
            // InternalSml.g:1129:2: ( rule__Model__SwAssignment_2 )
            // InternalSml.g:1129:3: rule__Model__SwAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Model__SwAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getSwAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2__Impl"


    // $ANTLR start "rule__Environment__Group__0"
    // InternalSml.g:1138:1: rule__Environment__Group__0 : rule__Environment__Group__0__Impl rule__Environment__Group__1 ;
    public final void rule__Environment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1142:1: ( rule__Environment__Group__0__Impl rule__Environment__Group__1 )
            // InternalSml.g:1143:2: rule__Environment__Group__0__Impl rule__Environment__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Environment__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Environment__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__0"


    // $ANTLR start "rule__Environment__Group__0__Impl"
    // InternalSml.g:1150:1: rule__Environment__Group__0__Impl : ( 'The' ) ;
    public final void rule__Environment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1154:1: ( ( 'The' ) )
            // InternalSml.g:1155:1: ( 'The' )
            {
            // InternalSml.g:1155:1: ( 'The' )
            // InternalSml.g:1156:2: 'The'
            {
             before(grammarAccess.getEnvironmentAccess().getTheKeyword_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getEnvironmentAccess().getTheKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__0__Impl"


    // $ANTLR start "rule__Environment__Group__1"
    // InternalSml.g:1165:1: rule__Environment__Group__1 : rule__Environment__Group__1__Impl rule__Environment__Group__2 ;
    public final void rule__Environment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1169:1: ( rule__Environment__Group__1__Impl rule__Environment__Group__2 )
            // InternalSml.g:1170:2: rule__Environment__Group__1__Impl rule__Environment__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Environment__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Environment__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__1"


    // $ANTLR start "rule__Environment__Group__1__Impl"
    // InternalSml.g:1177:1: rule__Environment__Group__1__Impl : ( 'arena' ) ;
    public final void rule__Environment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1181:1: ( ( 'arena' ) )
            // InternalSml.g:1182:1: ( 'arena' )
            {
            // InternalSml.g:1182:1: ( 'arena' )
            // InternalSml.g:1183:2: 'arena'
            {
             before(grammarAccess.getEnvironmentAccess().getArenaKeyword_1()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getEnvironmentAccess().getArenaKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__1__Impl"


    // $ANTLR start "rule__Environment__Group__2"
    // InternalSml.g:1192:1: rule__Environment__Group__2 : rule__Environment__Group__2__Impl rule__Environment__Group__3 ;
    public final void rule__Environment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1196:1: ( rule__Environment__Group__2__Impl rule__Environment__Group__3 )
            // InternalSml.g:1197:2: rule__Environment__Group__2__Impl rule__Environment__Group__3
            {
            pushFollow(FOLLOW_6);
            rule__Environment__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Environment__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__2"


    // $ANTLR start "rule__Environment__Group__2__Impl"
    // InternalSml.g:1204:1: rule__Environment__Group__2__Impl : ( 'contains' ) ;
    public final void rule__Environment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1208:1: ( ( 'contains' ) )
            // InternalSml.g:1209:1: ( 'contains' )
            {
            // InternalSml.g:1209:1: ( 'contains' )
            // InternalSml.g:1210:2: 'contains'
            {
             before(grammarAccess.getEnvironmentAccess().getContainsKeyword_2()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getEnvironmentAccess().getContainsKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__2__Impl"


    // $ANTLR start "rule__Environment__Group__3"
    // InternalSml.g:1219:1: rule__Environment__Group__3 : rule__Environment__Group__3__Impl rule__Environment__Group__4 ;
    public final void rule__Environment__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1223:1: ( rule__Environment__Group__3__Impl rule__Environment__Group__4 )
            // InternalSml.g:1224:2: rule__Environment__Group__3__Impl rule__Environment__Group__4
            {
            pushFollow(FOLLOW_7);
            rule__Environment__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Environment__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__3"


    // $ANTLR start "rule__Environment__Group__3__Impl"
    // InternalSml.g:1231:1: rule__Environment__Group__3__Impl : ( 'the' ) ;
    public final void rule__Environment__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1235:1: ( ( 'the' ) )
            // InternalSml.g:1236:1: ( 'the' )
            {
            // InternalSml.g:1236:1: ( 'the' )
            // InternalSml.g:1237:2: 'the'
            {
             before(grammarAccess.getEnvironmentAccess().getTheKeyword_3()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getEnvironmentAccess().getTheKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__3__Impl"


    // $ANTLR start "rule__Environment__Group__4"
    // InternalSml.g:1246:1: rule__Environment__Group__4 : rule__Environment__Group__4__Impl rule__Environment__Group__5 ;
    public final void rule__Environment__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1250:1: ( rule__Environment__Group__4__Impl rule__Environment__Group__5 )
            // InternalSml.g:1251:2: rule__Environment__Group__4__Impl rule__Environment__Group__5
            {
            pushFollow(FOLLOW_8);
            rule__Environment__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Environment__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__4"


    // $ANTLR start "rule__Environment__Group__4__Impl"
    // InternalSml.g:1258:1: rule__Environment__Group__4__Impl : ( 'following' ) ;
    public final void rule__Environment__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1262:1: ( ( 'following' ) )
            // InternalSml.g:1263:1: ( 'following' )
            {
            // InternalSml.g:1263:1: ( 'following' )
            // InternalSml.g:1264:2: 'following'
            {
             before(grammarAccess.getEnvironmentAccess().getFollowingKeyword_4()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getEnvironmentAccess().getFollowingKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__4__Impl"


    // $ANTLR start "rule__Environment__Group__5"
    // InternalSml.g:1273:1: rule__Environment__Group__5 : rule__Environment__Group__5__Impl rule__Environment__Group__6 ;
    public final void rule__Environment__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1277:1: ( rule__Environment__Group__5__Impl rule__Environment__Group__6 )
            // InternalSml.g:1278:2: rule__Environment__Group__5__Impl rule__Environment__Group__6
            {
            pushFollow(FOLLOW_9);
            rule__Environment__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Environment__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__5"


    // $ANTLR start "rule__Environment__Group__5__Impl"
    // InternalSml.g:1285:1: rule__Environment__Group__5__Impl : ( 'elements' ) ;
    public final void rule__Environment__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1289:1: ( ( 'elements' ) )
            // InternalSml.g:1290:1: ( 'elements' )
            {
            // InternalSml.g:1290:1: ( 'elements' )
            // InternalSml.g:1291:2: 'elements'
            {
             before(grammarAccess.getEnvironmentAccess().getElementsKeyword_5()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getEnvironmentAccess().getElementsKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__5__Impl"


    // $ANTLR start "rule__Environment__Group__6"
    // InternalSml.g:1300:1: rule__Environment__Group__6 : rule__Environment__Group__6__Impl rule__Environment__Group__7 ;
    public final void rule__Environment__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1304:1: ( rule__Environment__Group__6__Impl rule__Environment__Group__7 )
            // InternalSml.g:1305:2: rule__Environment__Group__6__Impl rule__Environment__Group__7
            {
            pushFollow(FOLLOW_10);
            rule__Environment__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Environment__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__6"


    // $ANTLR start "rule__Environment__Group__6__Impl"
    // InternalSml.g:1312:1: rule__Environment__Group__6__Impl : ( ':' ) ;
    public final void rule__Environment__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1316:1: ( ( ':' ) )
            // InternalSml.g:1317:1: ( ':' )
            {
            // InternalSml.g:1317:1: ( ':' )
            // InternalSml.g:1318:2: ':'
            {
             before(grammarAccess.getEnvironmentAccess().getColonKeyword_6()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getEnvironmentAccess().getColonKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__6__Impl"


    // $ANTLR start "rule__Environment__Group__7"
    // InternalSml.g:1327:1: rule__Environment__Group__7 : rule__Environment__Group__7__Impl ;
    public final void rule__Environment__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1331:1: ( rule__Environment__Group__7__Impl )
            // InternalSml.g:1332:2: rule__Environment__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Environment__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__7"


    // $ANTLR start "rule__Environment__Group__7__Impl"
    // InternalSml.g:1338:1: rule__Environment__Group__7__Impl : ( ( rule__Environment__EnvironmentAssignment_7 ) ) ;
    public final void rule__Environment__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1342:1: ( ( ( rule__Environment__EnvironmentAssignment_7 ) ) )
            // InternalSml.g:1343:1: ( ( rule__Environment__EnvironmentAssignment_7 ) )
            {
            // InternalSml.g:1343:1: ( ( rule__Environment__EnvironmentAssignment_7 ) )
            // InternalSml.g:1344:2: ( rule__Environment__EnvironmentAssignment_7 )
            {
             before(grammarAccess.getEnvironmentAccess().getEnvironmentAssignment_7()); 
            // InternalSml.g:1345:2: ( rule__Environment__EnvironmentAssignment_7 )
            // InternalSml.g:1345:3: rule__Environment__EnvironmentAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Environment__EnvironmentAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getEnvironmentAccess().getEnvironmentAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__Group__7__Impl"


    // $ANTLR start "rule__ProbabilisticDecription__Group__0"
    // InternalSml.g:1354:1: rule__ProbabilisticDecription__Group__0 : rule__ProbabilisticDecription__Group__0__Impl rule__ProbabilisticDecription__Group__1 ;
    public final void rule__ProbabilisticDecription__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1358:1: ( rule__ProbabilisticDecription__Group__0__Impl rule__ProbabilisticDecription__Group__1 )
            // InternalSml.g:1359:2: rule__ProbabilisticDecription__Group__0__Impl rule__ProbabilisticDecription__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__ProbabilisticDecription__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ProbabilisticDecription__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__0"


    // $ANTLR start "rule__ProbabilisticDecription__Group__0__Impl"
    // InternalSml.g:1366:1: rule__ProbabilisticDecription__Group__0__Impl : ( 'distributed' ) ;
    public final void rule__ProbabilisticDecription__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1370:1: ( ( 'distributed' ) )
            // InternalSml.g:1371:1: ( 'distributed' )
            {
            // InternalSml.g:1371:1: ( 'distributed' )
            // InternalSml.g:1372:2: 'distributed'
            {
             before(grammarAccess.getProbabilisticDecriptionAccess().getDistributedKeyword_0()); 
            match(input,32,FOLLOW_2); 
             after(grammarAccess.getProbabilisticDecriptionAccess().getDistributedKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__0__Impl"


    // $ANTLR start "rule__ProbabilisticDecription__Group__1"
    // InternalSml.g:1381:1: rule__ProbabilisticDecription__Group__1 : rule__ProbabilisticDecription__Group__1__Impl rule__ProbabilisticDecription__Group__2 ;
    public final void rule__ProbabilisticDecription__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1385:1: ( rule__ProbabilisticDecription__Group__1__Impl rule__ProbabilisticDecription__Group__2 )
            // InternalSml.g:1386:2: rule__ProbabilisticDecription__Group__1__Impl rule__ProbabilisticDecription__Group__2
            {
            pushFollow(FOLLOW_12);
            rule__ProbabilisticDecription__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ProbabilisticDecription__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__1"


    // $ANTLR start "rule__ProbabilisticDecription__Group__1__Impl"
    // InternalSml.g:1393:1: rule__ProbabilisticDecription__Group__1__Impl : ( 'with' ) ;
    public final void rule__ProbabilisticDecription__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1397:1: ( ( 'with' ) )
            // InternalSml.g:1398:1: ( 'with' )
            {
            // InternalSml.g:1398:1: ( 'with' )
            // InternalSml.g:1399:2: 'with'
            {
             before(grammarAccess.getProbabilisticDecriptionAccess().getWithKeyword_1()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getProbabilisticDecriptionAccess().getWithKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__1__Impl"


    // $ANTLR start "rule__ProbabilisticDecription__Group__2"
    // InternalSml.g:1408:1: rule__ProbabilisticDecription__Group__2 : rule__ProbabilisticDecription__Group__2__Impl rule__ProbabilisticDecription__Group__3 ;
    public final void rule__ProbabilisticDecription__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1412:1: ( rule__ProbabilisticDecription__Group__2__Impl rule__ProbabilisticDecription__Group__3 )
            // InternalSml.g:1413:2: rule__ProbabilisticDecription__Group__2__Impl rule__ProbabilisticDecription__Group__3
            {
            pushFollow(FOLLOW_13);
            rule__ProbabilisticDecription__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ProbabilisticDecription__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__2"


    // $ANTLR start "rule__ProbabilisticDecription__Group__2__Impl"
    // InternalSml.g:1420:1: rule__ProbabilisticDecription__Group__2__Impl : ( 'a' ) ;
    public final void rule__ProbabilisticDecription__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1424:1: ( ( 'a' ) )
            // InternalSml.g:1425:1: ( 'a' )
            {
            // InternalSml.g:1425:1: ( 'a' )
            // InternalSml.g:1426:2: 'a'
            {
             before(grammarAccess.getProbabilisticDecriptionAccess().getAKeyword_2()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getProbabilisticDecriptionAccess().getAKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__2__Impl"


    // $ANTLR start "rule__ProbabilisticDecription__Group__3"
    // InternalSml.g:1435:1: rule__ProbabilisticDecription__Group__3 : rule__ProbabilisticDecription__Group__3__Impl rule__ProbabilisticDecription__Group__4 ;
    public final void rule__ProbabilisticDecription__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1439:1: ( rule__ProbabilisticDecription__Group__3__Impl rule__ProbabilisticDecription__Group__4 )
            // InternalSml.g:1440:2: rule__ProbabilisticDecription__Group__3__Impl rule__ProbabilisticDecription__Group__4
            {
            pushFollow(FOLLOW_14);
            rule__ProbabilisticDecription__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ProbabilisticDecription__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__3"


    // $ANTLR start "rule__ProbabilisticDecription__Group__3__Impl"
    // InternalSml.g:1447:1: rule__ProbabilisticDecription__Group__3__Impl : ( ( rule__ProbabilisticDecription__DisAssignment_3 ) ) ;
    public final void rule__ProbabilisticDecription__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1451:1: ( ( ( rule__ProbabilisticDecription__DisAssignment_3 ) ) )
            // InternalSml.g:1452:1: ( ( rule__ProbabilisticDecription__DisAssignment_3 ) )
            {
            // InternalSml.g:1452:1: ( ( rule__ProbabilisticDecription__DisAssignment_3 ) )
            // InternalSml.g:1453:2: ( rule__ProbabilisticDecription__DisAssignment_3 )
            {
             before(grammarAccess.getProbabilisticDecriptionAccess().getDisAssignment_3()); 
            // InternalSml.g:1454:2: ( rule__ProbabilisticDecription__DisAssignment_3 )
            // InternalSml.g:1454:3: rule__ProbabilisticDecription__DisAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__ProbabilisticDecription__DisAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getProbabilisticDecriptionAccess().getDisAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__3__Impl"


    // $ANTLR start "rule__ProbabilisticDecription__Group__4"
    // InternalSml.g:1462:1: rule__ProbabilisticDecription__Group__4 : rule__ProbabilisticDecription__Group__4__Impl rule__ProbabilisticDecription__Group__5 ;
    public final void rule__ProbabilisticDecription__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1466:1: ( rule__ProbabilisticDecription__Group__4__Impl rule__ProbabilisticDecription__Group__5 )
            // InternalSml.g:1467:2: rule__ProbabilisticDecription__Group__4__Impl rule__ProbabilisticDecription__Group__5
            {
            pushFollow(FOLLOW_15);
            rule__ProbabilisticDecription__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ProbabilisticDecription__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__4"


    // $ANTLR start "rule__ProbabilisticDecription__Group__4__Impl"
    // InternalSml.g:1474:1: rule__ProbabilisticDecription__Group__4__Impl : ( 'distribution' ) ;
    public final void rule__ProbabilisticDecription__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1478:1: ( ( 'distribution' ) )
            // InternalSml.g:1479:1: ( 'distribution' )
            {
            // InternalSml.g:1479:1: ( 'distribution' )
            // InternalSml.g:1480:2: 'distribution'
            {
             before(grammarAccess.getProbabilisticDecriptionAccess().getDistributionKeyword_4()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getProbabilisticDecriptionAccess().getDistributionKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__4__Impl"


    // $ANTLR start "rule__ProbabilisticDecription__Group__5"
    // InternalSml.g:1489:1: rule__ProbabilisticDecription__Group__5 : rule__ProbabilisticDecription__Group__5__Impl rule__ProbabilisticDecription__Group__6 ;
    public final void rule__ProbabilisticDecription__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1493:1: ( rule__ProbabilisticDecription__Group__5__Impl rule__ProbabilisticDecription__Group__6 )
            // InternalSml.g:1494:2: rule__ProbabilisticDecription__Group__5__Impl rule__ProbabilisticDecription__Group__6
            {
            pushFollow(FOLLOW_12);
            rule__ProbabilisticDecription__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ProbabilisticDecription__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__5"


    // $ANTLR start "rule__ProbabilisticDecription__Group__5__Impl"
    // InternalSml.g:1501:1: rule__ProbabilisticDecription__Group__5__Impl : ( 'in' ) ;
    public final void rule__ProbabilisticDecription__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1505:1: ( ( 'in' ) )
            // InternalSml.g:1506:1: ( 'in' )
            {
            // InternalSml.g:1506:1: ( 'in' )
            // InternalSml.g:1507:2: 'in'
            {
             before(grammarAccess.getProbabilisticDecriptionAccess().getInKeyword_5()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getProbabilisticDecriptionAccess().getInKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__5__Impl"


    // $ANTLR start "rule__ProbabilisticDecription__Group__6"
    // InternalSml.g:1516:1: rule__ProbabilisticDecription__Group__6 : rule__ProbabilisticDecription__Group__6__Impl rule__ProbabilisticDecription__Group__7 ;
    public final void rule__ProbabilisticDecription__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1520:1: ( rule__ProbabilisticDecription__Group__6__Impl rule__ProbabilisticDecription__Group__7 )
            // InternalSml.g:1521:2: rule__ProbabilisticDecription__Group__6__Impl rule__ProbabilisticDecription__Group__7
            {
            pushFollow(FOLLOW_16);
            rule__ProbabilisticDecription__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ProbabilisticDecription__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__6"


    // $ANTLR start "rule__ProbabilisticDecription__Group__6__Impl"
    // InternalSml.g:1528:1: rule__ProbabilisticDecription__Group__6__Impl : ( 'a' ) ;
    public final void rule__ProbabilisticDecription__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1532:1: ( ( 'a' ) )
            // InternalSml.g:1533:1: ( 'a' )
            {
            // InternalSml.g:1533:1: ( 'a' )
            // InternalSml.g:1534:2: 'a'
            {
             before(grammarAccess.getProbabilisticDecriptionAccess().getAKeyword_6()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getProbabilisticDecriptionAccess().getAKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__6__Impl"


    // $ANTLR start "rule__ProbabilisticDecription__Group__7"
    // InternalSml.g:1543:1: rule__ProbabilisticDecription__Group__7 : rule__ProbabilisticDecription__Group__7__Impl ;
    public final void rule__ProbabilisticDecription__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1547:1: ( rule__ProbabilisticDecription__Group__7__Impl )
            // InternalSml.g:1548:2: rule__ProbabilisticDecription__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ProbabilisticDecription__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__7"


    // $ANTLR start "rule__ProbabilisticDecription__Group__7__Impl"
    // InternalSml.g:1554:1: rule__ProbabilisticDecription__Group__7__Impl : ( ( rule__ProbabilisticDecription__KAssignment_7 ) ) ;
    public final void rule__ProbabilisticDecription__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1558:1: ( ( ( rule__ProbabilisticDecription__KAssignment_7 ) ) )
            // InternalSml.g:1559:1: ( ( rule__ProbabilisticDecription__KAssignment_7 ) )
            {
            // InternalSml.g:1559:1: ( ( rule__ProbabilisticDecription__KAssignment_7 ) )
            // InternalSml.g:1560:2: ( rule__ProbabilisticDecription__KAssignment_7 )
            {
             before(grammarAccess.getProbabilisticDecriptionAccess().getKAssignment_7()); 
            // InternalSml.g:1561:2: ( rule__ProbabilisticDecription__KAssignment_7 )
            // InternalSml.g:1561:3: rule__ProbabilisticDecription__KAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__ProbabilisticDecription__KAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getProbabilisticDecriptionAccess().getKAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__Group__7__Impl"


    // $ANTLR start "rule__Swarmconf__Group__0"
    // InternalSml.g:1570:1: rule__Swarmconf__Group__0 : rule__Swarmconf__Group__0__Impl rule__Swarmconf__Group__1 ;
    public final void rule__Swarmconf__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1574:1: ( rule__Swarmconf__Group__0__Impl rule__Swarmconf__Group__1 )
            // InternalSml.g:1575:2: rule__Swarmconf__Group__0__Impl rule__Swarmconf__Group__1
            {
            pushFollow(FOLLOW_17);
            rule__Swarmconf__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Swarmconf__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__0"


    // $ANTLR start "rule__Swarmconf__Group__0__Impl"
    // InternalSml.g:1582:1: rule__Swarmconf__Group__0__Impl : ( 'The' ) ;
    public final void rule__Swarmconf__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1586:1: ( ( 'The' ) )
            // InternalSml.g:1587:1: ( 'The' )
            {
            // InternalSml.g:1587:1: ( 'The' )
            // InternalSml.g:1588:2: 'The'
            {
             before(grammarAccess.getSwarmconfAccess().getTheKeyword_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getSwarmconfAccess().getTheKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__0__Impl"


    // $ANTLR start "rule__Swarmconf__Group__1"
    // InternalSml.g:1597:1: rule__Swarmconf__Group__1 : rule__Swarmconf__Group__1__Impl rule__Swarmconf__Group__2 ;
    public final void rule__Swarmconf__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1601:1: ( rule__Swarmconf__Group__1__Impl rule__Swarmconf__Group__2 )
            // InternalSml.g:1602:2: rule__Swarmconf__Group__1__Impl rule__Swarmconf__Group__2
            {
            pushFollow(FOLLOW_18);
            rule__Swarmconf__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Swarmconf__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__1"


    // $ANTLR start "rule__Swarmconf__Group__1__Impl"
    // InternalSml.g:1609:1: rule__Swarmconf__Group__1__Impl : ( 'robot' ) ;
    public final void rule__Swarmconf__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1613:1: ( ( 'robot' ) )
            // InternalSml.g:1614:1: ( 'robot' )
            {
            // InternalSml.g:1614:1: ( 'robot' )
            // InternalSml.g:1615:2: 'robot'
            {
             before(grammarAccess.getSwarmconfAccess().getRobotKeyword_1()); 
            match(input,37,FOLLOW_2); 
             after(grammarAccess.getSwarmconfAccess().getRobotKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__1__Impl"


    // $ANTLR start "rule__Swarmconf__Group__2"
    // InternalSml.g:1624:1: rule__Swarmconf__Group__2 : rule__Swarmconf__Group__2__Impl rule__Swarmconf__Group__3 ;
    public final void rule__Swarmconf__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1628:1: ( rule__Swarmconf__Group__2__Impl rule__Swarmconf__Group__3 )
            // InternalSml.g:1629:2: rule__Swarmconf__Group__2__Impl rule__Swarmconf__Group__3
            {
            pushFollow(FOLLOW_19);
            rule__Swarmconf__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Swarmconf__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__2"


    // $ANTLR start "rule__Swarmconf__Group__2__Impl"
    // InternalSml.g:1636:1: rule__Swarmconf__Group__2__Impl : ( 'swarm' ) ;
    public final void rule__Swarmconf__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1640:1: ( ( 'swarm' ) )
            // InternalSml.g:1641:1: ( 'swarm' )
            {
            // InternalSml.g:1641:1: ( 'swarm' )
            // InternalSml.g:1642:2: 'swarm'
            {
             before(grammarAccess.getSwarmconfAccess().getSwarmKeyword_2()); 
            match(input,38,FOLLOW_2); 
             after(grammarAccess.getSwarmconfAccess().getSwarmKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__2__Impl"


    // $ANTLR start "rule__Swarmconf__Group__3"
    // InternalSml.g:1651:1: rule__Swarmconf__Group__3 : rule__Swarmconf__Group__3__Impl rule__Swarmconf__Group__4 ;
    public final void rule__Swarmconf__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1655:1: ( rule__Swarmconf__Group__3__Impl rule__Swarmconf__Group__4 )
            // InternalSml.g:1656:2: rule__Swarmconf__Group__3__Impl rule__Swarmconf__Group__4
            {
            pushFollow(FOLLOW_20);
            rule__Swarmconf__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Swarmconf__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__3"


    // $ANTLR start "rule__Swarmconf__Group__3__Impl"
    // InternalSml.g:1663:1: rule__Swarmconf__Group__3__Impl : ( 'consists' ) ;
    public final void rule__Swarmconf__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1667:1: ( ( 'consists' ) )
            // InternalSml.g:1668:1: ( 'consists' )
            {
            // InternalSml.g:1668:1: ( 'consists' )
            // InternalSml.g:1669:2: 'consists'
            {
             before(grammarAccess.getSwarmconfAccess().getConsistsKeyword_3()); 
            match(input,39,FOLLOW_2); 
             after(grammarAccess.getSwarmconfAccess().getConsistsKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__3__Impl"


    // $ANTLR start "rule__Swarmconf__Group__4"
    // InternalSml.g:1678:1: rule__Swarmconf__Group__4 : rule__Swarmconf__Group__4__Impl rule__Swarmconf__Group__5 ;
    public final void rule__Swarmconf__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1682:1: ( rule__Swarmconf__Group__4__Impl rule__Swarmconf__Group__5 )
            // InternalSml.g:1683:2: rule__Swarmconf__Group__4__Impl rule__Swarmconf__Group__5
            {
            pushFollow(FOLLOW_21);
            rule__Swarmconf__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Swarmconf__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__4"


    // $ANTLR start "rule__Swarmconf__Group__4__Impl"
    // InternalSml.g:1690:1: rule__Swarmconf__Group__4__Impl : ( 'of' ) ;
    public final void rule__Swarmconf__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1694:1: ( ( 'of' ) )
            // InternalSml.g:1695:1: ( 'of' )
            {
            // InternalSml.g:1695:1: ( 'of' )
            // InternalSml.g:1696:2: 'of'
            {
             before(grammarAccess.getSwarmconfAccess().getOfKeyword_4()); 
            match(input,40,FOLLOW_2); 
             after(grammarAccess.getSwarmconfAccess().getOfKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__4__Impl"


    // $ANTLR start "rule__Swarmconf__Group__5"
    // InternalSml.g:1705:1: rule__Swarmconf__Group__5 : rule__Swarmconf__Group__5__Impl rule__Swarmconf__Group__6 ;
    public final void rule__Swarmconf__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1709:1: ( rule__Swarmconf__Group__5__Impl rule__Swarmconf__Group__6 )
            // InternalSml.g:1710:2: rule__Swarmconf__Group__5__Impl rule__Swarmconf__Group__6
            {
            pushFollow(FOLLOW_22);
            rule__Swarmconf__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Swarmconf__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__5"


    // $ANTLR start "rule__Swarmconf__Group__5__Impl"
    // InternalSml.g:1717:1: rule__Swarmconf__Group__5__Impl : ( ( rule__Swarmconf__XAssignment_5 ) ) ;
    public final void rule__Swarmconf__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1721:1: ( ( ( rule__Swarmconf__XAssignment_5 ) ) )
            // InternalSml.g:1722:1: ( ( rule__Swarmconf__XAssignment_5 ) )
            {
            // InternalSml.g:1722:1: ( ( rule__Swarmconf__XAssignment_5 ) )
            // InternalSml.g:1723:2: ( rule__Swarmconf__XAssignment_5 )
            {
             before(grammarAccess.getSwarmconfAccess().getXAssignment_5()); 
            // InternalSml.g:1724:2: ( rule__Swarmconf__XAssignment_5 )
            // InternalSml.g:1724:3: rule__Swarmconf__XAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__Swarmconf__XAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getSwarmconfAccess().getXAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__5__Impl"


    // $ANTLR start "rule__Swarmconf__Group__6"
    // InternalSml.g:1732:1: rule__Swarmconf__Group__6 : rule__Swarmconf__Group__6__Impl rule__Swarmconf__Group__7 ;
    public final void rule__Swarmconf__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1736:1: ( rule__Swarmconf__Group__6__Impl rule__Swarmconf__Group__7 )
            // InternalSml.g:1737:2: rule__Swarmconf__Group__6__Impl rule__Swarmconf__Group__7
            {
            pushFollow(FOLLOW_23);
            rule__Swarmconf__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Swarmconf__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__6"


    // $ANTLR start "rule__Swarmconf__Group__6__Impl"
    // InternalSml.g:1744:1: rule__Swarmconf__Group__6__Impl : ( ( rule__Swarmconf__RAssignment_6 ) ) ;
    public final void rule__Swarmconf__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1748:1: ( ( ( rule__Swarmconf__RAssignment_6 ) ) )
            // InternalSml.g:1749:1: ( ( rule__Swarmconf__RAssignment_6 ) )
            {
            // InternalSml.g:1749:1: ( ( rule__Swarmconf__RAssignment_6 ) )
            // InternalSml.g:1750:2: ( rule__Swarmconf__RAssignment_6 )
            {
             before(grammarAccess.getSwarmconfAccess().getRAssignment_6()); 
            // InternalSml.g:1751:2: ( rule__Swarmconf__RAssignment_6 )
            // InternalSml.g:1751:3: rule__Swarmconf__RAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__Swarmconf__RAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getSwarmconfAccess().getRAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__6__Impl"


    // $ANTLR start "rule__Swarmconf__Group__7"
    // InternalSml.g:1759:1: rule__Swarmconf__Group__7 : rule__Swarmconf__Group__7__Impl ;
    public final void rule__Swarmconf__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1763:1: ( rule__Swarmconf__Group__7__Impl )
            // InternalSml.g:1764:2: rule__Swarmconf__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Swarmconf__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__7"


    // $ANTLR start "rule__Swarmconf__Group__7__Impl"
    // InternalSml.g:1770:1: rule__Swarmconf__Group__7__Impl : ( ( rule__Swarmconf__PrAssignment_7 ) ) ;
    public final void rule__Swarmconf__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1774:1: ( ( ( rule__Swarmconf__PrAssignment_7 ) ) )
            // InternalSml.g:1775:1: ( ( rule__Swarmconf__PrAssignment_7 ) )
            {
            // InternalSml.g:1775:1: ( ( rule__Swarmconf__PrAssignment_7 ) )
            // InternalSml.g:1776:2: ( rule__Swarmconf__PrAssignment_7 )
            {
             before(grammarAccess.getSwarmconfAccess().getPrAssignment_7()); 
            // InternalSml.g:1777:2: ( rule__Swarmconf__PrAssignment_7 )
            // InternalSml.g:1777:3: rule__Swarmconf__PrAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Swarmconf__PrAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getSwarmconfAccess().getPrAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__Group__7__Impl"


    // $ANTLR start "rule__EnvironmentElements__Group__0"
    // InternalSml.g:1786:1: rule__EnvironmentElements__Group__0 : rule__EnvironmentElements__Group__0__Impl rule__EnvironmentElements__Group__1 ;
    public final void rule__EnvironmentElements__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1790:1: ( rule__EnvironmentElements__Group__0__Impl rule__EnvironmentElements__Group__1 )
            // InternalSml.g:1791:2: rule__EnvironmentElements__Group__0__Impl rule__EnvironmentElements__Group__1
            {
            pushFollow(FOLLOW_24);
            rule__EnvironmentElements__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EnvironmentElements__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnvironmentElements__Group__0"


    // $ANTLR start "rule__EnvironmentElements__Group__0__Impl"
    // InternalSml.g:1798:1: rule__EnvironmentElements__Group__0__Impl : ( ( ( rule__EnvironmentElements__ElementAssignment_0 ) ) ( ( rule__EnvironmentElements__ElementAssignment_0 )* ) ) ;
    public final void rule__EnvironmentElements__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1802:1: ( ( ( ( rule__EnvironmentElements__ElementAssignment_0 ) ) ( ( rule__EnvironmentElements__ElementAssignment_0 )* ) ) )
            // InternalSml.g:1803:1: ( ( ( rule__EnvironmentElements__ElementAssignment_0 ) ) ( ( rule__EnvironmentElements__ElementAssignment_0 )* ) )
            {
            // InternalSml.g:1803:1: ( ( ( rule__EnvironmentElements__ElementAssignment_0 ) ) ( ( rule__EnvironmentElements__ElementAssignment_0 )* ) )
            // InternalSml.g:1804:2: ( ( rule__EnvironmentElements__ElementAssignment_0 ) ) ( ( rule__EnvironmentElements__ElementAssignment_0 )* )
            {
            // InternalSml.g:1804:2: ( ( rule__EnvironmentElements__ElementAssignment_0 ) )
            // InternalSml.g:1805:3: ( rule__EnvironmentElements__ElementAssignment_0 )
            {
             before(grammarAccess.getEnvironmentElementsAccess().getElementAssignment_0()); 
            // InternalSml.g:1806:3: ( rule__EnvironmentElements__ElementAssignment_0 )
            // InternalSml.g:1806:4: rule__EnvironmentElements__ElementAssignment_0
            {
            pushFollow(FOLLOW_25);
            rule__EnvironmentElements__ElementAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getEnvironmentElementsAccess().getElementAssignment_0()); 

            }

            // InternalSml.g:1809:2: ( ( rule__EnvironmentElements__ElementAssignment_0 )* )
            // InternalSml.g:1810:3: ( rule__EnvironmentElements__ElementAssignment_0 )*
            {
             before(grammarAccess.getEnvironmentElementsAccess().getElementAssignment_0()); 
            // InternalSml.g:1811:3: ( rule__EnvironmentElements__ElementAssignment_0 )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( ((LA10_0>=67 && LA10_0<=68)) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalSml.g:1811:4: rule__EnvironmentElements__ElementAssignment_0
            	    {
            	    pushFollow(FOLLOW_25);
            	    rule__EnvironmentElements__ElementAssignment_0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

             after(grammarAccess.getEnvironmentElementsAccess().getElementAssignment_0()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnvironmentElements__Group__0__Impl"


    // $ANTLR start "rule__EnvironmentElements__Group__1"
    // InternalSml.g:1820:1: rule__EnvironmentElements__Group__1 : rule__EnvironmentElements__Group__1__Impl ;
    public final void rule__EnvironmentElements__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1824:1: ( rule__EnvironmentElements__Group__1__Impl )
            // InternalSml.g:1825:2: rule__EnvironmentElements__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EnvironmentElements__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnvironmentElements__Group__1"


    // $ANTLR start "rule__EnvironmentElements__Group__1__Impl"
    // InternalSml.g:1831:1: rule__EnvironmentElements__Group__1__Impl : ( ( ( rule__EnvironmentElements__ElementAssignment_1 ) ) ( ( rule__EnvironmentElements__ElementAssignment_1 )* ) ) ;
    public final void rule__EnvironmentElements__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1835:1: ( ( ( ( rule__EnvironmentElements__ElementAssignment_1 ) ) ( ( rule__EnvironmentElements__ElementAssignment_1 )* ) ) )
            // InternalSml.g:1836:1: ( ( ( rule__EnvironmentElements__ElementAssignment_1 ) ) ( ( rule__EnvironmentElements__ElementAssignment_1 )* ) )
            {
            // InternalSml.g:1836:1: ( ( ( rule__EnvironmentElements__ElementAssignment_1 ) ) ( ( rule__EnvironmentElements__ElementAssignment_1 )* ) )
            // InternalSml.g:1837:2: ( ( rule__EnvironmentElements__ElementAssignment_1 ) ) ( ( rule__EnvironmentElements__ElementAssignment_1 )* )
            {
            // InternalSml.g:1837:2: ( ( rule__EnvironmentElements__ElementAssignment_1 ) )
            // InternalSml.g:1838:3: ( rule__EnvironmentElements__ElementAssignment_1 )
            {
             before(grammarAccess.getEnvironmentElementsAccess().getElementAssignment_1()); 
            // InternalSml.g:1839:3: ( rule__EnvironmentElements__ElementAssignment_1 )
            // InternalSml.g:1839:4: rule__EnvironmentElements__ElementAssignment_1
            {
            pushFollow(FOLLOW_26);
            rule__EnvironmentElements__ElementAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEnvironmentElementsAccess().getElementAssignment_1()); 

            }

            // InternalSml.g:1842:2: ( ( rule__EnvironmentElements__ElementAssignment_1 )* )
            // InternalSml.g:1843:3: ( rule__EnvironmentElements__ElementAssignment_1 )*
            {
             before(grammarAccess.getEnvironmentElementsAccess().getElementAssignment_1()); 
            // InternalSml.g:1844:3: ( rule__EnvironmentElements__ElementAssignment_1 )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==66) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalSml.g:1844:4: rule__EnvironmentElements__ElementAssignment_1
            	    {
            	    pushFollow(FOLLOW_26);
            	    rule__EnvironmentElements__ElementAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

             after(grammarAccess.getEnvironmentElementsAccess().getElementAssignment_1()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnvironmentElements__Group__1__Impl"


    // $ANTLR start "rule__ElementDescription__Group__0"
    // InternalSml.g:1854:1: rule__ElementDescription__Group__0 : rule__ElementDescription__Group__0__Impl rule__ElementDescription__Group__1 ;
    public final void rule__ElementDescription__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1858:1: ( rule__ElementDescription__Group__0__Impl rule__ElementDescription__Group__1 )
            // InternalSml.g:1859:2: rule__ElementDescription__Group__0__Impl rule__ElementDescription__Group__1
            {
            pushFollow(FOLLOW_27);
            rule__ElementDescription__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ElementDescription__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__Group__0"


    // $ANTLR start "rule__ElementDescription__Group__0__Impl"
    // InternalSml.g:1866:1: rule__ElementDescription__Group__0__Impl : ( ( rule__ElementDescription__ElAssignment_0 ) ) ;
    public final void rule__ElementDescription__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1870:1: ( ( ( rule__ElementDescription__ElAssignment_0 ) ) )
            // InternalSml.g:1871:1: ( ( rule__ElementDescription__ElAssignment_0 ) )
            {
            // InternalSml.g:1871:1: ( ( rule__ElementDescription__ElAssignment_0 ) )
            // InternalSml.g:1872:2: ( rule__ElementDescription__ElAssignment_0 )
            {
             before(grammarAccess.getElementDescriptionAccess().getElAssignment_0()); 
            // InternalSml.g:1873:2: ( rule__ElementDescription__ElAssignment_0 )
            // InternalSml.g:1873:3: rule__ElementDescription__ElAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__ElementDescription__ElAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getElementDescriptionAccess().getElAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__Group__0__Impl"


    // $ANTLR start "rule__ElementDescription__Group__1"
    // InternalSml.g:1881:1: rule__ElementDescription__Group__1 : rule__ElementDescription__Group__1__Impl rule__ElementDescription__Group__2 ;
    public final void rule__ElementDescription__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1885:1: ( rule__ElementDescription__Group__1__Impl rule__ElementDescription__Group__2 )
            // InternalSml.g:1886:2: rule__ElementDescription__Group__1__Impl rule__ElementDescription__Group__2
            {
            pushFollow(FOLLOW_21);
            rule__ElementDescription__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ElementDescription__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__Group__1"


    // $ANTLR start "rule__ElementDescription__Group__1__Impl"
    // InternalSml.g:1893:1: rule__ElementDescription__Group__1__Impl : ( 'are' ) ;
    public final void rule__ElementDescription__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1897:1: ( ( 'are' ) )
            // InternalSml.g:1898:1: ( 'are' )
            {
            // InternalSml.g:1898:1: ( 'are' )
            // InternalSml.g:1899:2: 'are'
            {
             before(grammarAccess.getElementDescriptionAccess().getAreKeyword_1()); 
            match(input,41,FOLLOW_2); 
             after(grammarAccess.getElementDescriptionAccess().getAreKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__Group__1__Impl"


    // $ANTLR start "rule__ElementDescription__Group__2"
    // InternalSml.g:1908:1: rule__ElementDescription__Group__2 : rule__ElementDescription__Group__2__Impl rule__ElementDescription__Group__3 ;
    public final void rule__ElementDescription__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1912:1: ( rule__ElementDescription__Group__2__Impl rule__ElementDescription__Group__3 )
            // InternalSml.g:1913:2: rule__ElementDescription__Group__2__Impl rule__ElementDescription__Group__3
            {
            pushFollow(FOLLOW_28);
            rule__ElementDescription__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ElementDescription__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__Group__2"


    // $ANTLR start "rule__ElementDescription__Group__2__Impl"
    // InternalSml.g:1920:1: rule__ElementDescription__Group__2__Impl : ( ( rule__ElementDescription__XAssignment_2 ) ) ;
    public final void rule__ElementDescription__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1924:1: ( ( ( rule__ElementDescription__XAssignment_2 ) ) )
            // InternalSml.g:1925:1: ( ( rule__ElementDescription__XAssignment_2 ) )
            {
            // InternalSml.g:1925:1: ( ( rule__ElementDescription__XAssignment_2 ) )
            // InternalSml.g:1926:2: ( rule__ElementDescription__XAssignment_2 )
            {
             before(grammarAccess.getElementDescriptionAccess().getXAssignment_2()); 
            // InternalSml.g:1927:2: ( rule__ElementDescription__XAssignment_2 )
            // InternalSml.g:1927:3: rule__ElementDescription__XAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__ElementDescription__XAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getElementDescriptionAccess().getXAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__Group__2__Impl"


    // $ANTLR start "rule__ElementDescription__Group__3"
    // InternalSml.g:1935:1: rule__ElementDescription__Group__3 : rule__ElementDescription__Group__3__Impl rule__ElementDescription__Group__4 ;
    public final void rule__ElementDescription__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1939:1: ( rule__ElementDescription__Group__3__Impl rule__ElementDescription__Group__4 )
            // InternalSml.g:1940:2: rule__ElementDescription__Group__3__Impl rule__ElementDescription__Group__4
            {
            pushFollow(FOLLOW_23);
            rule__ElementDescription__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ElementDescription__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__Group__3"


    // $ANTLR start "rule__ElementDescription__Group__3__Impl"
    // InternalSml.g:1947:1: rule__ElementDescription__Group__3__Impl : ( ( rule__ElementDescription__ObjAssignment_3 ) ) ;
    public final void rule__ElementDescription__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1951:1: ( ( ( rule__ElementDescription__ObjAssignment_3 ) ) )
            // InternalSml.g:1952:1: ( ( rule__ElementDescription__ObjAssignment_3 ) )
            {
            // InternalSml.g:1952:1: ( ( rule__ElementDescription__ObjAssignment_3 ) )
            // InternalSml.g:1953:2: ( rule__ElementDescription__ObjAssignment_3 )
            {
             before(grammarAccess.getElementDescriptionAccess().getObjAssignment_3()); 
            // InternalSml.g:1954:2: ( rule__ElementDescription__ObjAssignment_3 )
            // InternalSml.g:1954:3: rule__ElementDescription__ObjAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__ElementDescription__ObjAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getElementDescriptionAccess().getObjAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__Group__3__Impl"


    // $ANTLR start "rule__ElementDescription__Group__4"
    // InternalSml.g:1962:1: rule__ElementDescription__Group__4 : rule__ElementDescription__Group__4__Impl ;
    public final void rule__ElementDescription__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1966:1: ( rule__ElementDescription__Group__4__Impl )
            // InternalSml.g:1967:2: rule__ElementDescription__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ElementDescription__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__Group__4"


    // $ANTLR start "rule__ElementDescription__Group__4__Impl"
    // InternalSml.g:1973:1: rule__ElementDescription__Group__4__Impl : ( ( rule__ElementDescription__RAssignment_4 ) ) ;
    public final void rule__ElementDescription__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1977:1: ( ( ( rule__ElementDescription__RAssignment_4 ) ) )
            // InternalSml.g:1978:1: ( ( rule__ElementDescription__RAssignment_4 ) )
            {
            // InternalSml.g:1978:1: ( ( rule__ElementDescription__RAssignment_4 ) )
            // InternalSml.g:1979:2: ( rule__ElementDescription__RAssignment_4 )
            {
             before(grammarAccess.getElementDescriptionAccess().getRAssignment_4()); 
            // InternalSml.g:1980:2: ( rule__ElementDescription__RAssignment_4 )
            // InternalSml.g:1980:3: rule__ElementDescription__RAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__ElementDescription__RAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getElementDescriptionAccess().getRAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__Group__4__Impl"


    // $ANTLR start "rule__Element__Group_2__0"
    // InternalSml.g:1989:1: rule__Element__Group_2__0 : rule__Element__Group_2__0__Impl rule__Element__Group_2__1 ;
    public final void rule__Element__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:1993:1: ( rule__Element__Group_2__0__Impl rule__Element__Group_2__1 )
            // InternalSml.g:1994:2: rule__Element__Group_2__0__Impl rule__Element__Group_2__1
            {
            pushFollow(FOLLOW_29);
            rule__Element__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Element__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_2__0"


    // $ANTLR start "rule__Element__Group_2__0__Impl"
    // InternalSml.g:2001:1: rule__Element__Group_2__0__Impl : ( 'light' ) ;
    public final void rule__Element__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2005:1: ( ( 'light' ) )
            // InternalSml.g:2006:1: ( 'light' )
            {
            // InternalSml.g:2006:1: ( 'light' )
            // InternalSml.g:2007:2: 'light'
            {
             before(grammarAccess.getElementAccess().getLightKeyword_2_0()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getElementAccess().getLightKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_2__0__Impl"


    // $ANTLR start "rule__Element__Group_2__1"
    // InternalSml.g:2016:1: rule__Element__Group_2__1 : rule__Element__Group_2__1__Impl ;
    public final void rule__Element__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2020:1: ( rule__Element__Group_2__1__Impl )
            // InternalSml.g:2021:2: rule__Element__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Element__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_2__1"


    // $ANTLR start "rule__Element__Group_2__1__Impl"
    // InternalSml.g:2027:1: rule__Element__Group_2__1__Impl : ( 'sources' ) ;
    public final void rule__Element__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2031:1: ( ( 'sources' ) )
            // InternalSml.g:2032:1: ( 'sources' )
            {
            // InternalSml.g:2032:1: ( 'sources' )
            // InternalSml.g:2033:2: 'sources'
            {
             before(grammarAccess.getElementAccess().getSourcesKeyword_2_1()); 
            match(input,43,FOLLOW_2); 
             after(grammarAccess.getElementAccess().getSourcesKeyword_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_2__1__Impl"


    // $ANTLR start "rule__Object__Group__0"
    // InternalSml.g:2043:1: rule__Object__Group__0 : rule__Object__Group__0__Impl rule__Object__Group__1 ;
    public final void rule__Object__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2047:1: ( rule__Object__Group__0__Impl rule__Object__Group__1 )
            // InternalSml.g:2048:2: rule__Object__Group__0__Impl rule__Object__Group__1
            {
            pushFollow(FOLLOW_30);
            rule__Object__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Object__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Object__Group__0"


    // $ANTLR start "rule__Object__Group__0__Impl"
    // InternalSml.g:2055:1: rule__Object__Group__0__Impl : ( ( rule__Object__ObjAssignment_0 ) ) ;
    public final void rule__Object__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2059:1: ( ( ( rule__Object__ObjAssignment_0 ) ) )
            // InternalSml.g:2060:1: ( ( rule__Object__ObjAssignment_0 ) )
            {
            // InternalSml.g:2060:1: ( ( rule__Object__ObjAssignment_0 ) )
            // InternalSml.g:2061:2: ( rule__Object__ObjAssignment_0 )
            {
             before(grammarAccess.getObjectAccess().getObjAssignment_0()); 
            // InternalSml.g:2062:2: ( rule__Object__ObjAssignment_0 )
            // InternalSml.g:2062:3: rule__Object__ObjAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Object__ObjAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getObjectAccess().getObjAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Object__Group__0__Impl"


    // $ANTLR start "rule__Object__Group__1"
    // InternalSml.g:2070:1: rule__Object__Group__1 : rule__Object__Group__1__Impl rule__Object__Group__2 ;
    public final void rule__Object__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2074:1: ( rule__Object__Group__1__Impl rule__Object__Group__2 )
            // InternalSml.g:2075:2: rule__Object__Group__1__Impl rule__Object__Group__2
            {
            pushFollow(FOLLOW_31);
            rule__Object__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Object__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Object__Group__1"


    // $ANTLR start "rule__Object__Group__1__Impl"
    // InternalSml.g:2082:1: rule__Object__Group__1__Impl : ( 'object' ) ;
    public final void rule__Object__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2086:1: ( ( 'object' ) )
            // InternalSml.g:2087:1: ( 'object' )
            {
            // InternalSml.g:2087:1: ( 'object' )
            // InternalSml.g:2088:2: 'object'
            {
             before(grammarAccess.getObjectAccess().getObjectKeyword_1()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getObjectAccess().getObjectKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Object__Group__1__Impl"


    // $ANTLR start "rule__Object__Group__2"
    // InternalSml.g:2097:1: rule__Object__Group__2 : rule__Object__Group__2__Impl rule__Object__Group__3 ;
    public final void rule__Object__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2101:1: ( rule__Object__Group__2__Impl rule__Object__Group__3 )
            // InternalSml.g:2102:2: rule__Object__Group__2__Impl rule__Object__Group__3
            {
            pushFollow(FOLLOW_12);
            rule__Object__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Object__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Object__Group__2"


    // $ANTLR start "rule__Object__Group__2__Impl"
    // InternalSml.g:2109:1: rule__Object__Group__2__Impl : ( 'as' ) ;
    public final void rule__Object__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2113:1: ( ( 'as' ) )
            // InternalSml.g:2114:1: ( 'as' )
            {
            // InternalSml.g:2114:1: ( 'as' )
            // InternalSml.g:2115:2: 'as'
            {
             before(grammarAccess.getObjectAccess().getAsKeyword_2()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getObjectAccess().getAsKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Object__Group__2__Impl"


    // $ANTLR start "rule__Object__Group__3"
    // InternalSml.g:2124:1: rule__Object__Group__3 : rule__Object__Group__3__Impl rule__Object__Group__4 ;
    public final void rule__Object__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2128:1: ( rule__Object__Group__3__Impl rule__Object__Group__4 )
            // InternalSml.g:2129:2: rule__Object__Group__3__Impl rule__Object__Group__4
            {
            pushFollow(FOLLOW_16);
            rule__Object__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Object__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Object__Group__3"


    // $ANTLR start "rule__Object__Group__3__Impl"
    // InternalSml.g:2136:1: rule__Object__Group__3__Impl : ( 'a' ) ;
    public final void rule__Object__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2140:1: ( ( 'a' ) )
            // InternalSml.g:2141:1: ( 'a' )
            {
            // InternalSml.g:2141:1: ( 'a' )
            // InternalSml.g:2142:2: 'a'
            {
             before(grammarAccess.getObjectAccess().getAKeyword_3()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getObjectAccess().getAKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Object__Group__3__Impl"


    // $ANTLR start "rule__Object__Group__4"
    // InternalSml.g:2151:1: rule__Object__Group__4 : rule__Object__Group__4__Impl ;
    public final void rule__Object__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2155:1: ( rule__Object__Group__4__Impl )
            // InternalSml.g:2156:2: rule__Object__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Object__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Object__Group__4"


    // $ANTLR start "rule__Object__Group__4__Impl"
    // InternalSml.g:2162:1: rule__Object__Group__4__Impl : ( ( rule__Object__RAssignment_4 ) ) ;
    public final void rule__Object__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2166:1: ( ( ( rule__Object__RAssignment_4 ) ) )
            // InternalSml.g:2167:1: ( ( rule__Object__RAssignment_4 ) )
            {
            // InternalSml.g:2167:1: ( ( rule__Object__RAssignment_4 ) )
            // InternalSml.g:2168:2: ( rule__Object__RAssignment_4 )
            {
             before(grammarAccess.getObjectAccess().getRAssignment_4()); 
            // InternalSml.g:2169:2: ( rule__Object__RAssignment_4 )
            // InternalSml.g:2169:3: rule__Object__RAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Object__RAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getObjectAccess().getRAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Object__Group__4__Impl"


    // $ANTLR start "rule__Obstacle__Group__0"
    // InternalSml.g:2178:1: rule__Obstacle__Group__0 : rule__Obstacle__Group__0__Impl rule__Obstacle__Group__1 ;
    public final void rule__Obstacle__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2182:1: ( rule__Obstacle__Group__0__Impl rule__Obstacle__Group__1 )
            // InternalSml.g:2183:2: rule__Obstacle__Group__0__Impl rule__Obstacle__Group__1
            {
            pushFollow(FOLLOW_32);
            rule__Obstacle__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Obstacle__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Obstacle__Group__0"


    // $ANTLR start "rule__Obstacle__Group__0__Impl"
    // InternalSml.g:2190:1: rule__Obstacle__Group__0__Impl : ( ( rule__Obstacle__ObsAssignment_0 ) ) ;
    public final void rule__Obstacle__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2194:1: ( ( ( rule__Obstacle__ObsAssignment_0 ) ) )
            // InternalSml.g:2195:1: ( ( rule__Obstacle__ObsAssignment_0 ) )
            {
            // InternalSml.g:2195:1: ( ( rule__Obstacle__ObsAssignment_0 ) )
            // InternalSml.g:2196:2: ( rule__Obstacle__ObsAssignment_0 )
            {
             before(grammarAccess.getObstacleAccess().getObsAssignment_0()); 
            // InternalSml.g:2197:2: ( rule__Obstacle__ObsAssignment_0 )
            // InternalSml.g:2197:3: rule__Obstacle__ObsAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Obstacle__ObsAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getObstacleAccess().getObsAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Obstacle__Group__0__Impl"


    // $ANTLR start "rule__Obstacle__Group__1"
    // InternalSml.g:2205:1: rule__Obstacle__Group__1 : rule__Obstacle__Group__1__Impl rule__Obstacle__Group__2 ;
    public final void rule__Obstacle__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2209:1: ( rule__Obstacle__Group__1__Impl rule__Obstacle__Group__2 )
            // InternalSml.g:2210:2: rule__Obstacle__Group__1__Impl rule__Obstacle__Group__2
            {
            pushFollow(FOLLOW_31);
            rule__Obstacle__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Obstacle__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Obstacle__Group__1"


    // $ANTLR start "rule__Obstacle__Group__1__Impl"
    // InternalSml.g:2217:1: rule__Obstacle__Group__1__Impl : ( 'obstacle' ) ;
    public final void rule__Obstacle__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2221:1: ( ( 'obstacle' ) )
            // InternalSml.g:2222:1: ( 'obstacle' )
            {
            // InternalSml.g:2222:1: ( 'obstacle' )
            // InternalSml.g:2223:2: 'obstacle'
            {
             before(grammarAccess.getObstacleAccess().getObstacleKeyword_1()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getObstacleAccess().getObstacleKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Obstacle__Group__1__Impl"


    // $ANTLR start "rule__Obstacle__Group__2"
    // InternalSml.g:2232:1: rule__Obstacle__Group__2 : rule__Obstacle__Group__2__Impl rule__Obstacle__Group__3 ;
    public final void rule__Obstacle__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2236:1: ( rule__Obstacle__Group__2__Impl rule__Obstacle__Group__3 )
            // InternalSml.g:2237:2: rule__Obstacle__Group__2__Impl rule__Obstacle__Group__3
            {
            pushFollow(FOLLOW_12);
            rule__Obstacle__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Obstacle__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Obstacle__Group__2"


    // $ANTLR start "rule__Obstacle__Group__2__Impl"
    // InternalSml.g:2244:1: rule__Obstacle__Group__2__Impl : ( 'as' ) ;
    public final void rule__Obstacle__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2248:1: ( ( 'as' ) )
            // InternalSml.g:2249:1: ( 'as' )
            {
            // InternalSml.g:2249:1: ( 'as' )
            // InternalSml.g:2250:2: 'as'
            {
             before(grammarAccess.getObstacleAccess().getAsKeyword_2()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getObstacleAccess().getAsKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Obstacle__Group__2__Impl"


    // $ANTLR start "rule__Obstacle__Group__3"
    // InternalSml.g:2259:1: rule__Obstacle__Group__3 : rule__Obstacle__Group__3__Impl rule__Obstacle__Group__4 ;
    public final void rule__Obstacle__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2263:1: ( rule__Obstacle__Group__3__Impl rule__Obstacle__Group__4 )
            // InternalSml.g:2264:2: rule__Obstacle__Group__3__Impl rule__Obstacle__Group__4
            {
            pushFollow(FOLLOW_16);
            rule__Obstacle__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Obstacle__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Obstacle__Group__3"


    // $ANTLR start "rule__Obstacle__Group__3__Impl"
    // InternalSml.g:2271:1: rule__Obstacle__Group__3__Impl : ( 'a' ) ;
    public final void rule__Obstacle__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2275:1: ( ( 'a' ) )
            // InternalSml.g:2276:1: ( 'a' )
            {
            // InternalSml.g:2276:1: ( 'a' )
            // InternalSml.g:2277:2: 'a'
            {
             before(grammarAccess.getObstacleAccess().getAKeyword_3()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getObstacleAccess().getAKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Obstacle__Group__3__Impl"


    // $ANTLR start "rule__Obstacle__Group__4"
    // InternalSml.g:2286:1: rule__Obstacle__Group__4 : rule__Obstacle__Group__4__Impl ;
    public final void rule__Obstacle__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2290:1: ( rule__Obstacle__Group__4__Impl )
            // InternalSml.g:2291:2: rule__Obstacle__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Obstacle__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Obstacle__Group__4"


    // $ANTLR start "rule__Obstacle__Group__4__Impl"
    // InternalSml.g:2297:1: rule__Obstacle__Group__4__Impl : ( ( rule__Obstacle__RAssignment_4 ) ) ;
    public final void rule__Obstacle__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2301:1: ( ( ( rule__Obstacle__RAssignment_4 ) ) )
            // InternalSml.g:2302:1: ( ( rule__Obstacle__RAssignment_4 ) )
            {
            // InternalSml.g:2302:1: ( ( rule__Obstacle__RAssignment_4 ) )
            // InternalSml.g:2303:2: ( rule__Obstacle__RAssignment_4 )
            {
             before(grammarAccess.getObstacleAccess().getRAssignment_4()); 
            // InternalSml.g:2304:2: ( rule__Obstacle__RAssignment_4 )
            // InternalSml.g:2304:3: rule__Obstacle__RAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Obstacle__RAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getObstacleAccess().getRAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Obstacle__Group__4__Impl"


    // $ANTLR start "rule__Light__Group__0"
    // InternalSml.g:2313:1: rule__Light__Group__0 : rule__Light__Group__0__Impl rule__Light__Group__1 ;
    public final void rule__Light__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2317:1: ( rule__Light__Group__0__Impl rule__Light__Group__1 )
            // InternalSml.g:2318:2: rule__Light__Group__0__Impl rule__Light__Group__1
            {
            pushFollow(FOLLOW_33);
            rule__Light__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__0"


    // $ANTLR start "rule__Light__Group__0__Impl"
    // InternalSml.g:2325:1: rule__Light__Group__0__Impl : ( ( rule__Light__LAssignment_0 ) ) ;
    public final void rule__Light__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2329:1: ( ( ( rule__Light__LAssignment_0 ) ) )
            // InternalSml.g:2330:1: ( ( rule__Light__LAssignment_0 ) )
            {
            // InternalSml.g:2330:1: ( ( rule__Light__LAssignment_0 ) )
            // InternalSml.g:2331:2: ( rule__Light__LAssignment_0 )
            {
             before(grammarAccess.getLightAccess().getLAssignment_0()); 
            // InternalSml.g:2332:2: ( rule__Light__LAssignment_0 )
            // InternalSml.g:2332:3: rule__Light__LAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Light__LAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getLightAccess().getLAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__0__Impl"


    // $ANTLR start "rule__Light__Group__1"
    // InternalSml.g:2340:1: rule__Light__Group__1 : rule__Light__Group__1__Impl rule__Light__Group__2 ;
    public final void rule__Light__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2344:1: ( rule__Light__Group__1__Impl rule__Light__Group__2 )
            // InternalSml.g:2345:2: rule__Light__Group__1__Impl rule__Light__Group__2
            {
            pushFollow(FOLLOW_34);
            rule__Light__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__1"


    // $ANTLR start "rule__Light__Group__1__Impl"
    // InternalSml.g:2352:1: rule__Light__Group__1__Impl : ( 'light' ) ;
    public final void rule__Light__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2356:1: ( ( 'light' ) )
            // InternalSml.g:2357:1: ( 'light' )
            {
            // InternalSml.g:2357:1: ( 'light' )
            // InternalSml.g:2358:2: 'light'
            {
             before(grammarAccess.getLightAccess().getLightKeyword_1()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getLightKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__1__Impl"


    // $ANTLR start "rule__Light__Group__2"
    // InternalSml.g:2367:1: rule__Light__Group__2 : rule__Light__Group__2__Impl rule__Light__Group__3 ;
    public final void rule__Light__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2371:1: ( rule__Light__Group__2__Impl rule__Light__Group__3 )
            // InternalSml.g:2372:2: rule__Light__Group__2__Impl rule__Light__Group__3
            {
            pushFollow(FOLLOW_35);
            rule__Light__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__2"


    // $ANTLR start "rule__Light__Group__2__Impl"
    // InternalSml.g:2379:1: rule__Light__Group__2__Impl : ( 'source' ) ;
    public final void rule__Light__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2383:1: ( ( 'source' ) )
            // InternalSml.g:2384:1: ( 'source' )
            {
            // InternalSml.g:2384:1: ( 'source' )
            // InternalSml.g:2385:2: 'source'
            {
             before(grammarAccess.getLightAccess().getSourceKeyword_2()); 
            match(input,47,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getSourceKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__2__Impl"


    // $ANTLR start "rule__Light__Group__3"
    // InternalSml.g:2394:1: rule__Light__Group__3 : rule__Light__Group__3__Impl rule__Light__Group__4 ;
    public final void rule__Light__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2398:1: ( rule__Light__Group__3__Impl rule__Light__Group__4 )
            // InternalSml.g:2399:2: rule__Light__Group__3__Impl rule__Light__Group__4
            {
            pushFollow(FOLLOW_12);
            rule__Light__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__3"


    // $ANTLR start "rule__Light__Group__3__Impl"
    // InternalSml.g:2406:1: rule__Light__Group__3__Impl : ( 'emitting' ) ;
    public final void rule__Light__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2410:1: ( ( 'emitting' ) )
            // InternalSml.g:2411:1: ( 'emitting' )
            {
            // InternalSml.g:2411:1: ( 'emitting' )
            // InternalSml.g:2412:2: 'emitting'
            {
             before(grammarAccess.getLightAccess().getEmittingKeyword_3()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getEmittingKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__3__Impl"


    // $ANTLR start "rule__Light__Group__4"
    // InternalSml.g:2421:1: rule__Light__Group__4 : rule__Light__Group__4__Impl rule__Light__Group__5 ;
    public final void rule__Light__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2425:1: ( rule__Light__Group__4__Impl rule__Light__Group__5 )
            // InternalSml.g:2426:2: rule__Light__Group__4__Impl rule__Light__Group__5
            {
            pushFollow(FOLLOW_36);
            rule__Light__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__4"


    // $ANTLR start "rule__Light__Group__4__Impl"
    // InternalSml.g:2433:1: rule__Light__Group__4__Impl : ( 'a' ) ;
    public final void rule__Light__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2437:1: ( ( 'a' ) )
            // InternalSml.g:2438:1: ( 'a' )
            {
            // InternalSml.g:2438:1: ( 'a' )
            // InternalSml.g:2439:2: 'a'
            {
             before(grammarAccess.getLightAccess().getAKeyword_4()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getAKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__4__Impl"


    // $ANTLR start "rule__Light__Group__5"
    // InternalSml.g:2448:1: rule__Light__Group__5 : rule__Light__Group__5__Impl rule__Light__Group__6 ;
    public final void rule__Light__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2452:1: ( rule__Light__Group__5__Impl rule__Light__Group__6 )
            // InternalSml.g:2453:2: rule__Light__Group__5__Impl rule__Light__Group__6
            {
            pushFollow(FOLLOW_33);
            rule__Light__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__5"


    // $ANTLR start "rule__Light__Group__5__Impl"
    // InternalSml.g:2460:1: rule__Light__Group__5__Impl : ( ( rule__Light__CAssignment_5 ) ) ;
    public final void rule__Light__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2464:1: ( ( ( rule__Light__CAssignment_5 ) ) )
            // InternalSml.g:2465:1: ( ( rule__Light__CAssignment_5 ) )
            {
            // InternalSml.g:2465:1: ( ( rule__Light__CAssignment_5 ) )
            // InternalSml.g:2466:2: ( rule__Light__CAssignment_5 )
            {
             before(grammarAccess.getLightAccess().getCAssignment_5()); 
            // InternalSml.g:2467:2: ( rule__Light__CAssignment_5 )
            // InternalSml.g:2467:3: rule__Light__CAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__Light__CAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getLightAccess().getCAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__5__Impl"


    // $ANTLR start "rule__Light__Group__6"
    // InternalSml.g:2475:1: rule__Light__Group__6 : rule__Light__Group__6__Impl rule__Light__Group__7 ;
    public final void rule__Light__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2479:1: ( rule__Light__Group__6__Impl rule__Light__Group__7 )
            // InternalSml.g:2480:2: rule__Light__Group__6__Impl rule__Light__Group__7
            {
            pushFollow(FOLLOW_37);
            rule__Light__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__6"


    // $ANTLR start "rule__Light__Group__6__Impl"
    // InternalSml.g:2487:1: rule__Light__Group__6__Impl : ( 'light' ) ;
    public final void rule__Light__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2491:1: ( ( 'light' ) )
            // InternalSml.g:2492:1: ( 'light' )
            {
            // InternalSml.g:2492:1: ( 'light' )
            // InternalSml.g:2493:2: 'light'
            {
             before(grammarAccess.getLightAccess().getLightKeyword_6()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getLightKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__6__Impl"


    // $ANTLR start "rule__Light__Group__7"
    // InternalSml.g:2502:1: rule__Light__Group__7 : rule__Light__Group__7__Impl rule__Light__Group__8 ;
    public final void rule__Light__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2506:1: ( rule__Light__Group__7__Impl rule__Light__Group__8 )
            // InternalSml.g:2507:2: rule__Light__Group__7__Impl rule__Light__Group__8
            {
            pushFollow(FOLLOW_38);
            rule__Light__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__7"


    // $ANTLR start "rule__Light__Group__7__Impl"
    // InternalSml.g:2514:1: rule__Light__Group__7__Impl : ( 'is' ) ;
    public final void rule__Light__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2518:1: ( ( 'is' ) )
            // InternalSml.g:2519:1: ( 'is' )
            {
            // InternalSml.g:2519:1: ( 'is' )
            // InternalSml.g:2520:2: 'is'
            {
             before(grammarAccess.getLightAccess().getIsKeyword_7()); 
            match(input,49,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getIsKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__7__Impl"


    // $ANTLR start "rule__Light__Group__8"
    // InternalSml.g:2529:1: rule__Light__Group__8 : rule__Light__Group__8__Impl rule__Light__Group__9 ;
    public final void rule__Light__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2533:1: ( rule__Light__Group__8__Impl rule__Light__Group__9 )
            // InternalSml.g:2534:2: rule__Light__Group__8__Impl rule__Light__Group__9
            {
            pushFollow(FOLLOW_15);
            rule__Light__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__8"


    // $ANTLR start "rule__Light__Group__8__Impl"
    // InternalSml.g:2541:1: rule__Light__Group__8__Impl : ( 'placed' ) ;
    public final void rule__Light__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2545:1: ( ( 'placed' ) )
            // InternalSml.g:2546:1: ( 'placed' )
            {
            // InternalSml.g:2546:1: ( 'placed' )
            // InternalSml.g:2547:2: 'placed'
            {
             before(grammarAccess.getLightAccess().getPlacedKeyword_8()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getPlacedKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__8__Impl"


    // $ANTLR start "rule__Light__Group__9"
    // InternalSml.g:2556:1: rule__Light__Group__9 : rule__Light__Group__9__Impl rule__Light__Group__10 ;
    public final void rule__Light__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2560:1: ( rule__Light__Group__9__Impl rule__Light__Group__10 )
            // InternalSml.g:2561:2: rule__Light__Group__9__Impl rule__Light__Group__10
            {
            pushFollow(FOLLOW_12);
            rule__Light__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__9"


    // $ANTLR start "rule__Light__Group__9__Impl"
    // InternalSml.g:2568:1: rule__Light__Group__9__Impl : ( 'in' ) ;
    public final void rule__Light__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2572:1: ( ( 'in' ) )
            // InternalSml.g:2573:1: ( 'in' )
            {
            // InternalSml.g:2573:1: ( 'in' )
            // InternalSml.g:2574:2: 'in'
            {
             before(grammarAccess.getLightAccess().getInKeyword_9()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getInKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__9__Impl"


    // $ANTLR start "rule__Light__Group__10"
    // InternalSml.g:2583:1: rule__Light__Group__10 : rule__Light__Group__10__Impl rule__Light__Group__11 ;
    public final void rule__Light__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2587:1: ( rule__Light__Group__10__Impl rule__Light__Group__11 )
            // InternalSml.g:2588:2: rule__Light__Group__10__Impl rule__Light__Group__11
            {
            pushFollow(FOLLOW_39);
            rule__Light__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__10"


    // $ANTLR start "rule__Light__Group__10__Impl"
    // InternalSml.g:2595:1: rule__Light__Group__10__Impl : ( 'a' ) ;
    public final void rule__Light__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2599:1: ( ( 'a' ) )
            // InternalSml.g:2600:1: ( 'a' )
            {
            // InternalSml.g:2600:1: ( 'a' )
            // InternalSml.g:2601:2: 'a'
            {
             before(grammarAccess.getLightAccess().getAKeyword_10()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getAKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__10__Impl"


    // $ANTLR start "rule__Light__Group__11"
    // InternalSml.g:2610:1: rule__Light__Group__11 : rule__Light__Group__11__Impl ;
    public final void rule__Light__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2614:1: ( rule__Light__Group__11__Impl )
            // InternalSml.g:2615:2: rule__Light__Group__11__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Light__Group__11__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__11"


    // $ANTLR start "rule__Light__Group__11__Impl"
    // InternalSml.g:2621:1: rule__Light__Group__11__Impl : ( ( rule__Light__PAssignment_11 ) ) ;
    public final void rule__Light__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2625:1: ( ( ( rule__Light__PAssignment_11 ) ) )
            // InternalSml.g:2626:1: ( ( rule__Light__PAssignment_11 ) )
            {
            // InternalSml.g:2626:1: ( ( rule__Light__PAssignment_11 ) )
            // InternalSml.g:2627:2: ( rule__Light__PAssignment_11 )
            {
             before(grammarAccess.getLightAccess().getPAssignment_11()); 
            // InternalSml.g:2628:2: ( rule__Light__PAssignment_11 )
            // InternalSml.g:2628:3: rule__Light__PAssignment_11
            {
            pushFollow(FOLLOW_2);
            rule__Light__PAssignment_11();

            state._fsp--;


            }

             after(grammarAccess.getLightAccess().getPAssignment_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__11__Impl"


    // $ANTLR start "rule__Position__Group_0__0"
    // InternalSml.g:2637:1: rule__Position__Group_0__0 : rule__Position__Group_0__0__Impl rule__Position__Group_0__1 ;
    public final void rule__Position__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2641:1: ( rule__Position__Group_0__0__Impl rule__Position__Group_0__1 )
            // InternalSml.g:2642:2: rule__Position__Group_0__0__Impl rule__Position__Group_0__1
            {
            pushFollow(FOLLOW_40);
            rule__Position__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Position__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_0__0"


    // $ANTLR start "rule__Position__Group_0__0__Impl"
    // InternalSml.g:2649:1: rule__Position__Group_0__0__Impl : ( () ) ;
    public final void rule__Position__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2653:1: ( ( () ) )
            // InternalSml.g:2654:1: ( () )
            {
            // InternalSml.g:2654:1: ( () )
            // InternalSml.g:2655:2: ()
            {
             before(grammarAccess.getPositionAccess().getCircleAction_0_0()); 
            // InternalSml.g:2656:2: ()
            // InternalSml.g:2656:3: 
            {
            }

             after(grammarAccess.getPositionAccess().getCircleAction_0_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_0__0__Impl"


    // $ANTLR start "rule__Position__Group_0__1"
    // InternalSml.g:2664:1: rule__Position__Group_0__1 : rule__Position__Group_0__1__Impl rule__Position__Group_0__2 ;
    public final void rule__Position__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2668:1: ( rule__Position__Group_0__1__Impl rule__Position__Group_0__2 )
            // InternalSml.g:2669:2: rule__Position__Group_0__1__Impl rule__Position__Group_0__2
            {
            pushFollow(FOLLOW_41);
            rule__Position__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Position__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_0__1"


    // $ANTLR start "rule__Position__Group_0__1__Impl"
    // InternalSml.g:2676:1: rule__Position__Group_0__1__Impl : ( 'center' ) ;
    public final void rule__Position__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2680:1: ( ( 'center' ) )
            // InternalSml.g:2681:1: ( 'center' )
            {
            // InternalSml.g:2681:1: ( 'center' )
            // InternalSml.g:2682:2: 'center'
            {
             before(grammarAccess.getPositionAccess().getCenterKeyword_0_1()); 
            match(input,51,FOLLOW_2); 
             after(grammarAccess.getPositionAccess().getCenterKeyword_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_0__1__Impl"


    // $ANTLR start "rule__Position__Group_0__2"
    // InternalSml.g:2691:1: rule__Position__Group_0__2 : rule__Position__Group_0__2__Impl ;
    public final void rule__Position__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2695:1: ( rule__Position__Group_0__2__Impl )
            // InternalSml.g:2696:2: rule__Position__Group_0__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Position__Group_0__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_0__2"


    // $ANTLR start "rule__Position__Group_0__2__Impl"
    // InternalSml.g:2702:1: rule__Position__Group_0__2__Impl : ( ( rule__Position__PointAssignment_0_2 ) ) ;
    public final void rule__Position__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2706:1: ( ( ( rule__Position__PointAssignment_0_2 ) ) )
            // InternalSml.g:2707:1: ( ( rule__Position__PointAssignment_0_2 ) )
            {
            // InternalSml.g:2707:1: ( ( rule__Position__PointAssignment_0_2 ) )
            // InternalSml.g:2708:2: ( rule__Position__PointAssignment_0_2 )
            {
             before(grammarAccess.getPositionAccess().getPointAssignment_0_2()); 
            // InternalSml.g:2709:2: ( rule__Position__PointAssignment_0_2 )
            // InternalSml.g:2709:3: rule__Position__PointAssignment_0_2
            {
            pushFollow(FOLLOW_2);
            rule__Position__PointAssignment_0_2();

            state._fsp--;


            }

             after(grammarAccess.getPositionAccess().getPointAssignment_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_0__2__Impl"


    // $ANTLR start "rule__Position__Group_1__0"
    // InternalSml.g:2718:1: rule__Position__Group_1__0 : rule__Position__Group_1__0__Impl rule__Position__Group_1__1 ;
    public final void rule__Position__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2722:1: ( rule__Position__Group_1__0__Impl rule__Position__Group_1__1 )
            // InternalSml.g:2723:2: rule__Position__Group_1__0__Impl rule__Position__Group_1__1
            {
            pushFollow(FOLLOW_42);
            rule__Position__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Position__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_1__0"


    // $ANTLR start "rule__Position__Group_1__0__Impl"
    // InternalSml.g:2730:1: rule__Position__Group_1__0__Impl : ( () ) ;
    public final void rule__Position__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2734:1: ( ( () ) )
            // InternalSml.g:2735:1: ( () )
            {
            // InternalSml.g:2735:1: ( () )
            // InternalSml.g:2736:2: ()
            {
             before(grammarAccess.getPositionAccess().getRectangleAction_1_0()); 
            // InternalSml.g:2737:2: ()
            // InternalSml.g:2737:3: 
            {
            }

             after(grammarAccess.getPositionAccess().getRectangleAction_1_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_1__0__Impl"


    // $ANTLR start "rule__Position__Group_1__1"
    // InternalSml.g:2745:1: rule__Position__Group_1__1 : rule__Position__Group_1__1__Impl rule__Position__Group_1__2 ;
    public final void rule__Position__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2749:1: ( rule__Position__Group_1__1__Impl rule__Position__Group_1__2 )
            // InternalSml.g:2750:2: rule__Position__Group_1__1__Impl rule__Position__Group_1__2
            {
            pushFollow(FOLLOW_41);
            rule__Position__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Position__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_1__1"


    // $ANTLR start "rule__Position__Group_1__1__Impl"
    // InternalSml.g:2757:1: rule__Position__Group_1__1__Impl : ( 'reference point' ) ;
    public final void rule__Position__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2761:1: ( ( 'reference point' ) )
            // InternalSml.g:2762:1: ( 'reference point' )
            {
            // InternalSml.g:2762:1: ( 'reference point' )
            // InternalSml.g:2763:2: 'reference point'
            {
             before(grammarAccess.getPositionAccess().getReferencePointKeyword_1_1()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getPositionAccess().getReferencePointKeyword_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_1__1__Impl"


    // $ANTLR start "rule__Position__Group_1__2"
    // InternalSml.g:2772:1: rule__Position__Group_1__2 : rule__Position__Group_1__2__Impl ;
    public final void rule__Position__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2776:1: ( rule__Position__Group_1__2__Impl )
            // InternalSml.g:2777:2: rule__Position__Group_1__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Position__Group_1__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_1__2"


    // $ANTLR start "rule__Position__Group_1__2__Impl"
    // InternalSml.g:2783:1: rule__Position__Group_1__2__Impl : ( ( rule__Position__PointAssignment_1_2 ) ) ;
    public final void rule__Position__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2787:1: ( ( ( rule__Position__PointAssignment_1_2 ) ) )
            // InternalSml.g:2788:1: ( ( rule__Position__PointAssignment_1_2 ) )
            {
            // InternalSml.g:2788:1: ( ( rule__Position__PointAssignment_1_2 ) )
            // InternalSml.g:2789:2: ( rule__Position__PointAssignment_1_2 )
            {
             before(grammarAccess.getPositionAccess().getPointAssignment_1_2()); 
            // InternalSml.g:2790:2: ( rule__Position__PointAssignment_1_2 )
            // InternalSml.g:2790:3: rule__Position__PointAssignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__Position__PointAssignment_1_2();

            state._fsp--;


            }

             after(grammarAccess.getPositionAccess().getPointAssignment_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_1__2__Impl"


    // $ANTLR start "rule__Position__Group_2__0"
    // InternalSml.g:2799:1: rule__Position__Group_2__0 : rule__Position__Group_2__0__Impl rule__Position__Group_2__1 ;
    public final void rule__Position__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2803:1: ( rule__Position__Group_2__0__Impl rule__Position__Group_2__1 )
            // InternalSml.g:2804:2: rule__Position__Group_2__0__Impl rule__Position__Group_2__1
            {
            pushFollow(FOLLOW_39);
            rule__Position__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Position__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_2__0"


    // $ANTLR start "rule__Position__Group_2__0__Impl"
    // InternalSml.g:2811:1: rule__Position__Group_2__0__Impl : ( () ) ;
    public final void rule__Position__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2815:1: ( ( () ) )
            // InternalSml.g:2816:1: ( () )
            {
            // InternalSml.g:2816:1: ( () )
            // InternalSml.g:2817:2: ()
            {
             before(grammarAccess.getPositionAccess().getPointDAction_2_0()); 
            // InternalSml.g:2818:2: ()
            // InternalSml.g:2818:3: 
            {
            }

             after(grammarAccess.getPositionAccess().getPointDAction_2_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_2__0__Impl"


    // $ANTLR start "rule__Position__Group_2__1"
    // InternalSml.g:2826:1: rule__Position__Group_2__1 : rule__Position__Group_2__1__Impl rule__Position__Group_2__2 ;
    public final void rule__Position__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2830:1: ( rule__Position__Group_2__1__Impl rule__Position__Group_2__2 )
            // InternalSml.g:2831:2: rule__Position__Group_2__1__Impl rule__Position__Group_2__2
            {
            pushFollow(FOLLOW_41);
            rule__Position__Group_2__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Position__Group_2__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_2__1"


    // $ANTLR start "rule__Position__Group_2__1__Impl"
    // InternalSml.g:2838:1: rule__Position__Group_2__1__Impl : ( 'point' ) ;
    public final void rule__Position__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2842:1: ( ( 'point' ) )
            // InternalSml.g:2843:1: ( 'point' )
            {
            // InternalSml.g:2843:1: ( 'point' )
            // InternalSml.g:2844:2: 'point'
            {
             before(grammarAccess.getPositionAccess().getPointKeyword_2_1()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getPositionAccess().getPointKeyword_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_2__1__Impl"


    // $ANTLR start "rule__Position__Group_2__2"
    // InternalSml.g:2853:1: rule__Position__Group_2__2 : rule__Position__Group_2__2__Impl ;
    public final void rule__Position__Group_2__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2857:1: ( rule__Position__Group_2__2__Impl )
            // InternalSml.g:2858:2: rule__Position__Group_2__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Position__Group_2__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_2__2"


    // $ANTLR start "rule__Position__Group_2__2__Impl"
    // InternalSml.g:2864:1: rule__Position__Group_2__2__Impl : ( ( rule__Position__PointAssignment_2_2 ) ) ;
    public final void rule__Position__Group_2__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2868:1: ( ( ( rule__Position__PointAssignment_2_2 ) ) )
            // InternalSml.g:2869:1: ( ( rule__Position__PointAssignment_2_2 ) )
            {
            // InternalSml.g:2869:1: ( ( rule__Position__PointAssignment_2_2 ) )
            // InternalSml.g:2870:2: ( rule__Position__PointAssignment_2_2 )
            {
             before(grammarAccess.getPositionAccess().getPointAssignment_2_2()); 
            // InternalSml.g:2871:2: ( rule__Position__PointAssignment_2_2 )
            // InternalSml.g:2871:3: rule__Position__PointAssignment_2_2
            {
            pushFollow(FOLLOW_2);
            rule__Position__PointAssignment_2_2();

            state._fsp--;


            }

             after(grammarAccess.getPositionAccess().getPointAssignment_2_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_2__2__Impl"


    // $ANTLR start "rule__Arena__Group__0"
    // InternalSml.g:2880:1: rule__Arena__Group__0 : rule__Arena__Group__0__Impl rule__Arena__Group__1 ;
    public final void rule__Arena__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2884:1: ( rule__Arena__Group__0__Impl rule__Arena__Group__1 )
            // InternalSml.g:2885:2: rule__Arena__Group__0__Impl rule__Arena__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Arena__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Arena__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Arena__Group__0"


    // $ANTLR start "rule__Arena__Group__0__Impl"
    // InternalSml.g:2892:1: rule__Arena__Group__0__Impl : ( 'The' ) ;
    public final void rule__Arena__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2896:1: ( ( 'The' ) )
            // InternalSml.g:2897:1: ( 'The' )
            {
            // InternalSml.g:2897:1: ( 'The' )
            // InternalSml.g:2898:2: 'The'
            {
             before(grammarAccess.getArenaAccess().getTheKeyword_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getArenaAccess().getTheKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Arena__Group__0__Impl"


    // $ANTLR start "rule__Arena__Group__1"
    // InternalSml.g:2907:1: rule__Arena__Group__1 : rule__Arena__Group__1__Impl rule__Arena__Group__2 ;
    public final void rule__Arena__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2911:1: ( rule__Arena__Group__1__Impl rule__Arena__Group__2 )
            // InternalSml.g:2912:2: rule__Arena__Group__1__Impl rule__Arena__Group__2
            {
            pushFollow(FOLLOW_37);
            rule__Arena__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Arena__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Arena__Group__1"


    // $ANTLR start "rule__Arena__Group__1__Impl"
    // InternalSml.g:2919:1: rule__Arena__Group__1__Impl : ( 'arena' ) ;
    public final void rule__Arena__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2923:1: ( ( 'arena' ) )
            // InternalSml.g:2924:1: ( 'arena' )
            {
            // InternalSml.g:2924:1: ( 'arena' )
            // InternalSml.g:2925:2: 'arena'
            {
             before(grammarAccess.getArenaAccess().getArenaKeyword_1()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getArenaAccess().getArenaKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Arena__Group__1__Impl"


    // $ANTLR start "rule__Arena__Group__2"
    // InternalSml.g:2934:1: rule__Arena__Group__2 : rule__Arena__Group__2__Impl rule__Arena__Group__3 ;
    public final void rule__Arena__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2938:1: ( rule__Arena__Group__2__Impl rule__Arena__Group__3 )
            // InternalSml.g:2939:2: rule__Arena__Group__2__Impl rule__Arena__Group__3
            {
            pushFollow(FOLLOW_12);
            rule__Arena__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Arena__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Arena__Group__2"


    // $ANTLR start "rule__Arena__Group__2__Impl"
    // InternalSml.g:2946:1: rule__Arena__Group__2__Impl : ( 'is' ) ;
    public final void rule__Arena__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2950:1: ( ( 'is' ) )
            // InternalSml.g:2951:1: ( 'is' )
            {
            // InternalSml.g:2951:1: ( 'is' )
            // InternalSml.g:2952:2: 'is'
            {
             before(grammarAccess.getArenaAccess().getIsKeyword_2()); 
            match(input,49,FOLLOW_2); 
             after(grammarAccess.getArenaAccess().getIsKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Arena__Group__2__Impl"


    // $ANTLR start "rule__Arena__Group__3"
    // InternalSml.g:2961:1: rule__Arena__Group__3 : rule__Arena__Group__3__Impl rule__Arena__Group__4 ;
    public final void rule__Arena__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2965:1: ( rule__Arena__Group__3__Impl rule__Arena__Group__4 )
            // InternalSml.g:2966:2: rule__Arena__Group__3__Impl rule__Arena__Group__4
            {
            pushFollow(FOLLOW_16);
            rule__Arena__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Arena__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Arena__Group__3"


    // $ANTLR start "rule__Arena__Group__3__Impl"
    // InternalSml.g:2973:1: rule__Arena__Group__3__Impl : ( 'a' ) ;
    public final void rule__Arena__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2977:1: ( ( 'a' ) )
            // InternalSml.g:2978:1: ( 'a' )
            {
            // InternalSml.g:2978:1: ( 'a' )
            // InternalSml.g:2979:2: 'a'
            {
             before(grammarAccess.getArenaAccess().getAKeyword_3()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getArenaAccess().getAKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Arena__Group__3__Impl"


    // $ANTLR start "rule__Arena__Group__4"
    // InternalSml.g:2988:1: rule__Arena__Group__4 : rule__Arena__Group__4__Impl ;
    public final void rule__Arena__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:2992:1: ( rule__Arena__Group__4__Impl )
            // InternalSml.g:2993:2: rule__Arena__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Arena__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Arena__Group__4"


    // $ANTLR start "rule__Arena__Group__4__Impl"
    // InternalSml.g:2999:1: rule__Arena__Group__4__Impl : ( ( rule__Arena__SAssignment_4 ) ) ;
    public final void rule__Arena__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3003:1: ( ( ( rule__Arena__SAssignment_4 ) ) )
            // InternalSml.g:3004:1: ( ( rule__Arena__SAssignment_4 ) )
            {
            // InternalSml.g:3004:1: ( ( rule__Arena__SAssignment_4 ) )
            // InternalSml.g:3005:2: ( rule__Arena__SAssignment_4 )
            {
             before(grammarAccess.getArenaAccess().getSAssignment_4()); 
            // InternalSml.g:3006:2: ( rule__Arena__SAssignment_4 )
            // InternalSml.g:3006:3: rule__Arena__SAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Arena__SAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getArenaAccess().getSAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Arena__Group__4__Impl"


    // $ANTLR start "rule__Region__Group__0"
    // InternalSml.g:3015:1: rule__Region__Group__0 : rule__Region__Group__0__Impl rule__Region__Group__1 ;
    public final void rule__Region__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3019:1: ( rule__Region__Group__0__Impl rule__Region__Group__1 )
            // InternalSml.g:3020:2: rule__Region__Group__0__Impl rule__Region__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__Region__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Region__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group__0"


    // $ANTLR start "rule__Region__Group__0__Impl"
    // InternalSml.g:3027:1: rule__Region__Group__0__Impl : ( ( rule__Region__ColorsAssignment_0 )? ) ;
    public final void rule__Region__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3031:1: ( ( ( rule__Region__ColorsAssignment_0 )? ) )
            // InternalSml.g:3032:1: ( ( rule__Region__ColorsAssignment_0 )? )
            {
            // InternalSml.g:3032:1: ( ( rule__Region__ColorsAssignment_0 )? )
            // InternalSml.g:3033:2: ( rule__Region__ColorsAssignment_0 )?
            {
             before(grammarAccess.getRegionAccess().getColorsAssignment_0()); 
            // InternalSml.g:3034:2: ( rule__Region__ColorsAssignment_0 )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( ((LA12_0>=22 && LA12_0<=24)) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalSml.g:3034:3: rule__Region__ColorsAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Region__ColorsAssignment_0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRegionAccess().getColorsAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group__0__Impl"


    // $ANTLR start "rule__Region__Group__1"
    // InternalSml.g:3042:1: rule__Region__Group__1 : rule__Region__Group__1__Impl rule__Region__Group__2 ;
    public final void rule__Region__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3046:1: ( rule__Region__Group__1__Impl rule__Region__Group__2 )
            // InternalSml.g:3047:2: rule__Region__Group__1__Impl rule__Region__Group__2
            {
            pushFollow(FOLLOW_16);
            rule__Region__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Region__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group__1"


    // $ANTLR start "rule__Region__Group__1__Impl"
    // InternalSml.g:3054:1: rule__Region__Group__1__Impl : ( ( rule__Region__ShapeAssignment_1 )? ) ;
    public final void rule__Region__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3058:1: ( ( ( rule__Region__ShapeAssignment_1 )? ) )
            // InternalSml.g:3059:1: ( ( rule__Region__ShapeAssignment_1 )? )
            {
            // InternalSml.g:3059:1: ( ( rule__Region__ShapeAssignment_1 )? )
            // InternalSml.g:3060:2: ( rule__Region__ShapeAssignment_1 )?
            {
             before(grammarAccess.getRegionAccess().getShapeAssignment_1()); 
            // InternalSml.g:3061:2: ( rule__Region__ShapeAssignment_1 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( ((LA13_0>=18 && LA13_0<=21)) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalSml.g:3061:3: rule__Region__ShapeAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Region__ShapeAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRegionAccess().getShapeAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group__1__Impl"


    // $ANTLR start "rule__Region__Group__2"
    // InternalSml.g:3069:1: rule__Region__Group__2 : rule__Region__Group__2__Impl rule__Region__Group__3 ;
    public final void rule__Region__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3073:1: ( rule__Region__Group__2__Impl rule__Region__Group__3 )
            // InternalSml.g:3074:2: rule__Region__Group__2__Impl rule__Region__Group__3
            {
            pushFollow(FOLLOW_43);
            rule__Region__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Region__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group__2"


    // $ANTLR start "rule__Region__Group__2__Impl"
    // InternalSml.g:3081:1: rule__Region__Group__2__Impl : ( ( rule__Region__NameAssignment_2 ) ) ;
    public final void rule__Region__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3085:1: ( ( ( rule__Region__NameAssignment_2 ) ) )
            // InternalSml.g:3086:1: ( ( rule__Region__NameAssignment_2 ) )
            {
            // InternalSml.g:3086:1: ( ( rule__Region__NameAssignment_2 ) )
            // InternalSml.g:3087:2: ( rule__Region__NameAssignment_2 )
            {
             before(grammarAccess.getRegionAccess().getNameAssignment_2()); 
            // InternalSml.g:3088:2: ( rule__Region__NameAssignment_2 )
            // InternalSml.g:3088:3: rule__Region__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Region__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getRegionAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group__2__Impl"


    // $ANTLR start "rule__Region__Group__3"
    // InternalSml.g:3096:1: rule__Region__Group__3 : rule__Region__Group__3__Impl rule__Region__Group__4 ;
    public final void rule__Region__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3100:1: ( rule__Region__Group__3__Impl rule__Region__Group__4 )
            // InternalSml.g:3101:2: rule__Region__Group__3__Impl rule__Region__Group__4
            {
            pushFollow(FOLLOW_43);
            rule__Region__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Region__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group__3"


    // $ANTLR start "rule__Region__Group__3__Impl"
    // InternalSml.g:3108:1: rule__Region__Group__3__Impl : ( ( rule__Region__Group_3__0 )? ) ;
    public final void rule__Region__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3112:1: ( ( ( rule__Region__Group_3__0 )? ) )
            // InternalSml.g:3113:1: ( ( rule__Region__Group_3__0 )? )
            {
            // InternalSml.g:3113:1: ( ( rule__Region__Group_3__0 )? )
            // InternalSml.g:3114:2: ( rule__Region__Group_3__0 )?
            {
             before(grammarAccess.getRegionAccess().getGroup_3()); 
            // InternalSml.g:3115:2: ( rule__Region__Group_3__0 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==33) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalSml.g:3115:3: rule__Region__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Region__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRegionAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group__3__Impl"


    // $ANTLR start "rule__Region__Group__4"
    // InternalSml.g:3123:1: rule__Region__Group__4 : rule__Region__Group__4__Impl ;
    public final void rule__Region__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3127:1: ( rule__Region__Group__4__Impl )
            // InternalSml.g:3128:2: rule__Region__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Region__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group__4"


    // $ANTLR start "rule__Region__Group__4__Impl"
    // InternalSml.g:3134:1: rule__Region__Group__4__Impl : ( ( rule__Region__Group_4__0 )? ) ;
    public final void rule__Region__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3138:1: ( ( ( rule__Region__Group_4__0 )? ) )
            // InternalSml.g:3139:1: ( ( rule__Region__Group_4__0 )? )
            {
            // InternalSml.g:3139:1: ( ( rule__Region__Group_4__0 )? )
            // InternalSml.g:3140:2: ( rule__Region__Group_4__0 )?
            {
             before(grammarAccess.getRegionAccess().getGroup_4()); 
            // InternalSml.g:3141:2: ( rule__Region__Group_4__0 )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==54) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalSml.g:3141:3: rule__Region__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Region__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRegionAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group__4__Impl"


    // $ANTLR start "rule__Region__Group_3__0"
    // InternalSml.g:3150:1: rule__Region__Group_3__0 : rule__Region__Group_3__0__Impl rule__Region__Group_3__1 ;
    public final void rule__Region__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3154:1: ( rule__Region__Group_3__0__Impl rule__Region__Group_3__1 )
            // InternalSml.g:3155:2: rule__Region__Group_3__0__Impl rule__Region__Group_3__1
            {
            pushFollow(FOLLOW_39);
            rule__Region__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Region__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group_3__0"


    // $ANTLR start "rule__Region__Group_3__0__Impl"
    // InternalSml.g:3162:1: rule__Region__Group_3__0__Impl : ( 'with' ) ;
    public final void rule__Region__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3166:1: ( ( 'with' ) )
            // InternalSml.g:3167:1: ( 'with' )
            {
            // InternalSml.g:3167:1: ( 'with' )
            // InternalSml.g:3168:2: 'with'
            {
             before(grammarAccess.getRegionAccess().getWithKeyword_3_0()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getRegionAccess().getWithKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group_3__0__Impl"


    // $ANTLR start "rule__Region__Group_3__1"
    // InternalSml.g:3177:1: rule__Region__Group_3__1 : rule__Region__Group_3__1__Impl ;
    public final void rule__Region__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3181:1: ( rule__Region__Group_3__1__Impl )
            // InternalSml.g:3182:2: rule__Region__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Region__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group_3__1"


    // $ANTLR start "rule__Region__Group_3__1__Impl"
    // InternalSml.g:3188:1: rule__Region__Group_3__1__Impl : ( ( rule__Region__ReferencepointAssignment_3_1 ) ) ;
    public final void rule__Region__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3192:1: ( ( ( rule__Region__ReferencepointAssignment_3_1 ) ) )
            // InternalSml.g:3193:1: ( ( rule__Region__ReferencepointAssignment_3_1 ) )
            {
            // InternalSml.g:3193:1: ( ( rule__Region__ReferencepointAssignment_3_1 ) )
            // InternalSml.g:3194:2: ( rule__Region__ReferencepointAssignment_3_1 )
            {
             before(grammarAccess.getRegionAccess().getReferencepointAssignment_3_1()); 
            // InternalSml.g:3195:2: ( rule__Region__ReferencepointAssignment_3_1 )
            // InternalSml.g:3195:3: rule__Region__ReferencepointAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Region__ReferencepointAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getRegionAccess().getReferencepointAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group_3__1__Impl"


    // $ANTLR start "rule__Region__Group_4__0"
    // InternalSml.g:3204:1: rule__Region__Group_4__0 : rule__Region__Group_4__0__Impl rule__Region__Group_4__1 ;
    public final void rule__Region__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3208:1: ( rule__Region__Group_4__0__Impl rule__Region__Group_4__1 )
            // InternalSml.g:3209:2: rule__Region__Group_4__0__Impl rule__Region__Group_4__1
            {
            pushFollow(FOLLOW_44);
            rule__Region__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Region__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group_4__0"


    // $ANTLR start "rule__Region__Group_4__0__Impl"
    // InternalSml.g:3216:1: rule__Region__Group_4__0__Impl : ( 'and' ) ;
    public final void rule__Region__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3220:1: ( ( 'and' ) )
            // InternalSml.g:3221:1: ( 'and' )
            {
            // InternalSml.g:3221:1: ( 'and' )
            // InternalSml.g:3222:2: 'and'
            {
             before(grammarAccess.getRegionAccess().getAndKeyword_4_0()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getRegionAccess().getAndKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group_4__0__Impl"


    // $ANTLR start "rule__Region__Group_4__1"
    // InternalSml.g:3231:1: rule__Region__Group_4__1 : rule__Region__Group_4__1__Impl ;
    public final void rule__Region__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3235:1: ( rule__Region__Group_4__1__Impl )
            // InternalSml.g:3236:2: rule__Region__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Region__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group_4__1"


    // $ANTLR start "rule__Region__Group_4__1__Impl"
    // InternalSml.g:3242:1: rule__Region__Group_4__1__Impl : ( ( rule__Region__DimensionsAssignment_4_1 ) ) ;
    public final void rule__Region__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3246:1: ( ( ( rule__Region__DimensionsAssignment_4_1 ) ) )
            // InternalSml.g:3247:1: ( ( rule__Region__DimensionsAssignment_4_1 ) )
            {
            // InternalSml.g:3247:1: ( ( rule__Region__DimensionsAssignment_4_1 ) )
            // InternalSml.g:3248:2: ( rule__Region__DimensionsAssignment_4_1 )
            {
             before(grammarAccess.getRegionAccess().getDimensionsAssignment_4_1()); 
            // InternalSml.g:3249:2: ( rule__Region__DimensionsAssignment_4_1 )
            // InternalSml.g:3249:3: rule__Region__DimensionsAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Region__DimensionsAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getRegionAccess().getDimensionsAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__Group_4__1__Impl"


    // $ANTLR start "rule__CircleD__Group__0"
    // InternalSml.g:3258:1: rule__CircleD__Group__0 : rule__CircleD__Group__0__Impl rule__CircleD__Group__1 ;
    public final void rule__CircleD__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3262:1: ( rule__CircleD__Group__0__Impl rule__CircleD__Group__1 )
            // InternalSml.g:3263:2: rule__CircleD__Group__0__Impl rule__CircleD__Group__1
            {
            pushFollow(FOLLOW_41);
            rule__CircleD__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CircleD__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CircleD__Group__0"


    // $ANTLR start "rule__CircleD__Group__0__Impl"
    // InternalSml.g:3270:1: rule__CircleD__Group__0__Impl : ( 'radius' ) ;
    public final void rule__CircleD__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3274:1: ( ( 'radius' ) )
            // InternalSml.g:3275:1: ( 'radius' )
            {
            // InternalSml.g:3275:1: ( 'radius' )
            // InternalSml.g:3276:2: 'radius'
            {
             before(grammarAccess.getCircleDAccess().getRadiusKeyword_0()); 
            match(input,55,FOLLOW_2); 
             after(grammarAccess.getCircleDAccess().getRadiusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CircleD__Group__0__Impl"


    // $ANTLR start "rule__CircleD__Group__1"
    // InternalSml.g:3285:1: rule__CircleD__Group__1 : rule__CircleD__Group__1__Impl ;
    public final void rule__CircleD__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3289:1: ( rule__CircleD__Group__1__Impl )
            // InternalSml.g:3290:2: rule__CircleD__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__CircleD__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CircleD__Group__1"


    // $ANTLR start "rule__CircleD__Group__1__Impl"
    // InternalSml.g:3296:1: rule__CircleD__Group__1__Impl : ( ( rule__CircleD__RAssignment_1 ) ) ;
    public final void rule__CircleD__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3300:1: ( ( ( rule__CircleD__RAssignment_1 ) ) )
            // InternalSml.g:3301:1: ( ( rule__CircleD__RAssignment_1 ) )
            {
            // InternalSml.g:3301:1: ( ( rule__CircleD__RAssignment_1 ) )
            // InternalSml.g:3302:2: ( rule__CircleD__RAssignment_1 )
            {
             before(grammarAccess.getCircleDAccess().getRAssignment_1()); 
            // InternalSml.g:3303:2: ( rule__CircleD__RAssignment_1 )
            // InternalSml.g:3303:3: rule__CircleD__RAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__CircleD__RAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getCircleDAccess().getRAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CircleD__Group__1__Impl"


    // $ANTLR start "rule__RectangleD__Group__0"
    // InternalSml.g:3312:1: rule__RectangleD__Group__0 : rule__RectangleD__Group__0__Impl rule__RectangleD__Group__1 ;
    public final void rule__RectangleD__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3316:1: ( rule__RectangleD__Group__0__Impl rule__RectangleD__Group__1 )
            // InternalSml.g:3317:2: rule__RectangleD__Group__0__Impl rule__RectangleD__Group__1
            {
            pushFollow(FOLLOW_41);
            rule__RectangleD__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RectangleD__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__0"


    // $ANTLR start "rule__RectangleD__Group__0__Impl"
    // InternalSml.g:3324:1: rule__RectangleD__Group__0__Impl : ( 'length' ) ;
    public final void rule__RectangleD__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3328:1: ( ( 'length' ) )
            // InternalSml.g:3329:1: ( 'length' )
            {
            // InternalSml.g:3329:1: ( 'length' )
            // InternalSml.g:3330:2: 'length'
            {
             before(grammarAccess.getRectangleDAccess().getLengthKeyword_0()); 
            match(input,56,FOLLOW_2); 
             after(grammarAccess.getRectangleDAccess().getLengthKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__0__Impl"


    // $ANTLR start "rule__RectangleD__Group__1"
    // InternalSml.g:3339:1: rule__RectangleD__Group__1 : rule__RectangleD__Group__1__Impl rule__RectangleD__Group__2 ;
    public final void rule__RectangleD__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3343:1: ( rule__RectangleD__Group__1__Impl rule__RectangleD__Group__2 )
            // InternalSml.g:3344:2: rule__RectangleD__Group__1__Impl rule__RectangleD__Group__2
            {
            pushFollow(FOLLOW_45);
            rule__RectangleD__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RectangleD__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__1"


    // $ANTLR start "rule__RectangleD__Group__1__Impl"
    // InternalSml.g:3351:1: rule__RectangleD__Group__1__Impl : ( ( rule__RectangleD__LAssignment_1 ) ) ;
    public final void rule__RectangleD__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3355:1: ( ( ( rule__RectangleD__LAssignment_1 ) ) )
            // InternalSml.g:3356:1: ( ( rule__RectangleD__LAssignment_1 ) )
            {
            // InternalSml.g:3356:1: ( ( rule__RectangleD__LAssignment_1 ) )
            // InternalSml.g:3357:2: ( rule__RectangleD__LAssignment_1 )
            {
             before(grammarAccess.getRectangleDAccess().getLAssignment_1()); 
            // InternalSml.g:3358:2: ( rule__RectangleD__LAssignment_1 )
            // InternalSml.g:3358:3: rule__RectangleD__LAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__RectangleD__LAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getRectangleDAccess().getLAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__1__Impl"


    // $ANTLR start "rule__RectangleD__Group__2"
    // InternalSml.g:3366:1: rule__RectangleD__Group__2 : rule__RectangleD__Group__2__Impl rule__RectangleD__Group__3 ;
    public final void rule__RectangleD__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3370:1: ( rule__RectangleD__Group__2__Impl rule__RectangleD__Group__3 )
            // InternalSml.g:3371:2: rule__RectangleD__Group__2__Impl rule__RectangleD__Group__3
            {
            pushFollow(FOLLOW_41);
            rule__RectangleD__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RectangleD__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__2"


    // $ANTLR start "rule__RectangleD__Group__2__Impl"
    // InternalSml.g:3378:1: rule__RectangleD__Group__2__Impl : ( ',width' ) ;
    public final void rule__RectangleD__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3382:1: ( ( ',width' ) )
            // InternalSml.g:3383:1: ( ',width' )
            {
            // InternalSml.g:3383:1: ( ',width' )
            // InternalSml.g:3384:2: ',width'
            {
             before(grammarAccess.getRectangleDAccess().getWidthKeyword_2()); 
            match(input,57,FOLLOW_2); 
             after(grammarAccess.getRectangleDAccess().getWidthKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__2__Impl"


    // $ANTLR start "rule__RectangleD__Group__3"
    // InternalSml.g:3393:1: rule__RectangleD__Group__3 : rule__RectangleD__Group__3__Impl rule__RectangleD__Group__4 ;
    public final void rule__RectangleD__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3397:1: ( rule__RectangleD__Group__3__Impl rule__RectangleD__Group__4 )
            // InternalSml.g:3398:2: rule__RectangleD__Group__3__Impl rule__RectangleD__Group__4
            {
            pushFollow(FOLLOW_46);
            rule__RectangleD__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RectangleD__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__3"


    // $ANTLR start "rule__RectangleD__Group__3__Impl"
    // InternalSml.g:3405:1: rule__RectangleD__Group__3__Impl : ( ( rule__RectangleD__WAssignment_3 ) ) ;
    public final void rule__RectangleD__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3409:1: ( ( ( rule__RectangleD__WAssignment_3 ) ) )
            // InternalSml.g:3410:1: ( ( rule__RectangleD__WAssignment_3 ) )
            {
            // InternalSml.g:3410:1: ( ( rule__RectangleD__WAssignment_3 ) )
            // InternalSml.g:3411:2: ( rule__RectangleD__WAssignment_3 )
            {
             before(grammarAccess.getRectangleDAccess().getWAssignment_3()); 
            // InternalSml.g:3412:2: ( rule__RectangleD__WAssignment_3 )
            // InternalSml.g:3412:3: rule__RectangleD__WAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__RectangleD__WAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getRectangleDAccess().getWAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__3__Impl"


    // $ANTLR start "rule__RectangleD__Group__4"
    // InternalSml.g:3420:1: rule__RectangleD__Group__4 : rule__RectangleD__Group__4__Impl rule__RectangleD__Group__5 ;
    public final void rule__RectangleD__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3424:1: ( rule__RectangleD__Group__4__Impl rule__RectangleD__Group__5 )
            // InternalSml.g:3425:2: rule__RectangleD__Group__4__Impl rule__RectangleD__Group__5
            {
            pushFollow(FOLLOW_47);
            rule__RectangleD__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RectangleD__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__4"


    // $ANTLR start "rule__RectangleD__Group__4__Impl"
    // InternalSml.g:3432:1: rule__RectangleD__Group__4__Impl : ( 'and' ) ;
    public final void rule__RectangleD__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3436:1: ( ( 'and' ) )
            // InternalSml.g:3437:1: ( 'and' )
            {
            // InternalSml.g:3437:1: ( 'and' )
            // InternalSml.g:3438:2: 'and'
            {
             before(grammarAccess.getRectangleDAccess().getAndKeyword_4()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getRectangleDAccess().getAndKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__4__Impl"


    // $ANTLR start "rule__RectangleD__Group__5"
    // InternalSml.g:3447:1: rule__RectangleD__Group__5 : rule__RectangleD__Group__5__Impl rule__RectangleD__Group__6 ;
    public final void rule__RectangleD__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3451:1: ( rule__RectangleD__Group__5__Impl rule__RectangleD__Group__6 )
            // InternalSml.g:3452:2: rule__RectangleD__Group__5__Impl rule__RectangleD__Group__6
            {
            pushFollow(FOLLOW_41);
            rule__RectangleD__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RectangleD__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__5"


    // $ANTLR start "rule__RectangleD__Group__5__Impl"
    // InternalSml.g:3459:1: rule__RectangleD__Group__5__Impl : ( 'height' ) ;
    public final void rule__RectangleD__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3463:1: ( ( 'height' ) )
            // InternalSml.g:3464:1: ( 'height' )
            {
            // InternalSml.g:3464:1: ( 'height' )
            // InternalSml.g:3465:2: 'height'
            {
             before(grammarAccess.getRectangleDAccess().getHeightKeyword_5()); 
            match(input,58,FOLLOW_2); 
             after(grammarAccess.getRectangleDAccess().getHeightKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__5__Impl"


    // $ANTLR start "rule__RectangleD__Group__6"
    // InternalSml.g:3474:1: rule__RectangleD__Group__6 : rule__RectangleD__Group__6__Impl ;
    public final void rule__RectangleD__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3478:1: ( rule__RectangleD__Group__6__Impl )
            // InternalSml.g:3479:2: rule__RectangleD__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__RectangleD__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__6"


    // $ANTLR start "rule__RectangleD__Group__6__Impl"
    // InternalSml.g:3485:1: rule__RectangleD__Group__6__Impl : ( ( rule__RectangleD__HAssignment_6 ) ) ;
    public final void rule__RectangleD__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3489:1: ( ( ( rule__RectangleD__HAssignment_6 ) ) )
            // InternalSml.g:3490:1: ( ( rule__RectangleD__HAssignment_6 ) )
            {
            // InternalSml.g:3490:1: ( ( rule__RectangleD__HAssignment_6 ) )
            // InternalSml.g:3491:2: ( rule__RectangleD__HAssignment_6 )
            {
             before(grammarAccess.getRectangleDAccess().getHAssignment_6()); 
            // InternalSml.g:3492:2: ( rule__RectangleD__HAssignment_6 )
            // InternalSml.g:3492:3: rule__RectangleD__HAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__RectangleD__HAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getRectangleDAccess().getHAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__Group__6__Impl"


    // $ANTLR start "rule__Coordinate__Group__0"
    // InternalSml.g:3501:1: rule__Coordinate__Group__0 : rule__Coordinate__Group__0__Impl rule__Coordinate__Group__1 ;
    public final void rule__Coordinate__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3505:1: ( rule__Coordinate__Group__0__Impl rule__Coordinate__Group__1 )
            // InternalSml.g:3506:2: rule__Coordinate__Group__0__Impl rule__Coordinate__Group__1
            {
            pushFollow(FOLLOW_41);
            rule__Coordinate__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Coordinate__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__0"


    // $ANTLR start "rule__Coordinate__Group__0__Impl"
    // InternalSml.g:3513:1: rule__Coordinate__Group__0__Impl : ( ( rule__Coordinate__XAssignment_0 ) ) ;
    public final void rule__Coordinate__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3517:1: ( ( ( rule__Coordinate__XAssignment_0 ) ) )
            // InternalSml.g:3518:1: ( ( rule__Coordinate__XAssignment_0 ) )
            {
            // InternalSml.g:3518:1: ( ( rule__Coordinate__XAssignment_0 ) )
            // InternalSml.g:3519:2: ( rule__Coordinate__XAssignment_0 )
            {
             before(grammarAccess.getCoordinateAccess().getXAssignment_0()); 
            // InternalSml.g:3520:2: ( rule__Coordinate__XAssignment_0 )
            // InternalSml.g:3520:3: rule__Coordinate__XAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Coordinate__XAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getCoordinateAccess().getXAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__0__Impl"


    // $ANTLR start "rule__Coordinate__Group__1"
    // InternalSml.g:3528:1: rule__Coordinate__Group__1 : rule__Coordinate__Group__1__Impl ;
    public final void rule__Coordinate__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3532:1: ( rule__Coordinate__Group__1__Impl )
            // InternalSml.g:3533:2: rule__Coordinate__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Coordinate__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__1"


    // $ANTLR start "rule__Coordinate__Group__1__Impl"
    // InternalSml.g:3539:1: rule__Coordinate__Group__1__Impl : ( ( rule__Coordinate__YAssignment_1 ) ) ;
    public final void rule__Coordinate__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3543:1: ( ( ( rule__Coordinate__YAssignment_1 ) ) )
            // InternalSml.g:3544:1: ( ( rule__Coordinate__YAssignment_1 ) )
            {
            // InternalSml.g:3544:1: ( ( rule__Coordinate__YAssignment_1 ) )
            // InternalSml.g:3545:2: ( rule__Coordinate__YAssignment_1 )
            {
             before(grammarAccess.getCoordinateAccess().getYAssignment_1()); 
            // InternalSml.g:3546:2: ( rule__Coordinate__YAssignment_1 )
            // InternalSml.g:3546:3: rule__Coordinate__YAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Coordinate__YAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getCoordinateAccess().getYAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__Group__1__Impl"


    // $ANTLR start "rule__Double__Group__0"
    // InternalSml.g:3555:1: rule__Double__Group__0 : rule__Double__Group__0__Impl rule__Double__Group__1 ;
    public final void rule__Double__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3559:1: ( rule__Double__Group__0__Impl rule__Double__Group__1 )
            // InternalSml.g:3560:2: rule__Double__Group__0__Impl rule__Double__Group__1
            {
            pushFollow(FOLLOW_48);
            rule__Double__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Double__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Double__Group__0"


    // $ANTLR start "rule__Double__Group__0__Impl"
    // InternalSml.g:3567:1: rule__Double__Group__0__Impl : ( RULE_INT ) ;
    public final void rule__Double__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3571:1: ( ( RULE_INT ) )
            // InternalSml.g:3572:1: ( RULE_INT )
            {
            // InternalSml.g:3572:1: ( RULE_INT )
            // InternalSml.g:3573:2: RULE_INT
            {
             before(grammarAccess.getDoubleAccess().getINTTerminalRuleCall_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getDoubleAccess().getINTTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Double__Group__0__Impl"


    // $ANTLR start "rule__Double__Group__1"
    // InternalSml.g:3582:1: rule__Double__Group__1 : rule__Double__Group__1__Impl rule__Double__Group__2 ;
    public final void rule__Double__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3586:1: ( rule__Double__Group__1__Impl rule__Double__Group__2 )
            // InternalSml.g:3587:2: rule__Double__Group__1__Impl rule__Double__Group__2
            {
            pushFollow(FOLLOW_41);
            rule__Double__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Double__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Double__Group__1"


    // $ANTLR start "rule__Double__Group__1__Impl"
    // InternalSml.g:3594:1: rule__Double__Group__1__Impl : ( '.' ) ;
    public final void rule__Double__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3598:1: ( ( '.' ) )
            // InternalSml.g:3599:1: ( '.' )
            {
            // InternalSml.g:3599:1: ( '.' )
            // InternalSml.g:3600:2: '.'
            {
             before(grammarAccess.getDoubleAccess().getFullStopKeyword_1()); 
            match(input,59,FOLLOW_2); 
             after(grammarAccess.getDoubleAccess().getFullStopKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Double__Group__1__Impl"


    // $ANTLR start "rule__Double__Group__2"
    // InternalSml.g:3609:1: rule__Double__Group__2 : rule__Double__Group__2__Impl ;
    public final void rule__Double__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3613:1: ( rule__Double__Group__2__Impl )
            // InternalSml.g:3614:2: rule__Double__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Double__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Double__Group__2"


    // $ANTLR start "rule__Double__Group__2__Impl"
    // InternalSml.g:3620:1: rule__Double__Group__2__Impl : ( RULE_INT ) ;
    public final void rule__Double__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3624:1: ( ( RULE_INT ) )
            // InternalSml.g:3625:1: ( RULE_INT )
            {
            // InternalSml.g:3625:1: ( RULE_INT )
            // InternalSml.g:3626:2: RULE_INT
            {
             before(grammarAccess.getDoubleAccess().getINTTerminalRuleCall_2()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getDoubleAccess().getINTTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Double__Group__2__Impl"


    // $ANTLR start "rule__Lowerbound__Group__0"
    // InternalSml.g:3636:1: rule__Lowerbound__Group__0 : rule__Lowerbound__Group__0__Impl rule__Lowerbound__Group__1 ;
    public final void rule__Lowerbound__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3640:1: ( rule__Lowerbound__Group__0__Impl rule__Lowerbound__Group__1 )
            // InternalSml.g:3641:2: rule__Lowerbound__Group__0__Impl rule__Lowerbound__Group__1
            {
            pushFollow(FOLLOW_49);
            rule__Lowerbound__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Lowerbound__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lowerbound__Group__0"


    // $ANTLR start "rule__Lowerbound__Group__0__Impl"
    // InternalSml.g:3648:1: rule__Lowerbound__Group__0__Impl : ( 'less' ) ;
    public final void rule__Lowerbound__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3652:1: ( ( 'less' ) )
            // InternalSml.g:3653:1: ( 'less' )
            {
            // InternalSml.g:3653:1: ( 'less' )
            // InternalSml.g:3654:2: 'less'
            {
             before(grammarAccess.getLowerboundAccess().getLessKeyword_0()); 
            match(input,60,FOLLOW_2); 
             after(grammarAccess.getLowerboundAccess().getLessKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lowerbound__Group__0__Impl"


    // $ANTLR start "rule__Lowerbound__Group__1"
    // InternalSml.g:3663:1: rule__Lowerbound__Group__1 : rule__Lowerbound__Group__1__Impl rule__Lowerbound__Group__2 ;
    public final void rule__Lowerbound__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3667:1: ( rule__Lowerbound__Group__1__Impl rule__Lowerbound__Group__2 )
            // InternalSml.g:3668:2: rule__Lowerbound__Group__1__Impl rule__Lowerbound__Group__2
            {
            pushFollow(FOLLOW_41);
            rule__Lowerbound__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Lowerbound__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lowerbound__Group__1"


    // $ANTLR start "rule__Lowerbound__Group__1__Impl"
    // InternalSml.g:3675:1: rule__Lowerbound__Group__1__Impl : ( 'than' ) ;
    public final void rule__Lowerbound__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3679:1: ( ( 'than' ) )
            // InternalSml.g:3680:1: ( 'than' )
            {
            // InternalSml.g:3680:1: ( 'than' )
            // InternalSml.g:3681:2: 'than'
            {
             before(grammarAccess.getLowerboundAccess().getThanKeyword_1()); 
            match(input,61,FOLLOW_2); 
             after(grammarAccess.getLowerboundAccess().getThanKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lowerbound__Group__1__Impl"


    // $ANTLR start "rule__Lowerbound__Group__2"
    // InternalSml.g:3690:1: rule__Lowerbound__Group__2 : rule__Lowerbound__Group__2__Impl ;
    public final void rule__Lowerbound__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3694:1: ( rule__Lowerbound__Group__2__Impl )
            // InternalSml.g:3695:2: rule__Lowerbound__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Lowerbound__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lowerbound__Group__2"


    // $ANTLR start "rule__Lowerbound__Group__2__Impl"
    // InternalSml.g:3701:1: rule__Lowerbound__Group__2__Impl : ( ( rule__Lowerbound__NAssignment_2 ) ) ;
    public final void rule__Lowerbound__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3705:1: ( ( ( rule__Lowerbound__NAssignment_2 ) ) )
            // InternalSml.g:3706:1: ( ( rule__Lowerbound__NAssignment_2 ) )
            {
            // InternalSml.g:3706:1: ( ( rule__Lowerbound__NAssignment_2 ) )
            // InternalSml.g:3707:2: ( rule__Lowerbound__NAssignment_2 )
            {
             before(grammarAccess.getLowerboundAccess().getNAssignment_2()); 
            // InternalSml.g:3708:2: ( rule__Lowerbound__NAssignment_2 )
            // InternalSml.g:3708:3: rule__Lowerbound__NAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Lowerbound__NAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getLowerboundAccess().getNAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lowerbound__Group__2__Impl"


    // $ANTLR start "rule__LowerorEqualbound__Group__0"
    // InternalSml.g:3717:1: rule__LowerorEqualbound__Group__0 : rule__LowerorEqualbound__Group__0__Impl rule__LowerorEqualbound__Group__1 ;
    public final void rule__LowerorEqualbound__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3721:1: ( rule__LowerorEqualbound__Group__0__Impl rule__LowerorEqualbound__Group__1 )
            // InternalSml.g:3722:2: rule__LowerorEqualbound__Group__0__Impl rule__LowerorEqualbound__Group__1
            {
            pushFollow(FOLLOW_50);
            rule__LowerorEqualbound__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LowerorEqualbound__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LowerorEqualbound__Group__0"


    // $ANTLR start "rule__LowerorEqualbound__Group__0__Impl"
    // InternalSml.g:3729:1: rule__LowerorEqualbound__Group__0__Impl : ( 'less' ) ;
    public final void rule__LowerorEqualbound__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3733:1: ( ( 'less' ) )
            // InternalSml.g:3734:1: ( 'less' )
            {
            // InternalSml.g:3734:1: ( 'less' )
            // InternalSml.g:3735:2: 'less'
            {
             before(grammarAccess.getLowerorEqualboundAccess().getLessKeyword_0()); 
            match(input,60,FOLLOW_2); 
             after(grammarAccess.getLowerorEqualboundAccess().getLessKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LowerorEqualbound__Group__0__Impl"


    // $ANTLR start "rule__LowerorEqualbound__Group__1"
    // InternalSml.g:3744:1: rule__LowerorEqualbound__Group__1 : rule__LowerorEqualbound__Group__1__Impl rule__LowerorEqualbound__Group__2 ;
    public final void rule__LowerorEqualbound__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3748:1: ( rule__LowerorEqualbound__Group__1__Impl rule__LowerorEqualbound__Group__2 )
            // InternalSml.g:3749:2: rule__LowerorEqualbound__Group__1__Impl rule__LowerorEqualbound__Group__2
            {
            pushFollow(FOLLOW_51);
            rule__LowerorEqualbound__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LowerorEqualbound__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LowerorEqualbound__Group__1"


    // $ANTLR start "rule__LowerorEqualbound__Group__1__Impl"
    // InternalSml.g:3756:1: rule__LowerorEqualbound__Group__1__Impl : ( 'or' ) ;
    public final void rule__LowerorEqualbound__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3760:1: ( ( 'or' ) )
            // InternalSml.g:3761:1: ( 'or' )
            {
            // InternalSml.g:3761:1: ( 'or' )
            // InternalSml.g:3762:2: 'or'
            {
             before(grammarAccess.getLowerorEqualboundAccess().getOrKeyword_1()); 
            match(input,62,FOLLOW_2); 
             after(grammarAccess.getLowerorEqualboundAccess().getOrKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LowerorEqualbound__Group__1__Impl"


    // $ANTLR start "rule__LowerorEqualbound__Group__2"
    // InternalSml.g:3771:1: rule__LowerorEqualbound__Group__2 : rule__LowerorEqualbound__Group__2__Impl rule__LowerorEqualbound__Group__3 ;
    public final void rule__LowerorEqualbound__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3775:1: ( rule__LowerorEqualbound__Group__2__Impl rule__LowerorEqualbound__Group__3 )
            // InternalSml.g:3776:2: rule__LowerorEqualbound__Group__2__Impl rule__LowerorEqualbound__Group__3
            {
            pushFollow(FOLLOW_49);
            rule__LowerorEqualbound__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LowerorEqualbound__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LowerorEqualbound__Group__2"


    // $ANTLR start "rule__LowerorEqualbound__Group__2__Impl"
    // InternalSml.g:3783:1: rule__LowerorEqualbound__Group__2__Impl : ( 'equal' ) ;
    public final void rule__LowerorEqualbound__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3787:1: ( ( 'equal' ) )
            // InternalSml.g:3788:1: ( 'equal' )
            {
            // InternalSml.g:3788:1: ( 'equal' )
            // InternalSml.g:3789:2: 'equal'
            {
             before(grammarAccess.getLowerorEqualboundAccess().getEqualKeyword_2()); 
            match(input,63,FOLLOW_2); 
             after(grammarAccess.getLowerorEqualboundAccess().getEqualKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LowerorEqualbound__Group__2__Impl"


    // $ANTLR start "rule__LowerorEqualbound__Group__3"
    // InternalSml.g:3798:1: rule__LowerorEqualbound__Group__3 : rule__LowerorEqualbound__Group__3__Impl rule__LowerorEqualbound__Group__4 ;
    public final void rule__LowerorEqualbound__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3802:1: ( rule__LowerorEqualbound__Group__3__Impl rule__LowerorEqualbound__Group__4 )
            // InternalSml.g:3803:2: rule__LowerorEqualbound__Group__3__Impl rule__LowerorEqualbound__Group__4
            {
            pushFollow(FOLLOW_41);
            rule__LowerorEqualbound__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LowerorEqualbound__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LowerorEqualbound__Group__3"


    // $ANTLR start "rule__LowerorEqualbound__Group__3__Impl"
    // InternalSml.g:3810:1: rule__LowerorEqualbound__Group__3__Impl : ( 'than' ) ;
    public final void rule__LowerorEqualbound__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3814:1: ( ( 'than' ) )
            // InternalSml.g:3815:1: ( 'than' )
            {
            // InternalSml.g:3815:1: ( 'than' )
            // InternalSml.g:3816:2: 'than'
            {
             before(grammarAccess.getLowerorEqualboundAccess().getThanKeyword_3()); 
            match(input,61,FOLLOW_2); 
             after(grammarAccess.getLowerorEqualboundAccess().getThanKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LowerorEqualbound__Group__3__Impl"


    // $ANTLR start "rule__LowerorEqualbound__Group__4"
    // InternalSml.g:3825:1: rule__LowerorEqualbound__Group__4 : rule__LowerorEqualbound__Group__4__Impl ;
    public final void rule__LowerorEqualbound__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3829:1: ( rule__LowerorEqualbound__Group__4__Impl )
            // InternalSml.g:3830:2: rule__LowerorEqualbound__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LowerorEqualbound__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LowerorEqualbound__Group__4"


    // $ANTLR start "rule__LowerorEqualbound__Group__4__Impl"
    // InternalSml.g:3836:1: rule__LowerorEqualbound__Group__4__Impl : ( ( rule__LowerorEqualbound__NAssignment_4 ) ) ;
    public final void rule__LowerorEqualbound__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3840:1: ( ( ( rule__LowerorEqualbound__NAssignment_4 ) ) )
            // InternalSml.g:3841:1: ( ( rule__LowerorEqualbound__NAssignment_4 ) )
            {
            // InternalSml.g:3841:1: ( ( rule__LowerorEqualbound__NAssignment_4 ) )
            // InternalSml.g:3842:2: ( rule__LowerorEqualbound__NAssignment_4 )
            {
             before(grammarAccess.getLowerorEqualboundAccess().getNAssignment_4()); 
            // InternalSml.g:3843:2: ( rule__LowerorEqualbound__NAssignment_4 )
            // InternalSml.g:3843:3: rule__LowerorEqualbound__NAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__LowerorEqualbound__NAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getLowerorEqualboundAccess().getNAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LowerorEqualbound__Group__4__Impl"


    // $ANTLR start "rule__Upperbound__Group__0"
    // InternalSml.g:3852:1: rule__Upperbound__Group__0 : rule__Upperbound__Group__0__Impl rule__Upperbound__Group__1 ;
    public final void rule__Upperbound__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3856:1: ( rule__Upperbound__Group__0__Impl rule__Upperbound__Group__1 )
            // InternalSml.g:3857:2: rule__Upperbound__Group__0__Impl rule__Upperbound__Group__1
            {
            pushFollow(FOLLOW_49);
            rule__Upperbound__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Upperbound__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Upperbound__Group__0"


    // $ANTLR start "rule__Upperbound__Group__0__Impl"
    // InternalSml.g:3864:1: rule__Upperbound__Group__0__Impl : ( 'more' ) ;
    public final void rule__Upperbound__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3868:1: ( ( 'more' ) )
            // InternalSml.g:3869:1: ( 'more' )
            {
            // InternalSml.g:3869:1: ( 'more' )
            // InternalSml.g:3870:2: 'more'
            {
             before(grammarAccess.getUpperboundAccess().getMoreKeyword_0()); 
            match(input,64,FOLLOW_2); 
             after(grammarAccess.getUpperboundAccess().getMoreKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Upperbound__Group__0__Impl"


    // $ANTLR start "rule__Upperbound__Group__1"
    // InternalSml.g:3879:1: rule__Upperbound__Group__1 : rule__Upperbound__Group__1__Impl rule__Upperbound__Group__2 ;
    public final void rule__Upperbound__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3883:1: ( rule__Upperbound__Group__1__Impl rule__Upperbound__Group__2 )
            // InternalSml.g:3884:2: rule__Upperbound__Group__1__Impl rule__Upperbound__Group__2
            {
            pushFollow(FOLLOW_41);
            rule__Upperbound__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Upperbound__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Upperbound__Group__1"


    // $ANTLR start "rule__Upperbound__Group__1__Impl"
    // InternalSml.g:3891:1: rule__Upperbound__Group__1__Impl : ( 'than' ) ;
    public final void rule__Upperbound__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3895:1: ( ( 'than' ) )
            // InternalSml.g:3896:1: ( 'than' )
            {
            // InternalSml.g:3896:1: ( 'than' )
            // InternalSml.g:3897:2: 'than'
            {
             before(grammarAccess.getUpperboundAccess().getThanKeyword_1()); 
            match(input,61,FOLLOW_2); 
             after(grammarAccess.getUpperboundAccess().getThanKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Upperbound__Group__1__Impl"


    // $ANTLR start "rule__Upperbound__Group__2"
    // InternalSml.g:3906:1: rule__Upperbound__Group__2 : rule__Upperbound__Group__2__Impl ;
    public final void rule__Upperbound__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3910:1: ( rule__Upperbound__Group__2__Impl )
            // InternalSml.g:3911:2: rule__Upperbound__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Upperbound__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Upperbound__Group__2"


    // $ANTLR start "rule__Upperbound__Group__2__Impl"
    // InternalSml.g:3917:1: rule__Upperbound__Group__2__Impl : ( ( rule__Upperbound__NAssignment_2 ) ) ;
    public final void rule__Upperbound__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3921:1: ( ( ( rule__Upperbound__NAssignment_2 ) ) )
            // InternalSml.g:3922:1: ( ( rule__Upperbound__NAssignment_2 ) )
            {
            // InternalSml.g:3922:1: ( ( rule__Upperbound__NAssignment_2 ) )
            // InternalSml.g:3923:2: ( rule__Upperbound__NAssignment_2 )
            {
             before(grammarAccess.getUpperboundAccess().getNAssignment_2()); 
            // InternalSml.g:3924:2: ( rule__Upperbound__NAssignment_2 )
            // InternalSml.g:3924:3: rule__Upperbound__NAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Upperbound__NAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getUpperboundAccess().getNAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Upperbound__Group__2__Impl"


    // $ANTLR start "rule__UpperorEqualbound__Group__0"
    // InternalSml.g:3933:1: rule__UpperorEqualbound__Group__0 : rule__UpperorEqualbound__Group__0__Impl rule__UpperorEqualbound__Group__1 ;
    public final void rule__UpperorEqualbound__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3937:1: ( rule__UpperorEqualbound__Group__0__Impl rule__UpperorEqualbound__Group__1 )
            // InternalSml.g:3938:2: rule__UpperorEqualbound__Group__0__Impl rule__UpperorEqualbound__Group__1
            {
            pushFollow(FOLLOW_50);
            rule__UpperorEqualbound__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__UpperorEqualbound__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UpperorEqualbound__Group__0"


    // $ANTLR start "rule__UpperorEqualbound__Group__0__Impl"
    // InternalSml.g:3945:1: rule__UpperorEqualbound__Group__0__Impl : ( 'more' ) ;
    public final void rule__UpperorEqualbound__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3949:1: ( ( 'more' ) )
            // InternalSml.g:3950:1: ( 'more' )
            {
            // InternalSml.g:3950:1: ( 'more' )
            // InternalSml.g:3951:2: 'more'
            {
             before(grammarAccess.getUpperorEqualboundAccess().getMoreKeyword_0()); 
            match(input,64,FOLLOW_2); 
             after(grammarAccess.getUpperorEqualboundAccess().getMoreKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UpperorEqualbound__Group__0__Impl"


    // $ANTLR start "rule__UpperorEqualbound__Group__1"
    // InternalSml.g:3960:1: rule__UpperorEqualbound__Group__1 : rule__UpperorEqualbound__Group__1__Impl rule__UpperorEqualbound__Group__2 ;
    public final void rule__UpperorEqualbound__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3964:1: ( rule__UpperorEqualbound__Group__1__Impl rule__UpperorEqualbound__Group__2 )
            // InternalSml.g:3965:2: rule__UpperorEqualbound__Group__1__Impl rule__UpperorEqualbound__Group__2
            {
            pushFollow(FOLLOW_51);
            rule__UpperorEqualbound__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__UpperorEqualbound__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UpperorEqualbound__Group__1"


    // $ANTLR start "rule__UpperorEqualbound__Group__1__Impl"
    // InternalSml.g:3972:1: rule__UpperorEqualbound__Group__1__Impl : ( 'or' ) ;
    public final void rule__UpperorEqualbound__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3976:1: ( ( 'or' ) )
            // InternalSml.g:3977:1: ( 'or' )
            {
            // InternalSml.g:3977:1: ( 'or' )
            // InternalSml.g:3978:2: 'or'
            {
             before(grammarAccess.getUpperorEqualboundAccess().getOrKeyword_1()); 
            match(input,62,FOLLOW_2); 
             after(grammarAccess.getUpperorEqualboundAccess().getOrKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UpperorEqualbound__Group__1__Impl"


    // $ANTLR start "rule__UpperorEqualbound__Group__2"
    // InternalSml.g:3987:1: rule__UpperorEqualbound__Group__2 : rule__UpperorEqualbound__Group__2__Impl rule__UpperorEqualbound__Group__3 ;
    public final void rule__UpperorEqualbound__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:3991:1: ( rule__UpperorEqualbound__Group__2__Impl rule__UpperorEqualbound__Group__3 )
            // InternalSml.g:3992:2: rule__UpperorEqualbound__Group__2__Impl rule__UpperorEqualbound__Group__3
            {
            pushFollow(FOLLOW_49);
            rule__UpperorEqualbound__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__UpperorEqualbound__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UpperorEqualbound__Group__2"


    // $ANTLR start "rule__UpperorEqualbound__Group__2__Impl"
    // InternalSml.g:3999:1: rule__UpperorEqualbound__Group__2__Impl : ( 'equal' ) ;
    public final void rule__UpperorEqualbound__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4003:1: ( ( 'equal' ) )
            // InternalSml.g:4004:1: ( 'equal' )
            {
            // InternalSml.g:4004:1: ( 'equal' )
            // InternalSml.g:4005:2: 'equal'
            {
             before(grammarAccess.getUpperorEqualboundAccess().getEqualKeyword_2()); 
            match(input,63,FOLLOW_2); 
             after(grammarAccess.getUpperorEqualboundAccess().getEqualKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UpperorEqualbound__Group__2__Impl"


    // $ANTLR start "rule__UpperorEqualbound__Group__3"
    // InternalSml.g:4014:1: rule__UpperorEqualbound__Group__3 : rule__UpperorEqualbound__Group__3__Impl rule__UpperorEqualbound__Group__4 ;
    public final void rule__UpperorEqualbound__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4018:1: ( rule__UpperorEqualbound__Group__3__Impl rule__UpperorEqualbound__Group__4 )
            // InternalSml.g:4019:2: rule__UpperorEqualbound__Group__3__Impl rule__UpperorEqualbound__Group__4
            {
            pushFollow(FOLLOW_41);
            rule__UpperorEqualbound__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__UpperorEqualbound__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UpperorEqualbound__Group__3"


    // $ANTLR start "rule__UpperorEqualbound__Group__3__Impl"
    // InternalSml.g:4026:1: rule__UpperorEqualbound__Group__3__Impl : ( 'than' ) ;
    public final void rule__UpperorEqualbound__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4030:1: ( ( 'than' ) )
            // InternalSml.g:4031:1: ( 'than' )
            {
            // InternalSml.g:4031:1: ( 'than' )
            // InternalSml.g:4032:2: 'than'
            {
             before(grammarAccess.getUpperorEqualboundAccess().getThanKeyword_3()); 
            match(input,61,FOLLOW_2); 
             after(grammarAccess.getUpperorEqualboundAccess().getThanKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UpperorEqualbound__Group__3__Impl"


    // $ANTLR start "rule__UpperorEqualbound__Group__4"
    // InternalSml.g:4041:1: rule__UpperorEqualbound__Group__4 : rule__UpperorEqualbound__Group__4__Impl ;
    public final void rule__UpperorEqualbound__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4045:1: ( rule__UpperorEqualbound__Group__4__Impl )
            // InternalSml.g:4046:2: rule__UpperorEqualbound__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__UpperorEqualbound__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UpperorEqualbound__Group__4"


    // $ANTLR start "rule__UpperorEqualbound__Group__4__Impl"
    // InternalSml.g:4052:1: rule__UpperorEqualbound__Group__4__Impl : ( ( rule__UpperorEqualbound__NAssignment_4 ) ) ;
    public final void rule__UpperorEqualbound__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4056:1: ( ( ( rule__UpperorEqualbound__NAssignment_4 ) ) )
            // InternalSml.g:4057:1: ( ( rule__UpperorEqualbound__NAssignment_4 ) )
            {
            // InternalSml.g:4057:1: ( ( rule__UpperorEqualbound__NAssignment_4 ) )
            // InternalSml.g:4058:2: ( rule__UpperorEqualbound__NAssignment_4 )
            {
             before(grammarAccess.getUpperorEqualboundAccess().getNAssignment_4()); 
            // InternalSml.g:4059:2: ( rule__UpperorEqualbound__NAssignment_4 )
            // InternalSml.g:4059:3: rule__UpperorEqualbound__NAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__UpperorEqualbound__NAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getUpperorEqualboundAccess().getNAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UpperorEqualbound__Group__4__Impl"


    // $ANTLR start "rule__Interval__Group__0"
    // InternalSml.g:4068:1: rule__Interval__Group__0 : rule__Interval__Group__0__Impl rule__Interval__Group__1 ;
    public final void rule__Interval__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4072:1: ( rule__Interval__Group__0__Impl rule__Interval__Group__1 )
            // InternalSml.g:4073:2: rule__Interval__Group__0__Impl rule__Interval__Group__1
            {
            pushFollow(FOLLOW_41);
            rule__Interval__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Interval__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interval__Group__0"


    // $ANTLR start "rule__Interval__Group__0__Impl"
    // InternalSml.g:4080:1: rule__Interval__Group__0__Impl : ( 'between' ) ;
    public final void rule__Interval__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4084:1: ( ( 'between' ) )
            // InternalSml.g:4085:1: ( 'between' )
            {
            // InternalSml.g:4085:1: ( 'between' )
            // InternalSml.g:4086:2: 'between'
            {
             before(grammarAccess.getIntervalAccess().getBetweenKeyword_0()); 
            match(input,65,FOLLOW_2); 
             after(grammarAccess.getIntervalAccess().getBetweenKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interval__Group__0__Impl"


    // $ANTLR start "rule__Interval__Group__1"
    // InternalSml.g:4095:1: rule__Interval__Group__1 : rule__Interval__Group__1__Impl rule__Interval__Group__2 ;
    public final void rule__Interval__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4099:1: ( rule__Interval__Group__1__Impl rule__Interval__Group__2 )
            // InternalSml.g:4100:2: rule__Interval__Group__1__Impl rule__Interval__Group__2
            {
            pushFollow(FOLLOW_46);
            rule__Interval__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Interval__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interval__Group__1"


    // $ANTLR start "rule__Interval__Group__1__Impl"
    // InternalSml.g:4107:1: rule__Interval__Group__1__Impl : ( ( rule__Interval__MAssignment_1 ) ) ;
    public final void rule__Interval__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4111:1: ( ( ( rule__Interval__MAssignment_1 ) ) )
            // InternalSml.g:4112:1: ( ( rule__Interval__MAssignment_1 ) )
            {
            // InternalSml.g:4112:1: ( ( rule__Interval__MAssignment_1 ) )
            // InternalSml.g:4113:2: ( rule__Interval__MAssignment_1 )
            {
             before(grammarAccess.getIntervalAccess().getMAssignment_1()); 
            // InternalSml.g:4114:2: ( rule__Interval__MAssignment_1 )
            // InternalSml.g:4114:3: rule__Interval__MAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Interval__MAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getIntervalAccess().getMAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interval__Group__1__Impl"


    // $ANTLR start "rule__Interval__Group__2"
    // InternalSml.g:4122:1: rule__Interval__Group__2 : rule__Interval__Group__2__Impl rule__Interval__Group__3 ;
    public final void rule__Interval__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4126:1: ( rule__Interval__Group__2__Impl rule__Interval__Group__3 )
            // InternalSml.g:4127:2: rule__Interval__Group__2__Impl rule__Interval__Group__3
            {
            pushFollow(FOLLOW_41);
            rule__Interval__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Interval__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interval__Group__2"


    // $ANTLR start "rule__Interval__Group__2__Impl"
    // InternalSml.g:4134:1: rule__Interval__Group__2__Impl : ( 'and' ) ;
    public final void rule__Interval__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4138:1: ( ( 'and' ) )
            // InternalSml.g:4139:1: ( 'and' )
            {
            // InternalSml.g:4139:1: ( 'and' )
            // InternalSml.g:4140:2: 'and'
            {
             before(grammarAccess.getIntervalAccess().getAndKeyword_2()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getIntervalAccess().getAndKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interval__Group__2__Impl"


    // $ANTLR start "rule__Interval__Group__3"
    // InternalSml.g:4149:1: rule__Interval__Group__3 : rule__Interval__Group__3__Impl ;
    public final void rule__Interval__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4153:1: ( rule__Interval__Group__3__Impl )
            // InternalSml.g:4154:2: rule__Interval__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Interval__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interval__Group__3"


    // $ANTLR start "rule__Interval__Group__3__Impl"
    // InternalSml.g:4160:1: rule__Interval__Group__3__Impl : ( ( rule__Interval__NAssignment_3 ) ) ;
    public final void rule__Interval__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4164:1: ( ( ( rule__Interval__NAssignment_3 ) ) )
            // InternalSml.g:4165:1: ( ( rule__Interval__NAssignment_3 ) )
            {
            // InternalSml.g:4165:1: ( ( rule__Interval__NAssignment_3 ) )
            // InternalSml.g:4166:2: ( rule__Interval__NAssignment_3 )
            {
             before(grammarAccess.getIntervalAccess().getNAssignment_3()); 
            // InternalSml.g:4167:2: ( rule__Interval__NAssignment_3 )
            // InternalSml.g:4167:3: rule__Interval__NAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Interval__NAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getIntervalAccess().getNAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interval__Group__3__Impl"


    // $ANTLR start "rule__Model__ArenasAssignment_0"
    // InternalSml.g:4176:1: rule__Model__ArenasAssignment_0 : ( ruleArena ) ;
    public final void rule__Model__ArenasAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4180:1: ( ( ruleArena ) )
            // InternalSml.g:4181:2: ( ruleArena )
            {
            // InternalSml.g:4181:2: ( ruleArena )
            // InternalSml.g:4182:3: ruleArena
            {
             before(grammarAccess.getModelAccess().getArenasArenaParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleArena();

            state._fsp--;

             after(grammarAccess.getModelAccess().getArenasArenaParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__ArenasAssignment_0"


    // $ANTLR start "rule__Model__EnvAssignment_1"
    // InternalSml.g:4191:1: rule__Model__EnvAssignment_1 : ( ruleEnvironment ) ;
    public final void rule__Model__EnvAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4195:1: ( ( ruleEnvironment ) )
            // InternalSml.g:4196:2: ( ruleEnvironment )
            {
            // InternalSml.g:4196:2: ( ruleEnvironment )
            // InternalSml.g:4197:3: ruleEnvironment
            {
             before(grammarAccess.getModelAccess().getEnvEnvironmentParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEnvironment();

            state._fsp--;

             after(grammarAccess.getModelAccess().getEnvEnvironmentParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__EnvAssignment_1"


    // $ANTLR start "rule__Model__SwAssignment_2"
    // InternalSml.g:4206:1: rule__Model__SwAssignment_2 : ( ruleSwarmconf ) ;
    public final void rule__Model__SwAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4210:1: ( ( ruleSwarmconf ) )
            // InternalSml.g:4211:2: ( ruleSwarmconf )
            {
            // InternalSml.g:4211:2: ( ruleSwarmconf )
            // InternalSml.g:4212:3: ruleSwarmconf
            {
             before(grammarAccess.getModelAccess().getSwSwarmconfParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSwarmconf();

            state._fsp--;

             after(grammarAccess.getModelAccess().getSwSwarmconfParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__SwAssignment_2"


    // $ANTLR start "rule__Environment__EnvironmentAssignment_7"
    // InternalSml.g:4221:1: rule__Environment__EnvironmentAssignment_7 : ( ruleEnvironmentElements ) ;
    public final void rule__Environment__EnvironmentAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4225:1: ( ( ruleEnvironmentElements ) )
            // InternalSml.g:4226:2: ( ruleEnvironmentElements )
            {
            // InternalSml.g:4226:2: ( ruleEnvironmentElements )
            // InternalSml.g:4227:3: ruleEnvironmentElements
            {
             before(grammarAccess.getEnvironmentAccess().getEnvironmentEnvironmentElementsParserRuleCall_7_0()); 
            pushFollow(FOLLOW_2);
            ruleEnvironmentElements();

            state._fsp--;

             after(grammarAccess.getEnvironmentAccess().getEnvironmentEnvironmentElementsParserRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Environment__EnvironmentAssignment_7"


    // $ANTLR start "rule__ProbabilisticDecription__DisAssignment_3"
    // InternalSml.g:4236:1: rule__ProbabilisticDecription__DisAssignment_3 : ( ruleDistribution ) ;
    public final void rule__ProbabilisticDecription__DisAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4240:1: ( ( ruleDistribution ) )
            // InternalSml.g:4241:2: ( ruleDistribution )
            {
            // InternalSml.g:4241:2: ( ruleDistribution )
            // InternalSml.g:4242:3: ruleDistribution
            {
             before(grammarAccess.getProbabilisticDecriptionAccess().getDisDistributionParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleDistribution();

            state._fsp--;

             after(grammarAccess.getProbabilisticDecriptionAccess().getDisDistributionParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__DisAssignment_3"


    // $ANTLR start "rule__ProbabilisticDecription__KAssignment_7"
    // InternalSml.g:4251:1: rule__ProbabilisticDecription__KAssignment_7 : ( ruleRegion ) ;
    public final void rule__ProbabilisticDecription__KAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4255:1: ( ( ruleRegion ) )
            // InternalSml.g:4256:2: ( ruleRegion )
            {
            // InternalSml.g:4256:2: ( ruleRegion )
            // InternalSml.g:4257:3: ruleRegion
            {
             before(grammarAccess.getProbabilisticDecriptionAccess().getKRegionParserRuleCall_7_0()); 
            pushFollow(FOLLOW_2);
            ruleRegion();

            state._fsp--;

             after(grammarAccess.getProbabilisticDecriptionAccess().getKRegionParserRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProbabilisticDecription__KAssignment_7"


    // $ANTLR start "rule__Swarmconf__XAssignment_5"
    // InternalSml.g:4266:1: rule__Swarmconf__XAssignment_5 : ( ruleRange ) ;
    public final void rule__Swarmconf__XAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4270:1: ( ( ruleRange ) )
            // InternalSml.g:4271:2: ( ruleRange )
            {
            // InternalSml.g:4271:2: ( ruleRange )
            // InternalSml.g:4272:3: ruleRange
            {
             before(grammarAccess.getSwarmconfAccess().getXRangeParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleRange();

            state._fsp--;

             after(grammarAccess.getSwarmconfAccess().getXRangeParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__XAssignment_5"


    // $ANTLR start "rule__Swarmconf__RAssignment_6"
    // InternalSml.g:4281:1: rule__Swarmconf__RAssignment_6 : ( ruleRobot ) ;
    public final void rule__Swarmconf__RAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4285:1: ( ( ruleRobot ) )
            // InternalSml.g:4286:2: ( ruleRobot )
            {
            // InternalSml.g:4286:2: ( ruleRobot )
            // InternalSml.g:4287:3: ruleRobot
            {
             before(grammarAccess.getSwarmconfAccess().getRRobotParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleRobot();

            state._fsp--;

             after(grammarAccess.getSwarmconfAccess().getRRobotParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__RAssignment_6"


    // $ANTLR start "rule__Swarmconf__PrAssignment_7"
    // InternalSml.g:4296:1: rule__Swarmconf__PrAssignment_7 : ( ruleProbabilisticDecription ) ;
    public final void rule__Swarmconf__PrAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4300:1: ( ( ruleProbabilisticDecription ) )
            // InternalSml.g:4301:2: ( ruleProbabilisticDecription )
            {
            // InternalSml.g:4301:2: ( ruleProbabilisticDecription )
            // InternalSml.g:4302:3: ruleProbabilisticDecription
            {
             before(grammarAccess.getSwarmconfAccess().getPrProbabilisticDecriptionParserRuleCall_7_0()); 
            pushFollow(FOLLOW_2);
            ruleProbabilisticDecription();

            state._fsp--;

             after(grammarAccess.getSwarmconfAccess().getPrProbabilisticDecriptionParserRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Swarmconf__PrAssignment_7"


    // $ANTLR start "rule__EnvironmentElements__ElementAssignment_0"
    // InternalSml.g:4311:1: rule__EnvironmentElements__ElementAssignment_0 : ( ruleEnvironmentElement ) ;
    public final void rule__EnvironmentElements__ElementAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4315:1: ( ( ruleEnvironmentElement ) )
            // InternalSml.g:4316:2: ( ruleEnvironmentElement )
            {
            // InternalSml.g:4316:2: ( ruleEnvironmentElement )
            // InternalSml.g:4317:3: ruleEnvironmentElement
            {
             before(grammarAccess.getEnvironmentElementsAccess().getElementEnvironmentElementParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleEnvironmentElement();

            state._fsp--;

             after(grammarAccess.getEnvironmentElementsAccess().getElementEnvironmentElementParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnvironmentElements__ElementAssignment_0"


    // $ANTLR start "rule__EnvironmentElements__ElementAssignment_1"
    // InternalSml.g:4326:1: rule__EnvironmentElements__ElementAssignment_1 : ( ruleElementDescription ) ;
    public final void rule__EnvironmentElements__ElementAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4330:1: ( ( ruleElementDescription ) )
            // InternalSml.g:4331:2: ( ruleElementDescription )
            {
            // InternalSml.g:4331:2: ( ruleElementDescription )
            // InternalSml.g:4332:3: ruleElementDescription
            {
             before(grammarAccess.getEnvironmentElementsAccess().getElementElementDescriptionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleElementDescription();

            state._fsp--;

             after(grammarAccess.getEnvironmentElementsAccess().getElementElementDescriptionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnvironmentElements__ElementAssignment_1"


    // $ANTLR start "rule__ElementDescription__ElAssignment_0"
    // InternalSml.g:4341:1: rule__ElementDescription__ElAssignment_0 : ( ( 'There' ) ) ;
    public final void rule__ElementDescription__ElAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4345:1: ( ( ( 'There' ) ) )
            // InternalSml.g:4346:2: ( ( 'There' ) )
            {
            // InternalSml.g:4346:2: ( ( 'There' ) )
            // InternalSml.g:4347:3: ( 'There' )
            {
             before(grammarAccess.getElementDescriptionAccess().getElThereKeyword_0_0()); 
            // InternalSml.g:4348:3: ( 'There' )
            // InternalSml.g:4349:4: 'There'
            {
             before(grammarAccess.getElementDescriptionAccess().getElThereKeyword_0_0()); 
            match(input,66,FOLLOW_2); 
             after(grammarAccess.getElementDescriptionAccess().getElThereKeyword_0_0()); 

            }

             after(grammarAccess.getElementDescriptionAccess().getElThereKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__ElAssignment_0"


    // $ANTLR start "rule__ElementDescription__XAssignment_2"
    // InternalSml.g:4360:1: rule__ElementDescription__XAssignment_2 : ( ruleRange ) ;
    public final void rule__ElementDescription__XAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4364:1: ( ( ruleRange ) )
            // InternalSml.g:4365:2: ( ruleRange )
            {
            // InternalSml.g:4365:2: ( ruleRange )
            // InternalSml.g:4366:3: ruleRange
            {
             before(grammarAccess.getElementDescriptionAccess().getXRangeParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleRange();

            state._fsp--;

             after(grammarAccess.getElementDescriptionAccess().getXRangeParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__XAssignment_2"


    // $ANTLR start "rule__ElementDescription__ObjAssignment_3"
    // InternalSml.g:4375:1: rule__ElementDescription__ObjAssignment_3 : ( ruleElement ) ;
    public final void rule__ElementDescription__ObjAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4379:1: ( ( ruleElement ) )
            // InternalSml.g:4380:2: ( ruleElement )
            {
            // InternalSml.g:4380:2: ( ruleElement )
            // InternalSml.g:4381:3: ruleElement
            {
             before(grammarAccess.getElementDescriptionAccess().getObjElementParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleElement();

            state._fsp--;

             after(grammarAccess.getElementDescriptionAccess().getObjElementParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__ObjAssignment_3"


    // $ANTLR start "rule__ElementDescription__RAssignment_4"
    // InternalSml.g:4390:1: rule__ElementDescription__RAssignment_4 : ( ruleProbabilisticDecription ) ;
    public final void rule__ElementDescription__RAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4394:1: ( ( ruleProbabilisticDecription ) )
            // InternalSml.g:4395:2: ( ruleProbabilisticDecription )
            {
            // InternalSml.g:4395:2: ( ruleProbabilisticDecription )
            // InternalSml.g:4396:3: ruleProbabilisticDecription
            {
             before(grammarAccess.getElementDescriptionAccess().getRProbabilisticDecriptionParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleProbabilisticDecription();

            state._fsp--;

             after(grammarAccess.getElementDescriptionAccess().getRProbabilisticDecriptionParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ElementDescription__RAssignment_4"


    // $ANTLR start "rule__Object__ObjAssignment_0"
    // InternalSml.g:4405:1: rule__Object__ObjAssignment_0 : ( ( 'An' ) ) ;
    public final void rule__Object__ObjAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4409:1: ( ( ( 'An' ) ) )
            // InternalSml.g:4410:2: ( ( 'An' ) )
            {
            // InternalSml.g:4410:2: ( ( 'An' ) )
            // InternalSml.g:4411:3: ( 'An' )
            {
             before(grammarAccess.getObjectAccess().getObjAnKeyword_0_0()); 
            // InternalSml.g:4412:3: ( 'An' )
            // InternalSml.g:4413:4: 'An'
            {
             before(grammarAccess.getObjectAccess().getObjAnKeyword_0_0()); 
            match(input,67,FOLLOW_2); 
             after(grammarAccess.getObjectAccess().getObjAnKeyword_0_0()); 

            }

             after(grammarAccess.getObjectAccess().getObjAnKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Object__ObjAssignment_0"


    // $ANTLR start "rule__Object__RAssignment_4"
    // InternalSml.g:4424:1: rule__Object__RAssignment_4 : ( ruleRegion ) ;
    public final void rule__Object__RAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4428:1: ( ( ruleRegion ) )
            // InternalSml.g:4429:2: ( ruleRegion )
            {
            // InternalSml.g:4429:2: ( ruleRegion )
            // InternalSml.g:4430:3: ruleRegion
            {
             before(grammarAccess.getObjectAccess().getRRegionParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleRegion();

            state._fsp--;

             after(grammarAccess.getObjectAccess().getRRegionParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Object__RAssignment_4"


    // $ANTLR start "rule__Obstacle__ObsAssignment_0"
    // InternalSml.g:4439:1: rule__Obstacle__ObsAssignment_0 : ( ( 'An' ) ) ;
    public final void rule__Obstacle__ObsAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4443:1: ( ( ( 'An' ) ) )
            // InternalSml.g:4444:2: ( ( 'An' ) )
            {
            // InternalSml.g:4444:2: ( ( 'An' ) )
            // InternalSml.g:4445:3: ( 'An' )
            {
             before(grammarAccess.getObstacleAccess().getObsAnKeyword_0_0()); 
            // InternalSml.g:4446:3: ( 'An' )
            // InternalSml.g:4447:4: 'An'
            {
             before(grammarAccess.getObstacleAccess().getObsAnKeyword_0_0()); 
            match(input,67,FOLLOW_2); 
             after(grammarAccess.getObstacleAccess().getObsAnKeyword_0_0()); 

            }

             after(grammarAccess.getObstacleAccess().getObsAnKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Obstacle__ObsAssignment_0"


    // $ANTLR start "rule__Obstacle__RAssignment_4"
    // InternalSml.g:4458:1: rule__Obstacle__RAssignment_4 : ( ruleRegion ) ;
    public final void rule__Obstacle__RAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4462:1: ( ( ruleRegion ) )
            // InternalSml.g:4463:2: ( ruleRegion )
            {
            // InternalSml.g:4463:2: ( ruleRegion )
            // InternalSml.g:4464:3: ruleRegion
            {
             before(grammarAccess.getObstacleAccess().getRRegionParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleRegion();

            state._fsp--;

             after(grammarAccess.getObstacleAccess().getRRegionParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Obstacle__RAssignment_4"


    // $ANTLR start "rule__Light__LAssignment_0"
    // InternalSml.g:4473:1: rule__Light__LAssignment_0 : ( ( 'A' ) ) ;
    public final void rule__Light__LAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4477:1: ( ( ( 'A' ) ) )
            // InternalSml.g:4478:2: ( ( 'A' ) )
            {
            // InternalSml.g:4478:2: ( ( 'A' ) )
            // InternalSml.g:4479:3: ( 'A' )
            {
             before(grammarAccess.getLightAccess().getLAKeyword_0_0()); 
            // InternalSml.g:4480:3: ( 'A' )
            // InternalSml.g:4481:4: 'A'
            {
             before(grammarAccess.getLightAccess().getLAKeyword_0_0()); 
            match(input,68,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getLAKeyword_0_0()); 

            }

             after(grammarAccess.getLightAccess().getLAKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__LAssignment_0"


    // $ANTLR start "rule__Light__CAssignment_5"
    // InternalSml.g:4492:1: rule__Light__CAssignment_5 : ( ruleColor ) ;
    public final void rule__Light__CAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4496:1: ( ( ruleColor ) )
            // InternalSml.g:4497:2: ( ruleColor )
            {
            // InternalSml.g:4497:2: ( ruleColor )
            // InternalSml.g:4498:3: ruleColor
            {
             before(grammarAccess.getLightAccess().getCColorParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleColor();

            state._fsp--;

             after(grammarAccess.getLightAccess().getCColorParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__CAssignment_5"


    // $ANTLR start "rule__Light__PAssignment_11"
    // InternalSml.g:4507:1: rule__Light__PAssignment_11 : ( rulePosition ) ;
    public final void rule__Light__PAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4511:1: ( ( rulePosition ) )
            // InternalSml.g:4512:2: ( rulePosition )
            {
            // InternalSml.g:4512:2: ( rulePosition )
            // InternalSml.g:4513:3: rulePosition
            {
             before(grammarAccess.getLightAccess().getPPositionParserRuleCall_11_0()); 
            pushFollow(FOLLOW_2);
            rulePosition();

            state._fsp--;

             after(grammarAccess.getLightAccess().getPPositionParserRuleCall_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__PAssignment_11"


    // $ANTLR start "rule__Position__PointAssignment_0_2"
    // InternalSml.g:4522:1: rule__Position__PointAssignment_0_2 : ( ruleCoordinate ) ;
    public final void rule__Position__PointAssignment_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4526:1: ( ( ruleCoordinate ) )
            // InternalSml.g:4527:2: ( ruleCoordinate )
            {
            // InternalSml.g:4527:2: ( ruleCoordinate )
            // InternalSml.g:4528:3: ruleCoordinate
            {
             before(grammarAccess.getPositionAccess().getPointCoordinateParserRuleCall_0_2_0()); 
            pushFollow(FOLLOW_2);
            ruleCoordinate();

            state._fsp--;

             after(grammarAccess.getPositionAccess().getPointCoordinateParserRuleCall_0_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__PointAssignment_0_2"


    // $ANTLR start "rule__Position__PointAssignment_1_2"
    // InternalSml.g:4537:1: rule__Position__PointAssignment_1_2 : ( ruleCoordinate ) ;
    public final void rule__Position__PointAssignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4541:1: ( ( ruleCoordinate ) )
            // InternalSml.g:4542:2: ( ruleCoordinate )
            {
            // InternalSml.g:4542:2: ( ruleCoordinate )
            // InternalSml.g:4543:3: ruleCoordinate
            {
             before(grammarAccess.getPositionAccess().getPointCoordinateParserRuleCall_1_2_0()); 
            pushFollow(FOLLOW_2);
            ruleCoordinate();

            state._fsp--;

             after(grammarAccess.getPositionAccess().getPointCoordinateParserRuleCall_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__PointAssignment_1_2"


    // $ANTLR start "rule__Position__PointAssignment_2_2"
    // InternalSml.g:4552:1: rule__Position__PointAssignment_2_2 : ( ruleCoordinate ) ;
    public final void rule__Position__PointAssignment_2_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4556:1: ( ( ruleCoordinate ) )
            // InternalSml.g:4557:2: ( ruleCoordinate )
            {
            // InternalSml.g:4557:2: ( ruleCoordinate )
            // InternalSml.g:4558:3: ruleCoordinate
            {
             before(grammarAccess.getPositionAccess().getPointCoordinateParserRuleCall_2_2_0()); 
            pushFollow(FOLLOW_2);
            ruleCoordinate();

            state._fsp--;

             after(grammarAccess.getPositionAccess().getPointCoordinateParserRuleCall_2_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__PointAssignment_2_2"


    // $ANTLR start "rule__Arena__SAssignment_4"
    // InternalSml.g:4567:1: rule__Arena__SAssignment_4 : ( ruleRegion ) ;
    public final void rule__Arena__SAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4571:1: ( ( ruleRegion ) )
            // InternalSml.g:4572:2: ( ruleRegion )
            {
            // InternalSml.g:4572:2: ( ruleRegion )
            // InternalSml.g:4573:3: ruleRegion
            {
             before(grammarAccess.getArenaAccess().getSRegionParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleRegion();

            state._fsp--;

             after(grammarAccess.getArenaAccess().getSRegionParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Arena__SAssignment_4"


    // $ANTLR start "rule__Region__ColorsAssignment_0"
    // InternalSml.g:4582:1: rule__Region__ColorsAssignment_0 : ( ruleColor ) ;
    public final void rule__Region__ColorsAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4586:1: ( ( ruleColor ) )
            // InternalSml.g:4587:2: ( ruleColor )
            {
            // InternalSml.g:4587:2: ( ruleColor )
            // InternalSml.g:4588:3: ruleColor
            {
             before(grammarAccess.getRegionAccess().getColorsColorParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleColor();

            state._fsp--;

             after(grammarAccess.getRegionAccess().getColorsColorParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__ColorsAssignment_0"


    // $ANTLR start "rule__Region__ShapeAssignment_1"
    // InternalSml.g:4597:1: rule__Region__ShapeAssignment_1 : ( ruleShape ) ;
    public final void rule__Region__ShapeAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4601:1: ( ( ruleShape ) )
            // InternalSml.g:4602:2: ( ruleShape )
            {
            // InternalSml.g:4602:2: ( ruleShape )
            // InternalSml.g:4603:3: ruleShape
            {
             before(grammarAccess.getRegionAccess().getShapeShapeParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleShape();

            state._fsp--;

             after(grammarAccess.getRegionAccess().getShapeShapeParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__ShapeAssignment_1"


    // $ANTLR start "rule__Region__NameAssignment_2"
    // InternalSml.g:4612:1: rule__Region__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__Region__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4616:1: ( ( RULE_ID ) )
            // InternalSml.g:4617:2: ( RULE_ID )
            {
            // InternalSml.g:4617:2: ( RULE_ID )
            // InternalSml.g:4618:3: RULE_ID
            {
             before(grammarAccess.getRegionAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getRegionAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__NameAssignment_2"


    // $ANTLR start "rule__Region__ReferencepointAssignment_3_1"
    // InternalSml.g:4627:1: rule__Region__ReferencepointAssignment_3_1 : ( rulePosition ) ;
    public final void rule__Region__ReferencepointAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4631:1: ( ( rulePosition ) )
            // InternalSml.g:4632:2: ( rulePosition )
            {
            // InternalSml.g:4632:2: ( rulePosition )
            // InternalSml.g:4633:3: rulePosition
            {
             before(grammarAccess.getRegionAccess().getReferencepointPositionParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            rulePosition();

            state._fsp--;

             after(grammarAccess.getRegionAccess().getReferencepointPositionParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__ReferencepointAssignment_3_1"


    // $ANTLR start "rule__Region__DimensionsAssignment_4_1"
    // InternalSml.g:4642:1: rule__Region__DimensionsAssignment_4_1 : ( ruleDimension ) ;
    public final void rule__Region__DimensionsAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4646:1: ( ( ruleDimension ) )
            // InternalSml.g:4647:2: ( ruleDimension )
            {
            // InternalSml.g:4647:2: ( ruleDimension )
            // InternalSml.g:4648:3: ruleDimension
            {
             before(grammarAccess.getRegionAccess().getDimensionsDimensionParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleDimension();

            state._fsp--;

             after(grammarAccess.getRegionAccess().getDimensionsDimensionParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Region__DimensionsAssignment_4_1"


    // $ANTLR start "rule__CircleD__RAssignment_1"
    // InternalSml.g:4657:1: rule__CircleD__RAssignment_1 : ( ruleDouble ) ;
    public final void rule__CircleD__RAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4661:1: ( ( ruleDouble ) )
            // InternalSml.g:4662:2: ( ruleDouble )
            {
            // InternalSml.g:4662:2: ( ruleDouble )
            // InternalSml.g:4663:3: ruleDouble
            {
             before(grammarAccess.getCircleDAccess().getRDoubleParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleDouble();

            state._fsp--;

             after(grammarAccess.getCircleDAccess().getRDoubleParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CircleD__RAssignment_1"


    // $ANTLR start "rule__RectangleD__LAssignment_1"
    // InternalSml.g:4672:1: rule__RectangleD__LAssignment_1 : ( ruleDouble ) ;
    public final void rule__RectangleD__LAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4676:1: ( ( ruleDouble ) )
            // InternalSml.g:4677:2: ( ruleDouble )
            {
            // InternalSml.g:4677:2: ( ruleDouble )
            // InternalSml.g:4678:3: ruleDouble
            {
             before(grammarAccess.getRectangleDAccess().getLDoubleParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleDouble();

            state._fsp--;

             after(grammarAccess.getRectangleDAccess().getLDoubleParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__LAssignment_1"


    // $ANTLR start "rule__RectangleD__WAssignment_3"
    // InternalSml.g:4687:1: rule__RectangleD__WAssignment_3 : ( ruleDouble ) ;
    public final void rule__RectangleD__WAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4691:1: ( ( ruleDouble ) )
            // InternalSml.g:4692:2: ( ruleDouble )
            {
            // InternalSml.g:4692:2: ( ruleDouble )
            // InternalSml.g:4693:3: ruleDouble
            {
             before(grammarAccess.getRectangleDAccess().getWDoubleParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleDouble();

            state._fsp--;

             after(grammarAccess.getRectangleDAccess().getWDoubleParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__WAssignment_3"


    // $ANTLR start "rule__RectangleD__HAssignment_6"
    // InternalSml.g:4702:1: rule__RectangleD__HAssignment_6 : ( ruleDouble ) ;
    public final void rule__RectangleD__HAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4706:1: ( ( ruleDouble ) )
            // InternalSml.g:4707:2: ( ruleDouble )
            {
            // InternalSml.g:4707:2: ( ruleDouble )
            // InternalSml.g:4708:3: ruleDouble
            {
             before(grammarAccess.getRectangleDAccess().getHDoubleParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleDouble();

            state._fsp--;

             after(grammarAccess.getRectangleDAccess().getHDoubleParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RectangleD__HAssignment_6"


    // $ANTLR start "rule__Coordinate__XAssignment_0"
    // InternalSml.g:4717:1: rule__Coordinate__XAssignment_0 : ( ruleDouble ) ;
    public final void rule__Coordinate__XAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4721:1: ( ( ruleDouble ) )
            // InternalSml.g:4722:2: ( ruleDouble )
            {
            // InternalSml.g:4722:2: ( ruleDouble )
            // InternalSml.g:4723:3: ruleDouble
            {
             before(grammarAccess.getCoordinateAccess().getXDoubleParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleDouble();

            state._fsp--;

             after(grammarAccess.getCoordinateAccess().getXDoubleParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__XAssignment_0"


    // $ANTLR start "rule__Coordinate__YAssignment_1"
    // InternalSml.g:4732:1: rule__Coordinate__YAssignment_1 : ( ruleDouble ) ;
    public final void rule__Coordinate__YAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4736:1: ( ( ruleDouble ) )
            // InternalSml.g:4737:2: ( ruleDouble )
            {
            // InternalSml.g:4737:2: ( ruleDouble )
            // InternalSml.g:4738:3: ruleDouble
            {
             before(grammarAccess.getCoordinateAccess().getYDoubleParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleDouble();

            state._fsp--;

             after(grammarAccess.getCoordinateAccess().getYDoubleParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coordinate__YAssignment_1"


    // $ANTLR start "rule__ConstantSize__NAssignment"
    // InternalSml.g:4747:1: rule__ConstantSize__NAssignment : ( RULE_INT ) ;
    public final void rule__ConstantSize__NAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4751:1: ( ( RULE_INT ) )
            // InternalSml.g:4752:2: ( RULE_INT )
            {
            // InternalSml.g:4752:2: ( RULE_INT )
            // InternalSml.g:4753:3: RULE_INT
            {
             before(grammarAccess.getConstantSizeAccess().getNINTTerminalRuleCall_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getConstantSizeAccess().getNINTTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstantSize__NAssignment"


    // $ANTLR start "rule__Lowerbound__NAssignment_2"
    // InternalSml.g:4762:1: rule__Lowerbound__NAssignment_2 : ( RULE_INT ) ;
    public final void rule__Lowerbound__NAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4766:1: ( ( RULE_INT ) )
            // InternalSml.g:4767:2: ( RULE_INT )
            {
            // InternalSml.g:4767:2: ( RULE_INT )
            // InternalSml.g:4768:3: RULE_INT
            {
             before(grammarAccess.getLowerboundAccess().getNINTTerminalRuleCall_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getLowerboundAccess().getNINTTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lowerbound__NAssignment_2"


    // $ANTLR start "rule__LowerorEqualbound__NAssignment_4"
    // InternalSml.g:4777:1: rule__LowerorEqualbound__NAssignment_4 : ( RULE_INT ) ;
    public final void rule__LowerorEqualbound__NAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4781:1: ( ( RULE_INT ) )
            // InternalSml.g:4782:2: ( RULE_INT )
            {
            // InternalSml.g:4782:2: ( RULE_INT )
            // InternalSml.g:4783:3: RULE_INT
            {
             before(grammarAccess.getLowerorEqualboundAccess().getNINTTerminalRuleCall_4_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getLowerorEqualboundAccess().getNINTTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LowerorEqualbound__NAssignment_4"


    // $ANTLR start "rule__Upperbound__NAssignment_2"
    // InternalSml.g:4792:1: rule__Upperbound__NAssignment_2 : ( RULE_INT ) ;
    public final void rule__Upperbound__NAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4796:1: ( ( RULE_INT ) )
            // InternalSml.g:4797:2: ( RULE_INT )
            {
            // InternalSml.g:4797:2: ( RULE_INT )
            // InternalSml.g:4798:3: RULE_INT
            {
             before(grammarAccess.getUpperboundAccess().getNINTTerminalRuleCall_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getUpperboundAccess().getNINTTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Upperbound__NAssignment_2"


    // $ANTLR start "rule__UpperorEqualbound__NAssignment_4"
    // InternalSml.g:4807:1: rule__UpperorEqualbound__NAssignment_4 : ( RULE_INT ) ;
    public final void rule__UpperorEqualbound__NAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4811:1: ( ( RULE_INT ) )
            // InternalSml.g:4812:2: ( RULE_INT )
            {
            // InternalSml.g:4812:2: ( RULE_INT )
            // InternalSml.g:4813:3: RULE_INT
            {
             before(grammarAccess.getUpperorEqualboundAccess().getNINTTerminalRuleCall_4_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getUpperorEqualboundAccess().getNINTTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UpperorEqualbound__NAssignment_4"


    // $ANTLR start "rule__Interval__MAssignment_1"
    // InternalSml.g:4822:1: rule__Interval__MAssignment_1 : ( RULE_INT ) ;
    public final void rule__Interval__MAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4826:1: ( ( RULE_INT ) )
            // InternalSml.g:4827:2: ( RULE_INT )
            {
            // InternalSml.g:4827:2: ( RULE_INT )
            // InternalSml.g:4828:3: RULE_INT
            {
             before(grammarAccess.getIntervalAccess().getMINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getIntervalAccess().getMINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interval__MAssignment_1"


    // $ANTLR start "rule__Interval__NAssignment_3"
    // InternalSml.g:4837:1: rule__Interval__NAssignment_3 : ( RULE_INT ) ;
    public final void rule__Interval__NAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSml.g:4841:1: ( ( RULE_INT ) )
            // InternalSml.g:4842:2: ( RULE_INT )
            {
            // InternalSml.g:4842:2: ( RULE_INT )
            // InternalSml.g:4843:3: RULE_INT
            {
             before(grammarAccess.getIntervalAccess().getNINTTerminalRuleCall_3_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getIntervalAccess().getNINTTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interval__NAssignment_3"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000018L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x000000000000E000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000001FC0020L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x1000000000000010L,0x0000000000000003L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000001800L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000004L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000018L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000004L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000040000030000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000001C00000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0038000000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0040000200000000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0180000000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x8000000000000000L});

}